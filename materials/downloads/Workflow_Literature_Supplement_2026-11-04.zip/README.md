# Current workflow and literature supplement

Open workflow.html. This is the 4 November 2026 reader guide. Benchmark figures and the full AI research package are linked to the public article site. The workflow is a research blueprint, not a validated universal procedure.
