# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf`.
- Raw Markdown: `rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md`.
- Source note: `wiki/sources/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
