# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `needs-further-coding`.
- Top automated-data-extraction terms in source text: annotation (37), information extraction (36), large language model (6), human-ai (3), semi-automated (2), artificial intelligence (2), data extraction (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- While people can extract information from such documents with
high accuracy, this is often too time-consuming to be practical.
- Motivated by two use cases from criminal justice, we consider the benefits and drawbacks
of various human-only, human–machine, and machine-only approaches.
- Finding no tool well suited for
our use cases, we develop a human-in-the-loop method for fast but accurate extraction of structured data
from unstructured text.
- The tool is based on automated extraction followed by human validation, and is
particularly useful in cases where purely manual extraction is not practical.
- Testing on three criminal justice
datasets, we find that the combination of the computer speed and human understanding yields precision
comparable to manual annotation while requiring only a fraction of time, and significantly outperforms the
precision of all fully automated baselines.
- CCS Concepts: • Information systems → Information extraction; • Human-centered computing →
Interactive systems and tools; HCI design and evaluation methods;
Additional Key Words and Phrases: Human-computer collaboration, human-in-the-loop, information
extraction, weak supervision
ACM Reference Format:
Bradley Butcher, Miri Zilka, Jiri Hron, Darren Cook, and Adrian Weller.
- Optimising Human–Machine
Collaboration for Efficient High-Precision Information Extraction from Text Documents.
- In this
article, we explore information extraction (IE) use cases in criminal justice.
- While humans can often extract information from unstructured documents with near-perfect accuracy, their work is time-intensive, costly, and possibly
traumatizing (e.g., when the content is violent or sexual) [19].
- On the other hand, even state-ofthe-art automated methods still cannot extract information from text with human-level accuracy
[30, 79].
- The main focus of our article are therefore human–computer collaborative approaches to
IE with emphasis on the tradeoff between processing speed and extraction accuracy.
- Unlike in most of the existing literature on human–machine collaboration
[e.g., 5, 62], all our tasks are examples of the under-explored scenario where computers achieve
lower accuracy, but can significantly speed up processing.
