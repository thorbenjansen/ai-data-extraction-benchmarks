# Method And Design

## Source Identity

- Title: Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents
- ARA: `butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-ara`
- Source PDF: `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf`
- Raw Markdown: `rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `needs-further-coding`
- Branch role: `direct automated-data-extraction evidence`

## Data, Sample, Or Source Material

Optimising Human–Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents BRADLEY BUTCHER, University of Sussex and The Alan Turing Institute, Brighton, UK MIRI ZILKA, University of Cambridge, Cambridge, UK JIRI HRON, Google DeepMind, London, UK DARREN COOK, Imperial College London, London, UK ADRIAN WELLER, University of Cambridge and The Alan Turing Institute, Cambridge, UK From science to law enforcement, many research questions are answerable only by poring over a large amount of unstructured text documents. While people can extract information from such documents with high accuracy, this is often too time-consuming to be practical. On the other hand, automated approaches produce nearly-immediate results, but are not reliable enough for applications where near-perfect precision is essential. Motivated by two use cases from criminal justice, we consider the benefits and drawbacks of various human-only, human–machine, and machine-only approaches. Finding no tool well suited for our use cases, we develop a human-in-the-loop method for fast but accurate extraction of structured data from unstructured text. The tool is based on automated extraction followed by human validation, and is particularly useful in cases where purely manual extraction is not practical. Testing on three criminal justice datasets, we find that the combination of the computer speed and human understanding yields precision comparable to manual annotation while requiring only a fraction of time, and significantly outperforms the precision of all fully automated baselines. CCS Concepts: • Information systems → Information extraction; • Human-centered computing → Interactive systems and tools; HCI design and evaluation methods; Additional Key Words and Phrases: Human-computer collaboration, human-in-the-loop, information extraction, weak supervision ACM Reference Format: Bradley Butcher, Miri Zilka, Jiri Hron, Darren Cook, and Adrian Weller. 2024. Optimising Human–Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents. ACM J. Responsib. Comput. 1, 2, Article 16 (June 2024), 27 pages. https://doi.org/10.1145/3652591

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Optimising Human–Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents BRADLEY BUTCHER, University of Sussex and The Alan Turing Institute, Brighton, UK MIRI ZILKA, University of Cambridge, Cambridge, UK JIRI HRON, Google DeepMind, London, UK DARREN COOK, Imperial College London, London, UK ADRIAN WELLER, University of Cambridge and The Alan Turing Institute, Cambridge, UK From science to law enforcement, many research questions are answerable only by poring over a large amount of unstructured text documents. While people can extract information from such documents with high accuracy, this is often too time-consuming to be practical. On the other hand, automated approaches produce nearly-immediate results, but are not reliable enough for applications where near-perfect precision is essential. Motivated by two use cases from criminal justice, we consider the benefits and drawbacks of various human-only, human–machine, and machine-only approaches. Finding no tool well suited for our use cases, we develop a human-in-the-loop method for fast but accurate extraction of structured data from unstructured text. The tool is based on automated extraction followed by human validation, and is particularly useful in cases where purely manual extraction is not practical. Testing on three criminal justice datasets, we find that the combination of the computer speed and human understanding yields precision comparable to manual annotation while requiring only a fraction of time, and significantly outperforms the precision of all fully automated baselines. CCS Concepts: • Information systems → Information extraction; • Human-centered computing → Interactive systems and tools; HCI design and evaluation methods; Additional Key Words and Phrases: Human-computer collaboration, human-in-the-loop, information extraction, weak supervision ACM Reference Format: Bradley Butcher, Miri Zilka, Jiri Hron, Darren Cook, and Adrian Weller. 2024. Optimising Human–Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents. ACM J. Responsib. Comput. 1, 2, Article 16 (June 2024), 27 pages. https://doi.org/10.1145/3652591

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
