# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `full_markdown`.
- Source checking path: `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf`.
- Raw Markdown path: `rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md`.
