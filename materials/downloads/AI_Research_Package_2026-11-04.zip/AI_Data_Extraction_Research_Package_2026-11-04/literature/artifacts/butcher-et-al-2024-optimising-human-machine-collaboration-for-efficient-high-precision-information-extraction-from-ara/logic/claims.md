# Claims

- C01: `Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]], [[Speed-Accuracy Tradeoff]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf`.
