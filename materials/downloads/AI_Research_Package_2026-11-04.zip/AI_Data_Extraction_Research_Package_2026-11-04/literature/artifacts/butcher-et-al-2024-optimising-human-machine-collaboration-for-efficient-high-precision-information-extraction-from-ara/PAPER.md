---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents"
source_note: "wiki/sources/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.md"
source_path: "raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf"
rawmarkdown_path: "rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.md`
- Source path: `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md`
- Grounding status: `full_markdown`

## Abstracted Contribution

# Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Speed-Accuracy Tradeoff]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
