# Read-Through Result

## Source Identity Check

- Title: Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents
- Source PDF: `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf`
- Raw Markdown: `rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `needs-further-coding`
- Branch role: `direct automated-data-extraction evidence`

## Results Or Findings Check

Optimising Human–Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents BRADLEY BUTCHER, University of Sussex and The Alan Turing Institute, Brighton, UK MIRI ZILKA, University of Cambridge, Cambridge, UK JIRI HRON, Google DeepMind, London, UK DARREN COOK, Imperial College London, London, UK ADRIAN WELLER, University of Cambridge and The Alan Turing Institute, Cambridge, UK From science to law enforcement, many research questions are answerable only by poring over a large amount of unstructured text documents. While people can extract information from such documents with high accuracy, this is often too time-consuming to be practical. On the other hand, automated approaches produce nearly-immediate results, but are not reliable enough for applications where near-perfect precision is essential. Motivated by two use cases from criminal justice, we consider the benefits and drawbacks of various human-only, human–machine, and machine-only approaches. Finding no tool well suited for our use cases, we develop a human-in-the-loop method for fast but accurate extraction of structured data from unstructured text. The tool is based on automated extraction followed by human validation, and is particularly useful in cases where purely manual extraction is not practical. Testing on three criminal justice datasets, we find that the combination of the computer speed and human understanding yields precision comparable to manual annotation while requiring only a fraction of time, and significantly outperforms the precision of all fully automated baselines. CCS Concepts: • Information systems → Information extraction; • Human-centered computing → Interactive systems and tools; HCI design and evaluation methods; Additional Key Words and Phrases: Human-computer collaboration, human-in-the-loop, information extraction, weak supervision ACM Reference Format: Bradley Butcher, Miri Zilka, Jiri Hron, Darren Cook, and Adrian Weller. 2024. Optimising Human–Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents. ACM J. Responsib. Comput. 1, 2, Article 16 (June 2024), 27 pages. https://doi.org/10.1145/3652591

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
