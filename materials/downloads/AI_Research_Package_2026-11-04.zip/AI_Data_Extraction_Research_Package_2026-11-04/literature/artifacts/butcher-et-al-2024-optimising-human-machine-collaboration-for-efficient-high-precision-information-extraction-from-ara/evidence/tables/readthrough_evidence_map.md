# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf` |
| Raw Markdown | `rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `needs-further-coding` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | annotation (37), information extraction (36), large language model (6), human-ai (3), semi-automated (2), artificial intelligence (2), data extraction (1) |
| Verification status | Needs human source-checking before exact citation |
