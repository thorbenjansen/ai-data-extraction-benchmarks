# Evidence README

## Source Pointer

- PDF: `raw/Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents.pdf`
- Raw Markdown: `rawmarkdown_full/butcher-et-al-2024-optimising-human-machine-collaboration-for-efficient-high-precision-information-extraction-from-text-documents.md`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

# Butcher et al. - 2024 - Optimising Human-Machine Collaboration for Efficient High-Precision Information Extraction from Text Documents
