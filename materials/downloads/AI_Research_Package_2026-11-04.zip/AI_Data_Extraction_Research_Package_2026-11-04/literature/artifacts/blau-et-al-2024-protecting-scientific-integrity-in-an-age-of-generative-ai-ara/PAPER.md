---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI"
source_note: "wiki/sources/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.md"
source_path: "raw/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.md`
- Source path: `raw/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

EDITORIAL

Protecting scientific integrity in an age of generative AI

Downloaded from https://www.pnas.org by 134.245.76.71 on December 11, 2025 from IP address 134.245.76.71.

Wolfgang Blaua, Vinton G. Cerfb, Juan Enriquezc, Joseph S. Franciscod , Urs Gassere, Mary L. Grayf,g, Mark Greavesh, Barbara J. Groszi,
Kathleen Hall Jamiesonj , Gerald H. Haugk , John L. Hennessyl, Eric Horvitzm , David I. Kaisern, Alex John Londono ,
Robin Lovell-­Badgep , Marcia K. McNuttq,1 , Martha Minowr, Tom M. Mitchells, Susan Nessj, Shobita Parthasarathyt,
Saul Perlmutteru,v, William H. Pressw , Jeannette M. Wingx, and Michael Witherelly

Revolutionary advances in AI have brought us to a transformative moment for science. AI is accelerating scientific discoveries
and analyses. At the same time, its tools and processes challenge core norms and values in the conduct of science, including
accountability, transparency, replicability, and human responsibility (1–3). These difficulties are particularly apparent in recent
advances with generative AI. Future innovations with AI may
mitigate some of these or raise new concerns and challenges.
With scientific integrity and responsibility in mind, the
National Academy of Sciences, the Annenberg Public Policy
Center of the University of Pennsylvania, and the Annenberg
Foundation Trust at Sunnylands recently convened an interdisciplinary panel of experts with experience in academia,
industry, and government to explore rising challenges posed
by the use of AI in research and to chart a path forward for
the scientific community. The panel included experts in
behavioral and social sciences, ethics, biology, physics, chemistry, mathematics, and computer science, as well as leaders
in higher education, law, governance, and science publishing
and communic

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Speed-Accuracy Tradeoff]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
