# Concepts

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Speed-Accuracy Tradeoff]]
