# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.pdf`.
- Raw Markdown path: `not available`.
