# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `branch-adjacent context`.
- Provisional design: `guidance/framework`.
- Top automated-data-extraction terms in source text: generative ai (7), artificial intelligence (2).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- At the same time, its tools and processes challenge core norms and values in the conduct of science, including
accountability, transparency, replicability, and human responsibility (1–3).
- Generative AI systems are constructed with computational
procedures that learn from large bodies of human-­authored and
curated text, imagery, and analyses, including expansive collections of scientific literature.
- 22

e2407886121

Five Principles of Human Accountability and
Responsibility
To protect the integrity of science in the age of generative AI,
we call upon the scientific community to remain steadfast in
honoring the guiding norms and values of science.
- We also reaffirm the findings of earlier work performed by the National Academies on responsible automated research workflows, which called for human review
of algorithms, the need for transparency and reproducibility,
and efforts to uncover and address bias (10).
- Building upon the prior studies, we urge the scientific community to focus sustained attention on five principles of
human accountability and responsibility for scientific efforts
that employ AI:
1.
- Published May 21, 2024.

https://doi.org/10.1073/pnas.2407886121 1 of 3

settings employed; accurately attribute the human and AI
sources of information or ideas, distinguishing between
the two and acknowledging their respective contributions;
and ensure that human expertise and prior literature are
appropriately cited, even when machines do not provide
such citations in their output.
- Verification of AI-­generated content and analyses
Scientists are accountable for the accuracy of the data,
imagery, and inferences that they draw from their uses of
generative models.
- Accountability requires the use of appropriate methods to validate the accuracy and reliability of
inferences made by or with the assistance of AI, along with a
thorough disclosure of evidence relevant to such inferences.
- AI should not be used without careful human oversight
in decisional steps of peer review processes or decisions
around career advancement and funding allocations.
- Gray, “A human rights framework for AI research worthy of public trust” in Issues in Science and Technology (2024), 10.58875/ERUU8159.
- That commitment—
together with the five principles of human accountability and
responsibility for the use of AI in science and the standing up
of the council to provide ongoing guidance—will support the
pursuit of trustworthy science for the benefit of all.
