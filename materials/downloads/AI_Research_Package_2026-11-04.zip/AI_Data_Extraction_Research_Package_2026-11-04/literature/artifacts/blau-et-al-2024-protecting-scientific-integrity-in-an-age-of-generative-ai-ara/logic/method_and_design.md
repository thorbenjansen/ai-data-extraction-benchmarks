# Method And Design

## Source Identity

- Title: Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI
- ARA: `blau-et-al-2024-protecting-scientific-integrity-in-an-age-of-generative-ai-ara`
- Source PDF: `raw/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `guidance/framework`
- Branch role: `branch-adjacent context`

## Data, Sample, Or Source Material

National Academies of Sciences, Engineering, and Medicine. Fostering Integrity in Research (The National Academies Press, Washington, DC, 2017), 10.17226/21896. National Academies of Sciences, Engineering, and Medicine. Reproducibility and Replicability in Science (The National Academies Press, Washington, DC, 2019), 10.17226/25303. National Academies of Sciences, Engineering, and Medicine. Fostering Responsible Computing Research: Foundations and Practices (The National Academies Press, Washington, DC, 2022), 10.17226/26507. M. Aidinoff, D. Kaiser, “Novel technologies and the choices we make: Historical precedents for managing artificial intelligence” in Issues in Science and Technology (2024), 10.58875/BUXB2813. U. Gasser, “Governing AI with intelligence” in Issues in Science and Technology (2024), 10.58875/AWJG1236. M. L. Gray, “A human rights framework for AI research worthy of public trust” in Issues in Science and Technology (2024), 10.58875/ERUU8159. A. J. London, “A justice-­led approach to AI innovation” in Issues in Science and Technology (2024), 10.58875/KNRZ2697. S. Parthasarathy, J. Katzman, “Bringing communities in, achieving AI for all” in Issues in Science and Technology (2024), 10.58875/SLRG2529. E. Horvitz, T. M. Mitchell, “Progress in AI: History and Trajectory” in Issues in Science and Technology (in press), 10.58875/ZRFJ6746. National Academies of Sciences, Engineering, and Medicine. Automated Research Workflows for Accelerated Discovery: Closing the Knowledge Discovery Loop (The National Academies Press, Washington, DC, 2022), 10.17226/26532.

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Revolutionary advances in AI have brought us to a transformative moment for science. AI is accelerating scientific discoveries and analyses. At the same time, its tools and processes challenge core norms and values in the conduct of science, including accountability, transparency, replicability, and human responsibility (1–3). These difficulties are particularly apparent in recent advances with generative AI. Future innovations with AI may mitigate some of these or raise new concerns and challenges. With scientific integrity and responsibility in mind, the National Academy of Sciences, the Annenberg Public Policy Center of the University of Pennsylvania, and the Annenberg Foundation Trust at Sunnylands recently convened an interdisciplinary panel of experts with experience in academia, industry, and government to explore rising challenges posed by the use of AI in research and to chart a path forward for the scientific community. The panel included experts in behavioral and social sciences, ethics, biology, physics, chemistry, mathematics, and computer science, as well as leaders in higher education, law, governance, and science publishing and communication. Discussions were informed by commissioned papers detailing the development and current state of AI technologies; the potential effects of AI advances on equality, justice, and research ethics; emerging governance issues; and lessons that can be learned from past instances where the scientific community addressed new technologies with significant societal implications (4–9). Generative AI systems are constructed with computational procedures that learn from large bodies of human-­authored and curated text, imagery, and analyses, including expansive collections of scientific literature. The systems are used to ­perform multiple operations, such as problem-­solving, data analysis, interpretation of textual and visual content, and the generation of text, images, and other forms of data. In response to prompts and other directives, the systems can provide users with coherent text, compelling imagery, and analyses, while also possessing the capability to generate novel syntheses and ideas that push the expected boundaries of automated ­content creation. Generative AI’s power to interact with scientists in a natural manner, to perform unprecedented types of problem-­solving, and to generate novel ideas and cont

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
