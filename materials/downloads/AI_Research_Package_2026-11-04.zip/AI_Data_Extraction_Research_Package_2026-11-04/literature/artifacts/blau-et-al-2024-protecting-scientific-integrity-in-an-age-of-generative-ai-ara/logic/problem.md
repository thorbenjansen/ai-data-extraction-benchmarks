# Problem

This ARA preserves a branch-local retrieval entry point for `Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI`.

## Provisional Role

- Document category: `branch-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
