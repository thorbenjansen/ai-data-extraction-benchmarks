# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `guidance/framework` |
| Branch role | `branch-adjacent context` |
| Top terms | generative ai (7), artificial intelligence (2) |
| Verification status | Needs human source-checking before exact citation |
