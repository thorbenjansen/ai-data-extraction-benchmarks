# Evidence README

## Source Pointer

- PDF: `raw/Blau et al. - 2024 - Protecting scientific integrity in an age of generative AI.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

EDITORIAL

Protecting scientific integrity in an age of generative AI

Downloaded from https://www.pnas.org by 134.245.76.71 on December 11, 2025 from IP address 134.245.76.71.

Wolfgang Blaua, Vinton G. Cerfb, Juan Enriquezc, Joseph S. Franciscod , Urs Gassere, Mary L. Grayf,g, Mark Greavesh, Barbara J. Groszi,
Kathleen Hall Jamiesonj , Gerald H. Haugk , John L. Hennessyl, Eric Horvitzm , David I. Kaisern, Alex John Londono ,
Robin Lovell-­Badgep , Marcia K. McNuttq,1 , Martha Minowr, Tom M. Mitchells, Susan Nessj, Shobita Parthasarathyt,
Saul Perlmutteru,v, William H. Pressw , Jeannette M. Wingx, and Michael Witherelly

Revolutionary advances in AI have brought us to a transformative moment for science. AI is accelerating scientific discoveries
and analyses. At the same time, its tools and processes challenge core norms and values in the conduct of science, including
accountability, transparency, replicability, and human responsibility (1–3). These difficulties are particularly apparent in recent
advances with generative AI. Future innovations with AI may
mitigate some of these or raise new concerns and challenges.
With scientific integrity and responsibility in mind, the
National Academy of Sciences, the Annenberg Public Policy
Center of the University of Pennsylvania, and the Annenberg
Foundation Trust at Sunnylands recently convened an interdisciplinary panel of experts with experience in academia,
industry, and government to explore rising challenges posed
by the use of AI in research and to chart a path forward for
the scientific community. The panel included experts in
behavioral and social sciences, ethics, biology, physics, chemistry, mathematics, and computer science, as well as leaders
in higher education, law, governance, and science publishing
and communic
