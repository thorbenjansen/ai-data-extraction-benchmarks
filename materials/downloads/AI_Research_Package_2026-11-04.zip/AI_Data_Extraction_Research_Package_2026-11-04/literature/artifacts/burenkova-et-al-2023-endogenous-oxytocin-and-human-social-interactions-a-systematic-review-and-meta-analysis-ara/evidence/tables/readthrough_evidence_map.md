# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `systematic-review/meta-analysis` |
| Branch role | `adjacent evidence-synthesis automation evidence` |
| Top terms | screening (6), data extraction (2), llm (1), risk of bias (1) |
| Verification status | Needs human source-checking before exact citation |
