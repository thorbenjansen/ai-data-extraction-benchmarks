# Method And Design

## Source Identity

- Title: Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis.
- ARA: `burenkova-et-al-2023-endogenous-oxytocin-and-human-social-interactions-a-systematic-review-and-meta-analysis-ara`
- Source PDF: `raw/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `adjacent evidence-synthesis automation evidence`

## Data, Sample, Or Source Material

extraction procedure, extraction type, sample collection method, special precautions before OXT collection, such as fasting); and (f) statistical information utilized to derive an effect size [ES]. Two authors performed data extraction independently, and were checked by a third author. If the data reported in the article were insufﬁcient to compute ESs, the publication authors were contacted twice during a given month to provide the data. If the authors did not respond to the request, but the data were present in ﬁgures, we digitized the data points using the open-source tool WebPlotDigitizer (Rohatgi, 2020). Otherwise, the article in question was excluded from the metaanalysis. We extracted three types of statistics during the extraction phase: mean differences between OXT concentrations, Pearson’s and Spearman’s correlation coefﬁcients between OXT concentrations and indicators of social interactions, and regression coefﬁcients for associations between OXT concentrations and indicators of social interactions. The ESs were estimated only for mean differences and correlation coefﬁcients; only these indices were used for further meta-analytic synthesis. We did not include regression coefﬁcients due to the high variability of the regression models used and the variables included in them, which would have added even greater heterogeneity to the analyses. Also, no data on mean differences were presented in one of the included studies (Grewen et al., 2005), and the authors did not provide them to us, although t statistics data were presented. Despite the existence of methods for conversion of t statistics into Cohen’s d, they cannot be used for a dependent or paired t test without correlation coefﬁcient r (Cooper et al., 2019, p. 216; Wilson, 2016, p. 4). We used the following formulas to calculate Hedges’ g ESs and variances for the results presented as mean differences. Hedges’ g is Cohen’s d corrected for small samples (Cumming, 2012, p. 309). We calculated Hedges’ gav using the following equation for dependent pairs of means for pre–post design and betweenconditions (control vs. interaction) design, with SDav value as a standardizer (Cumming, 2012, p. 291), taking into account the lack of correlation coefﬁcients r and other data from which they can be extracted in the vast majority of studies: Hedges’ gav =

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

extraction procedure, extraction type, sample collection method, special precautions before OXT collection, such as fasting); and (f) statistical information utilized to derive an effect size [ES]. Two authors performed data extraction independently, and were checked by a third author. If the data reported in the article were insufﬁcient to compute ESs, the publication authors were contacted twice during a given month to provide the data. If the authors did not respond to the request, but the data were present in ﬁgures, we digitized the data points using the open-source tool WebPlotDigitizer (Rohatgi, 2020). Otherwise, the article in question was excluded from the metaanalysis. We extracted three types of statistics during the extraction phase: mean differences between OXT concentrations, Pearson’s and Spearman’s correlation coefﬁcients between OXT concentrations and indicators of social interactions, and regression coefﬁcients for associations between OXT concentrations and indicators of social interactions. The ESs were estimated only for mean differences and correlation coefﬁcients; only these indices were used for further meta-analytic synthesis. We did not include regression coefﬁcients due to the high variability of the regression models used and the variables included in them, which would have added even greater heterogeneity to the analyses. Also, no data on mean differences were presented in one of the included studies (Grewen et al., 2005), and the authors did not provide them to us, although t statistics data were presented. Despite the existence of methods for conversion of t statistics into Cohen’s d, they cannot be used for a dependent or paired t test without correlation coefﬁcient r (Cooper et al., 2019, p. 216; Wilson, 2016, p. 4). We used the following formulas to calculate Hedges’ g ESs and variances for the results presented as mean differences. Hedges’ g is Cohen’s d corrected for small samples (Cumming, 2012, p. 309). We calculated Hedges’ gav using the following equation for dependent pairs of means for pre–post design and betweenconditions (control vs. interaction) design, with SDav value as a standardizer (Cumming, 2012, p. 291), taking into account the lack of correlation coefﬁcients r and other data from which they can be extracted in the vast majority of studies: Hedges’ gav =

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
