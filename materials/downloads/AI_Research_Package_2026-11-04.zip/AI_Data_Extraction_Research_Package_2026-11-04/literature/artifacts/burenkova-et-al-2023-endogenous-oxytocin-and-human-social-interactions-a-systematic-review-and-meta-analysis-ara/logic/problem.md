# Problem

This ARA preserves a branch-local retrieval entry point for `Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis.`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
