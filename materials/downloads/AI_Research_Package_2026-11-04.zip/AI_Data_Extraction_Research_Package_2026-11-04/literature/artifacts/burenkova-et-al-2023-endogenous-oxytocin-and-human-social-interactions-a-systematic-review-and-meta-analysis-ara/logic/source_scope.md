# Source Scope

## Strong Uses

- Use as `adjacent evidence-synthesis automation evidence` in the AI Data Extraction branch.
- Use for retrieval around screening, data extraction, llm, risk of bias.

## Weak Uses

- Do not treat this automated ARA as citation-grade for exact numbers without checking the PDF.
- Do not infer model superiority from abstract-level claims alone.
- Do not treat human-AI agreement or model confidence as validation unless the source itself defines and tests that standard.

## Transfer Boundaries

- Domain, document type, extraction target, model/tool version, and human adjudication design may limit transfer to the main AI data extraction paper.

## Citation-Grade Verification Needs

- Re-open `raw/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..pdf`.
- Confirm the exact extraction task and evaluation metric.
- Confirm whether the source evaluates data extraction specifically or an adjacent task such as screening, annotation, risk-of-bias, or literature search.
