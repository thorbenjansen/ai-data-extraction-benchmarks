# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `adjacent evidence-synthesis automation evidence`.
- Provisional design: `systematic-review/meta-analysis`.
- Top automated-data-extraction terms in source text: screening (6), data extraction (2), llm (1), risk of bias (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- 9–10, 549–579
https://doi.org/10.1037/bul0000402

Endogenous Oxytocin and Human Social Interactions: A Systematic
Review and Meta-Analysis
Olga V.
- 2

While there has been an increase in studies investigating the relationship between endogenous oxytocin
(OXT) concentrations and human social interactions over the past decades, these studies still seem far from
converging, both in methodological terms and in terms of their results.
- This systematic review and metaanalysis were aimed at a comprehensive evaluation and synthesis of empirical evidence on the relationship
between endogenous OXT concentrations and human social interactions by reviewing studies published
between 1970 and July 2020 and addressing various related methodological and analytical limitations.
- This review exposes the observed inconsistencies and suggests that
standardized, replicable, and reliable approaches to assessing social interaction and measuring OXT
concentrations need to be developed to study neurochemical mechanisms of sociality in humans.
- Public Signiﬁcance Statement
This comprehensive review and meta-analysis of studies on the relationships between endogenous
oxytocin concentration and human social interactions highlight a lack of convergence in current research
ﬁndings and consensus in their interpretation.
- This work was supported by an award from the Eunice Kennedy
Shriver National Institute of Child Health and Human Development
(NICHD) to the University of Houston for the Texas Center for Learning

Olga V.
- Over the last decade, the number of human studies on oxytocin
(OXT) has grown dramatically from 1,187 in the 1980s to 4,157 in the
2010s.1 In the 2020s, although the decade has just begun, the number
of publications has already reached 1,637 studies.2 Such an increase
cannot be explained by the general growth of the ﬁeld of hormonal
research, as another well-studied hormone, cortisol, has received
1.5 times less attention in the last decade (Figure 1).
- 527), touch-related afﬁliative processes
(Feldman, Gordon, & Schneiderman, 2010), parenting (Gordon
et al., 2017), individual sensitivity to social cues (Bartz et al.,
2011), and social motivation (Bartz et al., 2011).
- The
authors are grateful to the University of Houston students Amy Bui,
Mohammad Mahdi, Miracle Powell, and Graham Lee for their help in
screening abstracts.
- They are also grateful to Mei Tan and Lauren Elderton

Figure 1
Relative Increase in the Number of Articles Devoted to Oxytocin
and Cortisol in Humans in the 1990s, 2000s, and 2010s Compared
to the 1980s, PubMed

Note.
- Thus, the ﬁeld is now in an active development stage,
in which researchers are questioning the simplistic interpretation of
the relationships between OXT concentrations and human social
interactions.
- In comparison, the Trier
Social Stress Test is considered the gold standard for assessing
human acute psychosocial stress under laboratory conditions:
testing in this paradigm reliably induces a two- to threefold increase
in concentrations of the stress hormone cortisol in approximately
1
According to the search in PubMed, using the search term “oxytocin
[Title/Abstract]” and a ﬁlter to display only human studies.
