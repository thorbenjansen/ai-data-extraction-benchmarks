---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis."
source_note: "wiki/sources/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..md"
source_path: "raw/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis.

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..md`
- Source path: `raw/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Psychological Bulletin
© 2023 American Psychological Association
ISSN: 0033-2909

2023, Vol. 149, Nos. 9–10, 549–579
https://doi.org/10.1037/bul0000402

Endogenous Oxytocin and Human Social Interactions: A Systematic
Review and Meta-Analysis
Olga V. Burenkova1, 2, 3, Tatiana A. Dolgorukova3, Iuliia An3, Tatiana A. Kustova4,
Aleksei A. Podturkin5, Ekaterina M. Shurdova3, Oksana I. Talantseva4,
Marina A. Zhukova1, 2, 3, 4, and Elena L. Grigorenko1, 2, 3, 4, 6, 7, 8, 9, 10
1

Department of Psychology, University of Houston
Texas Institute for Measurement, Evaluation, and Statistics, University of Houston
3
Department of Psychology, Saint-Petersburg State University
4
Center for Cognitive Sciences, Sirius University of Science and Technology
5
Scientiﬁc Research Department, Moscow Zoo, Moscow, Russia
6
Department of Molecular and Human Genetics, Baylor College of Medicine, Yale University
7
Department of Pediatrics, Baylor College of Medicine, Yale University
8
Child Study Center, Yale University
9
Haskins Laboratories, Yale University
10
Research Administration, Moscow State University for Psychology and Education

This document is copyrighted by the American Psychological Association or one of its allied publishers.
This article is intended solely for the personal use of the individual user and is not to be disseminated broadly.

2

While there has been an increase in studies investigating the relationship between endogenous oxytocin
(OXT) concentrations and human social interactions over the past decades, these studies still seem far from
converging, both in methodological terms and in terms of their results. This systematic review and metaanalysis were aimed at a comprehensive evaluation and synthesis of empirical evidence on the relationship
between endogenous OXT conc

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
