# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
