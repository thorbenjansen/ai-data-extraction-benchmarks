# Read-Through Result

## Source Identity Check

- Title: Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis.
- Source PDF: `raw/Burenkova et al. - 2023 - Endogenous oxytocin and human social interactions A systematic review and meta-analysis..pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `adjacent evidence-synthesis automation evidence`

## Results Or Findings Check

extraction procedure, extraction type, sample collection method, special precautions before OXT collection, such as fasting); and (f) statistical information utilized to derive an effect size [ES]. Two authors performed data extraction independently, and were checked by a third author. If the data reported in the article were insufﬁcient to compute ESs, the publication authors were contacted twice during a given month to provide the data. If the authors did not respond to the request, but the data were present in ﬁgures, we digitized the data points using the open-source tool WebPlotDigitizer (Rohatgi, 2020). Otherwise, the article in question was excluded from the metaanalysis. We extracted three types of statistics during the extraction phase: mean differences between OXT concentrations, Pearson’s and Spearman’s correlation coefﬁcients between OXT concentrations and indicators of social interactions, and regression coefﬁcients for associations between OXT concentrations and indicators of social interactions. The ESs were estimated only for mean differences and correlation coefﬁcients; only these indices were used for further meta-analytic synthesis. We did not include regression coefﬁcients due to the high variability of the regression models used and the variables included in them, which would have added even greater heterogeneity to the analyses. Also, no data on mean differences were presented in one of the included studies (Grewen et al., 2005), and the authors did not provide them to us, although t statistics data were presented. Despite the existence of methods for conversion of t statistics into Cohen’s d, they cannot be used for a dependent or paired t test without correlation coefﬁcient r (Cooper et al., 2019, p. 216; Wilson, 2016, p. 4). We used the following formulas to calculate Hedges’ g ESs and variances for the results presented as mean differences. Hedges’ g is Cohen’s d corrected for small samples (Cumming, 2012, p. 309). We calculated Hedges’ gav using the following equation for dependent pairs of means for pre–post design and betweenconditions (control vs. interaction) design, with SDav value as a standardizer (Cumming, 2012, p. 291), taking into account the lack of correlation coefﬁcients r and other data from which they can be extracted in the vast majority of studies: Hedges’ gav =

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
