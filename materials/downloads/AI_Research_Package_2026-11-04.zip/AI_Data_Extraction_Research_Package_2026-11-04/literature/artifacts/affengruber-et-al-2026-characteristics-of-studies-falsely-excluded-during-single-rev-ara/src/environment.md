# Environment

## Source Environment

- Branch: `Sub_Branch_AI Data Extraction`
- Source note: `wiki/sources/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.md`
- Source path: `raw/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.pdf`
- Raw Markdown: `rawmarkdown_full/affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-reviewer-abstract-screening-a-meta-epidemiological-analysis.md`

## Agent Environment

This artifact was generated from local wiki/source metadata on 2026-05-04.
