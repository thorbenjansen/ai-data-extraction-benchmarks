"""Retrieval scaffold for the ARA: Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis."""
from pathlib import Path

BRANCH_ROOT = Path(__file__).resolve().parents[5]
SOURCE_NOTE = BRANCH_ROOT / "wiki" / "sources" / 'Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.md'
RAW_MARKDOWN = BRANCH_ROOT / 'rawmarkdown_full/affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-reviewer-abstract-screening-a-meta-epidemiological-analysis.md'
SOURCE_PATH = BRANCH_ROOT / 'raw/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.pdf' if True else None


def available_paths():
    paths = {"source_note": SOURCE_NOTE}
    if RAW_MARKDOWN:
        paths["raw_markdown"] = RAW_MARKDOWN
    if SOURCE_PATH:
        paths["source_path"] = SOURCE_PATH
    return {k: str(v) for k, v in paths.items() if v.exists()}
