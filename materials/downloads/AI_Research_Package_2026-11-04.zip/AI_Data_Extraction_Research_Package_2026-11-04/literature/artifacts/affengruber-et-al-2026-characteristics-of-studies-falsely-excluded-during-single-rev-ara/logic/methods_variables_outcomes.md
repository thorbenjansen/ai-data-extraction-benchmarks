# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `adjacent evidence-synthesis automation evidence`.
- Provisional design: `review`.
- Top automated-data-extraction terms in source text: screening (53), risk of bias (7), chatgpt (2), artificial intelligence (1), pico (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- BMC Medical Research Methodology

https://doi.org/10.1186/s12874-026-02838-9

Article in Press

Characteristics of studies falsely excluded during
single-reviewer abstract screening: a metaepidemiological analysis
Lisa Affengruber, Robert Emprechtinger, Emma Persad, Jos Kleijnen & Gerald
Gartlehner

Received: 3 October 2024
Accepted: 17 March 2026

Cite this article as: Affengruber L.,
Emprechtinger R., Persad E. et al.
- Characteristics of studies falsely
excluded during single-reviewer
abstract screening: a metaepidemiological analysis.
- Please
note there may be errors present which affect the content, and all legal disclaimers
apply.
- ARTICLE IN PRESS

Characteristics of studies falsely excluded during single-reviewer
abstract screening: A meta-epidemiological analysis
Lisa Affengruber1,2, lisa.affengruber@donau-uni.ac.at
Robert Emprechtinger3, robert.emprechtinger@charite.de
Emma Persad1,4, emma.persad@ki.se
Jos Kleijnen2, jos@systematic-reviews.com
Gerald Gartlehner1,5, gerald.gartlehner@donau-uni.ac.at
1.
- Understanding the
characteristics associated with falsely excluded studies can inform strategies to improve
screening processes and minimize errors.
- We examined the study,
abstract, journal, and reviewer characteristics associated with the falsely excluded abstracts.
- The characteristics examined included the study design, publication year, risk of bias, abstract

S
S
E

content, country of conduct, journal indexing, SCImago Journal & Country Rank, and
reviewer characteristics.
- Abstracts that insufficiently reported study
information (18.4%; 95% CI, 14.6%–22.8%) and study design (15.4%; 95% CI, 10.3%–
20.6%) were more often falsely excluded by reviewers than abstracts sufficiently reporting
study information (6.0%; 95% CI, 4.4%–8.3%) and study design (9.4%; 95% CI, 7.3%–
11.5%).
- These findings highlight the need for adherence to current

ARTICLE IN PRESS

reporting standards, reviewer training, and reviewer support (e.g., meetings, discussions), to
improve the accuracy of systematic reviews.
- Trial registration: https://osf.io/7xhkj
Keywords: Single screening; false exclusion of abstracts; systematic review; rapid review;
exploratory data analysis

E
L
C
I
T
R
A

IN

PR

S
S
E

ARTICLE IN PRESS

1.
- To address research questions in a timely manner, rapid
reviews often only use one reviewer to screen the literature, which has been shown to reduce
screening time by approximately 60% compared to dual independent screening (1, 2).
- However, the single-reviewer screening process is error-prone and may falsely exclude
relevant studies.
