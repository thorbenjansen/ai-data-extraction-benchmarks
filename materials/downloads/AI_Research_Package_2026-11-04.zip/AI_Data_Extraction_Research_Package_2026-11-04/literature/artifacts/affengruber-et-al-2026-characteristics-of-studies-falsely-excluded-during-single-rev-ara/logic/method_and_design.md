# Method And Design

## Source Identity

- Title: Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis
- ARA: `affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-rev-ara`
- Source PDF: `raw/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.pdf`
- Raw Markdown: `rawmarkdown_full/affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-reviewer-abstract-screening-a-meta-epidemiological-analysis.md`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `review`
- Branch role: `adjacent evidence-synthesis automation evidence`

## Data, Sample, Or Source Material

1. Background As the need for rapid evidence syntheses continues to grow, research is increasingly focused on exploring rapid review methods. To address research questions in a timely manner, rapid reviews often only use one reviewer to screen the literature, which has been shown to reduce screening time by approximately 60% compared to dual independent screening (1, 2). However, the single-reviewer screening process is error-prone and may falsely exclude relevant studies. A crowd-based randomized controlled trial (RCT) found that single-reviewer abstract screening missed 13% of relevant studies on average (3). Similarly, the authors of recent retrospective observational study reported that single-reviewer abstract screening

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

for clear visibility, including key aspects of study design, methods, and results. This structured and transparent reporting more easily enables readers to understand and evaluate a study’s methods. Therefore, the endorsement and enforcement of reporting guidelines by journals can enhance the transparency and quality of published studies, ultimately improving the screening process and minimizing the risk of excluding relevant studies. By adhering to reporting guidelines, clear and comprehensive abstracts enable reviewers to quickly assess a study’s relevance, thereby reducing the risk of false exclusions. Our findings indicate that falsely excluded abstracts often lacked sufficient reporting of the study design and general study information. This underscores the need for reviewers to exercise caution and only exclude studies if they are certain. In cases where there is uncertainty due to missing information in the abstract, it may be prudent to order the full paper for a more thorough evaluation.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
