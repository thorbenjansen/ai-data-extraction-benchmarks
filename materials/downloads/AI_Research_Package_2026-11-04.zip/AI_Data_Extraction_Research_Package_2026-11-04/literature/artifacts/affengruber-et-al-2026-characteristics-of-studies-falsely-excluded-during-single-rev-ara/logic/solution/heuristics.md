# Heuristics

- Prefer claims tied to explicit methods, metrics, or recommendations in the source.
- Treat high branch degree as retrieval priority, not as evidence quality.
- Use this source when branch concepts overlap with: AI data extraction and validation.
- For rejoinder work, check whether the source supports the main paper, commentary 1, commentary 2, or a synthesis bridge.
