# Read-Through Key Passages

## Abstract Or Opening

Characteristics of studies falsely excluded during single-reviewer abstract screening: a metaepidemiological analysis Lisa Affengruber, Robert Emprechtinger, Emma Persad, Jos Kleijnen & Gerald Gartlehner

## Methods

1. Background As the need for rapid evidence syntheses continues to grow, research is increasingly focused on exploring rapid review methods. To address research questions in a timely manner, rapid reviews often only use one reviewer to screen the literature, which has been shown to reduce screening time by approximately 60% compared to dual independent screening (1, 2). However, the single-reviewer screening process is error-prone and may falsely exclude relevant studies. A crowd-based randomized controlled trial (RCT) found that single-reviewer abstract screening missed 13% of relevant studies on average (3). Similarly, the authors of recent retrospective observational study reported that single-reviewer abstract screening

## Results Or Findings

for clear visibility, including key aspects of study design, methods, and results. This structured and transparent reporting more easily enables readers to understand and evaluate a study’s methods. Therefore, the endorsement and enforcement of reporting guidelines by journals can enhance the transparency and quality of published studies, ultimately improving the screening process and minimizing the risk of excluding relevant studies. By adhering to reporting guidelines, clear and comprehensive abstracts enable reviewers to quickly assess a study’s relevance, thereby reducing the risk of false exclusions. Our findings indicate that falsely excluded abstracts often lacked sufficient reporting of the study design and general study information. This underscores the need for reviewers to exercise caution and only exclude studies if they are certain. In cases where there is uncertainty due to missing information in the abstract, it may be prudent to order the full paper for a more thorough evaluation.

## Discussion Or Conclusion

Due to the limited evidence identified, we could not draw any firm conclusions about the characteristics that might predict a higher risk of false exclusion (9). Recognizing the characteristics that might lead to the false exclusion of studies or publications can benefit researchers conducting evidence synthesis. This awareness could enable them to approach the screening process with increased caution, especially when they encounter studies presenting potential risk factors for erroneous exclusions. The objective of our methods study was to identify characteristics on a study, abstract, journal, and reviewer level that are associated with false exclusion of studies during singlereviewer title and abstract screening.

## Limitations

the systematic review’s reliability and comprehensiveness. Implementing reviewer support, such as through clear screening forms, piloting, training, discussions, and standardized inclusion/exclusion criteria, can help mitigate false exclusion decisions. Additionally, limiting abstract screening to a maximum of three hours per day can help prevent reviewer fatigue and potentially reduce the risk of false exclusions (30). Our study has limitations. Our dataset was small and focused on specific research topics, limiting the generalizability of our findings to other research topics. Additionally, while we measured the time per decision, we could not control for external activities by the reviewers, which may have affected the accuracy of the time measurements. Further, our analysis may not have accounted for all factors that could influence the risk of false exclusions. To gain a broader understanding of the characteristics for false exclusion during screening, replicating the study using a larger dataset encompassing a wider range of study
