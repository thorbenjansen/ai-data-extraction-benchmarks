# Source Grounding Table

| Field | Value |
|---|---|
| Source title | Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis |
| Source note | wiki/sources/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.md |
| Source path | raw/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.pdf |
| Raw Markdown | rawmarkdown_full/affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-reviewer-abstract-screening-a-meta-epidemiological-analysis.md |
| Grounding status | full_markdown |
| Branch degree | 7 |
| Incoming links | 0 |
| Outgoing links | 7 |
| Study kind | empirical-primary |
| Study method | applied-methods-study |
| Article role | supporting-rejoinder-evidence |
