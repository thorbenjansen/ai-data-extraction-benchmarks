# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.pdf` |
| Raw Markdown | `rawmarkdown_full/affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-reviewer-abstract-screening-a-meta-epidemiological-analysis.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `review` |
| Branch role | `adjacent evidence-synthesis automation evidence` |
| Top terms | screening (53), risk of bias (7), chatgpt (2), artificial intelligence (1), pico (1) |
| Verification status | Needs human source-checking before exact citation |
