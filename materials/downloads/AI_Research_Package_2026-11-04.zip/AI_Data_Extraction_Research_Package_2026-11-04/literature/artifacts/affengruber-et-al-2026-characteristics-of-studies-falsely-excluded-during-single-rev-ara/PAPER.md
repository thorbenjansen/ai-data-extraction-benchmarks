---
type: agent_native_research_artifact
date: 2026-05-04
source_title: "Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis"
source_note: "wiki/sources/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.md"
source_path: "raw/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.pdf"
rawmarkdown_path: "rawmarkdown_full/affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-reviewer-abstract-screening-a-meta-epidemiological-analysis.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
ranking_degree: 7
ranking_incoming: 0
ranking_outgoing: 7
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis

## Retrieval Contract

Use this ARA as the first agent-facing layer for the source, then verify important claims against `evidence/README.md`, `the PDF/source note pointer`, and the branch source note `wiki/sources/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.md`.

## Source Grounding

- Source note: `wiki/sources/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.md`
- Source path: `raw/Affengruber et al. - 2026 - Characteristics of studies falsely excluded during single-reviewer abstract screening a meta-epidemiological analysis.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/affengruber-et-al-2026-characteristics-of-studies-falsely-excluded-during-single-reviewer-abstract-screening-a-meta-epidemiological-analysis.md`
- Grounding status: `full_markdown`
- Branch graph rank signal: degree 7 = 0 incoming + 7 outgoing links.

## Abstracted Contribution

This article-in-press analyzes a screening-decision dataset to examine which study, abstract, journal, and reviewer characteristics are associated with false exclusions during single-reviewer abstract screening. The paper frames abstract screening as a crucial but error-prone stage of evidence synthesis and argues that understanding the profile of missed studies can inform safer and more efficient screening...

## Branch Use

This artifact was generated for the Top-20 connected-paper pass. It is designed for retrieval, rejoinder drafting, and source triage, not as a substitute for checking the PDF or full Markdown when making exact empirical claims.

## Main Ideas

- Single-reviewer abstract screening can wrongly exclude relevant studies, and those errors are patterned rather than purely random.
- Meta-epidemiological analysis can identify characteristics associated with false exclusions and thereby inform safer screening strategies.
- The study contributes to the evidence base on when evidence-synthesis automation may require stronger verification and human oversight.

## Key Claims

- C01: The source is highly connected in the branch graph with degree 7 (0 incoming, 7 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: This article-in-press analyzes a screening-decision dataset to examine which study, abstract, journal, and reviewer characteristics are associated with false exclusions during single-reviewer abstract screening. The paper frames abstract screening as a crucial but error-prone stage of evidence synthesis and argues that understanding the profile of missed studies can inform safer and more efficient screening...
- C03: The source note classifies the work as empirical-primary using applied-methods-study, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.
