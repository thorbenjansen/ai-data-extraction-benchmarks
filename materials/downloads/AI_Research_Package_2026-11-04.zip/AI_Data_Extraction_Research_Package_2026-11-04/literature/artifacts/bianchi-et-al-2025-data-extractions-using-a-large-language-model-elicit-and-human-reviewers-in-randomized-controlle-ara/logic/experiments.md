# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Bianchi et al. - 2025 - Data Extractions Using a Large Language Model (Elicit) and Human Reviewers in Randomized Controlled.pdf`.
- Raw Markdown path: `not available`.
