# Problem

This ARA preserves a branch-local retrieval entry point for `Bianchi et al. - 2025 - Data Extractions Using a Large Language Model (Elicit) and Human Reviewers in Randomized Controlled`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
