# Concepts

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[LLM Accuracy]]
