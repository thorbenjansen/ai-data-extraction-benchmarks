# Source Scope

## Strong Uses

- Use as `direct automated-data-extraction evidence` in the AI Data Extraction branch.
- Use for retrieval around data extraction, artificial intelligence, large language model, chatgpt, screening.

## Weak Uses

- Do not treat this automated ARA as citation-grade for exact numbers without checking the PDF.
- Do not infer model superiority from abstract-level claims alone.
- Do not treat human-AI agreement or model confidence as validation unless the source itself defines and tests that standard.

## Transfer Boundaries

- Domain, document type, extraction target, model/tool version, and human adjudication design may limit transfer to the main AI data extraction paper.

## Citation-Grade Verification Needs

- Re-open `raw/Bianchi et al. - 2025 - Data Extractions Using a Large Language Model (Elicit) and Human Reviewers in Randomized Controlled.pdf`.
- Confirm the exact extraction task and evaluation metric.
- Confirm whether the source evaluates data extraction specifically or an adjacent task such as screening, annotation, risk-of-bias, or literature search.
