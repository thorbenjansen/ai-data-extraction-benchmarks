# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `protocol`.
- Top automated-data-extraction terms in source text: data extraction (33), artificial intelligence (6), large language model (2), chatgpt (2), screening (2), generative ai (1), machine learning tools (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Cochrane Evidence Synthesis and Methods

BRIEF REPORT

Data Extractions Using a Large Language Model (Elicit)
and Human Reviewers in Randomized Controlled Trials:
A Systematic Comparison
Joleen Bianchi1,2 | Julian Hirt1,3,4

| Magdalena Vogt1

| Janine Vetsch1

1

Department of Health, Eastern Switzerland University of Applied Sciences, St.
- Keywords: artificial intelligence | data extraction | human reviewer | randomized controlled trial | systematic review

ABSTRACT
Aim: We aimed at comparing data extractions from randomized controlled trials by using Elicit and human reviewers.
- However, the tool's performance and accuracy have not been independently assessed.
- Methods: For comparison, we sampled 20 randomized controlled trials of which data were extracted manually from a human
reviewer.
- Variables like “intervention
effect” or “intervention” may require a human reviewer to complete the data extraction.
- Our results suggest that verification by
human reviewers is necessary to ensure that all relevant information is captured completely and correctly by Elicit.
- Data extraction process may be facilitated by artificial intelligence tools.
- Use of Elicit may require a human reviewer to double‐check the extracted data.
- Cochrane Evidence Synthesis and Methods published by John Wiley & Sons Ltd on behalf of The Cochrane Collaboration.
- Cochrane Evidence Synthesis and Methods, 2025; 3:e70033
https://doi.org/10.1002/cesm.70033

1 of 6

2 | Background
There is an AI research tool called “Elicit” which, in comparison to manual data extraction by trained research staff, demonstrated an accuracy that was 13%–26% higher (Elicit).
- However, this accuracy data were conducted and reported by
Elicit and there is—to the best of our knowledge—no full
independent research report on Elicit's accuracy.
- Elicit leverages large language models, including GPT‐3, to automate
research workflows.
