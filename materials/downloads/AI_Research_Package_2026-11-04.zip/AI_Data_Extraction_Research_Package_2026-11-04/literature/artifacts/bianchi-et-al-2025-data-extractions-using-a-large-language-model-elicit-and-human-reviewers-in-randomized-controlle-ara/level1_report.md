# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Bianchi et al. - 2025 - Data Extractions Using a Large Language Model (Elicit) and Human Reviewers in Randomized Controlled.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Bianchi et al. - 2025 - Data Extractions Using a Large Language Model (Elicit) and Human Reviewers in Randomized Controlled.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
