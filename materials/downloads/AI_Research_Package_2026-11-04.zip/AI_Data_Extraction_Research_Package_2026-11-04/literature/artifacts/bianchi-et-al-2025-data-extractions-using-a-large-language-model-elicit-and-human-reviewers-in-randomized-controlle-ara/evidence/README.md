# Evidence README

## Source Pointer

- PDF: `raw/Bianchi et al. - 2025 - Data Extractions Using a Large Language Model (Elicit) and Human Reviewers in Randomized Controlled.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Cochrane Evidence Synthesis and Methods

BRIEF REPORT

Data Extractions Using a Large Language Model (Elicit)
and Human Reviewers in Randomized Controlled Trials:
A Systematic Comparison
Joleen Bianchi1,2 | Julian Hirt1,3,4

| Magdalena Vogt1

| Janine Vetsch1

1

Department of Health, Eastern Switzerland University of Applied Sciences, St. Gallen, Switzerland | 2Interdisciplinary Infant Unit, Eastern Switzerland
Children's Hospital, St. Gallen, Switzerland | 3Pragmatic Evidence Lab, Research Center for Clinical Neuroimmunology and Neuroscience Basel (RC2NB),
University Hospital Basel, University of Basel, Basel, Switzerland | 4Institute of Health and Nursing Science, Medical Faculty, Martin Luther University Halle‐
Wittenberg, Halle (Saale), Germany
Correspondence: Janine Vetsch (Janine.vetsch@ost.ch)
Received: 13 February 2025 | Revised: 20 May 2025 | Accepted: 21 May 2025
Funding: The authors received no specific funding for this work.
Keywords: artificial intelligence | data extraction | human reviewer | randomized controlled trial | systematic review

ABSTRACT
Aim: We aimed at comparing data extractions from randomized controlled trials by using Elicit and human reviewers.
Background: Elicit is an artificial intelligence tool which may automate specific steps in conducting systematic reviews.
However, the tool's performance and accuracy have not been independently assessed.
Methods: For comparison, we sampled 20 randomized controlled trials of which data were extracted manually from a human
reviewer. We assessed the variables study objectives, sample characteristics and size, study design, interventions, outcome measured,
and intervention effects and classified the results into “more,” “equal to,” “partially equal,” and “deviating” extractions. STROBE
checklist was
