# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Bianchi et al. - 2025 - Data Extractions Using a Large Language Model (Elicit) and Human Reviewers in Randomized Controlled.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `protocol` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | data extraction (33), artificial intelligence (6), large language model (2), chatgpt (2), screening (2), generative ai (1), machine learning tools (1) |
| Verification status | Needs human source-checking before exact citation |
