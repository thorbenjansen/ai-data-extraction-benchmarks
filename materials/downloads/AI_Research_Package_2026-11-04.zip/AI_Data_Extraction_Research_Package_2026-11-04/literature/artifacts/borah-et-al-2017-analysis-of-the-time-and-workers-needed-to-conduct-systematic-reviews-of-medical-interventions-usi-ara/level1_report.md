# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
