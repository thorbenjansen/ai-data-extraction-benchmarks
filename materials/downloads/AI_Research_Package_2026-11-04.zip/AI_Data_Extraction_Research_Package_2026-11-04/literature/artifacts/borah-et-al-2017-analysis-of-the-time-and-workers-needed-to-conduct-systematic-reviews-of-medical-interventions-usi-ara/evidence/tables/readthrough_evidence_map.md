# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `protocol` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | data extraction (4), screening (3), pico (2) |
| Verification status | Needs human source-checking before exact citation |
