# Evidence README

## Source Pointer

- PDF: `raw/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Research

Analysis of the time and workers
needed to conduct systematic reviews
of medical interventions using data
from the PROSPERO registry
Rohit Borah,1,2 Andrew W Brown,2,3 Patrice L Capers,2,3 Kathryn A Kaiser2,3

To cite: Borah R, Brown AW,
Capers PL, et al. Analysis of
the time and workers needed
to conduct systematic
reviews of medical
interventions using data from
the PROSPERO registry. BMJ
Open 2017;7:e012545.
doi:10.1136/bmjopen-2016012545
▸ Prepublication history and
additional material is
available. To view please visit
the journal (http://dx.doi.org/
10.1136/bmjopen-2016012545).

Received 5 May 2016
Revised 21 October 2016
Accepted 25 October 2016

1

Science and Technology
Honors Program, University
of Alabama at Birmingham,
Birmingham, Alabama, USA
2
Office of Energetics, Dean’s
Office, School of Public
Health, University of Alabama
at Birmingham, Birmingham,
Alabama, USA
3
Nutrition Obesity Research
Center, University of Alabama
at Birmingham, Birmingham,
Alabama, USA
Correspondence to
Dr Kathryn A Kaiser;
kakaiser@uab.edu

ABSTRACT
Objectives: To summarise logistical aspects of recently
completed systematic reviews that were registered in the
International Prospective Register of Systematic Reviews
(PROSPERO) registry to quantify the time and resources
required to complete such projects.
Design: Meta-analysis.
Data sources and study selection: All of the 195
registered and completed reviews (status from the
PROSPERO registry) with associated publications at the
time of our search (1 July 2014).
Data extraction: All authors extracted data using
registry entries and publication information related to the
data sources used, the number of initially retrieved
citations, the final number of included studies, the time
between registration date to publication
