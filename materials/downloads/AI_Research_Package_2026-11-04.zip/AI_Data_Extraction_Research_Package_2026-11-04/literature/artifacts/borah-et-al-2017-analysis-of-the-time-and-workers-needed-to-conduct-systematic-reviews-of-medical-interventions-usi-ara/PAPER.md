---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using"
source_note: "wiki/sources/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.md"
source_path: "raw/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.md`
- Source path: `raw/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Research

Analysis of the time and workers
needed to conduct systematic reviews
of medical interventions using data
from the PROSPERO registry
Rohit Borah,1,2 Andrew W Brown,2,3 Patrice L Capers,2,3 Kathryn A Kaiser2,3

To cite: Borah R, Brown AW,
Capers PL, et al. Analysis of
the time and workers needed
to conduct systematic
reviews of medical
interventions using data from
the PROSPERO registry. BMJ
Open 2017;7:e012545.
doi:10.1136/bmjopen-2016012545
▸ Prepublication history and
additional material is
available. To view please visit
the journal (http://dx.doi.org/
10.1136/bmjopen-2016012545).

Received 5 May 2016
Revised 21 October 2016
Accepted 25 October 2016

1

Science and Technology
Honors Program, University
of Alabama at Birmingham,
Birmingham, Alabama, USA
2
Office of Energetics, Dean’s
Office, School of Public
Health, University of Alabama
at Birmingham, Birmingham,
Alabama, USA
3
Nutrition Obesity Research
Center, University of Alabama
at Birmingham, Birmingham,
Alabama, USA
Correspondence to
Dr Kathryn A Kaiser;
kakaiser@uab.edu

ABSTRACT
Objectives: To summarise logistical aspects of recently
completed systematic reviews that were registered in the
International Prospective Register of Systematic Reviews
(PROSPERO) registry to quantify the time and resources
required to complete such projects.
Design: Meta-analysis.
Data sources and study selection: All of the 195
registered and completed reviews (status from the
PROSPERO registry) with associated publications at the
time of our search (1 July 2014).
Data extraction: All authors extracted data using
registry entries and publication information related to the
data sources used, the number of initially retrieved
citations, the final number of included studies, the time
between registration date to publication

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Speed-Accuracy Tradeoff]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
