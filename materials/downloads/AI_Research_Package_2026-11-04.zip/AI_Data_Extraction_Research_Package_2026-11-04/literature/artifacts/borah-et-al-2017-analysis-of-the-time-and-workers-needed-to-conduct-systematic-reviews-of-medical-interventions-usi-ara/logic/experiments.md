# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using.pdf`.
- Raw Markdown path: `not available`.
