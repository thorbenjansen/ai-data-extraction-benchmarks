# Problem

This ARA preserves a branch-local retrieval entry point for `Borah et al. - 2017 - Analysis of the time and workers needed to conduct systematic reviews of medical interventions using`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
