# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `protocol`.
- Top automated-data-extraction terms in source text: data extraction (4), screening (3), pico (2).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Data extraction: All authors extracted data using
registry entries and publication information related to the
data sources used, the number of initially retrieved
citations, the final number of included studies, the time
between registration date to publication date and number
of authors involved for completion of each publication.
- Conclusions: Systematic reviews presently take much
time and require large amounts of human resources.
- Although an audit trail is available
for each PROSPERO record, there is no way to verify the
completeness or accuracy of the entries or whether the
registrants created the ﬁles early in the timeline of the
project as prescribed by the registry administrators.
- Additionally, this registry is not equipped to verify the
completeness or accuracy of the entries as compared
with the resultant publication.
- Means (reported as
funded vs funding
not reported)

Yes
No

42 vs 26 weeks
68 vs 64 weeks

Yes
No

6.8 vs 4.8 persons
6.0 vs 5.7 persons

determine inclusion and exclusion criteria, conduct preliminary searches to reﬁne the search syntax, perform
inter-rater reliability for literature screening, and obtain
funding (if the review is speciﬁcally funded).
- Further constraining the present conclusions, the
PROSPERO registry does not currently function as a
day-to-day project diary or require answers to detailed
questions about methods such as the use of automated
text screening or data extraction approaches that may
affect the timeline or people required.
- Others who have
evaluated the use of text mining13 and automated data
extraction14 report that these methods may have some
utility in certain types of reviews (eg, scoping), but more
work is needed to provide signiﬁcant reductions in work
required by humans.
- These authors found a 47% difference in
the number of studies in the paired reviews (excluding
individual trials included in both reviews) unaccounted
for by order of publication.17 One potential source of
search differences may be the use of Medical Subject
Headings (MeSH), which were introduced in 1963.18
Although this system is still able to provide a list of articles on a topic of interest, it is not designed to meet the
needs of today’s clinicians or systematic reviewers.
- We suggest that human clinical
trials could be a starting point for testing the use of
indexing systems that employ a Population, Intervention,
Comparisons, Outcomes, Study Design (PICOS)15 structure of coding metadata for clinical trials in order to
make the scientiﬁc literature become a truly searchable
database.
- In a brighter future,
evidence-based, up-to-date summaries could be produced on demand with less human effort and may
reduce the delay between the question and the
evidence-based answer.
- The authors are also grateful to the reviewers for their helpful
comments and suggestions.
- Pinpointing needles in giant
haystacks: use of text mining to reduce impractical screening
workload in extremely large scoping reviews.
