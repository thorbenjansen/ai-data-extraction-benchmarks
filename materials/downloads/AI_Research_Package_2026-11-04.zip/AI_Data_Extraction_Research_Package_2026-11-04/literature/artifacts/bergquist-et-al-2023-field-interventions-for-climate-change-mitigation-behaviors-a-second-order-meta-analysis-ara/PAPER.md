---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis"
source_note: "wiki/sources/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.md"
source_path: "raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.md`
- Source path: `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

RESEARCH ARTICLE

| SUSTAINABILITY SCIENCE

OPEN ACCESS

Field interventions for climate change mitigation behaviors:
A second-order meta-analysis
Magnus Bergquista,1, Maximilian Thiela, Matthew H. Goldbergb

, and Sander van der Lindenc

Edited by Elke Weber, Princeton University, Princeton, NJ; received August 30, 2022; accepted January 27, 2023

Downloaded from https://www.pnas.org by 134.245.76.71 on December 11, 2025 from IP address 134.245.76.71.

Behavioral change is essential to mitigate climate change. To advance current knowledge,
we synthesize research on interventions aiming to promote climate change mitigation
behaviors in field settings. In a preregistered second-order meta-analysis, we assess the
overall effect of 10 meta-analyses, incorporating a total of 430 primary studies. In
addition, we assess subgroup analyses for six types of interventions, five behaviors,
and three publication bias adjustments. Results showed that climate change mitigation
interventions were generally effective (dunadjusted = 0.31, 95% CI [0.30, 0.32]). A follow-up
analysis using only unique primary studies, adjusted for publication bias, provides a
more conservative overall estimate (d = 0.18, 95% CI [0.13, 0.24]). This translates
into a mean treatment effect of 7 percentage points. Furthermore, in a subsample of
adequately powered large-scale interventions (n > 9,000, k = 32), the effect was adjusted
downward to approximately 2 percentage points. This discrepancy might be because
large-scale interventions often target nonvoluntary participants by less direct techniques
(e.g., “home energy reports”) while small-scale interventions often target voluntary participants by more direct techniques (e.g., face-to-face interactions). Subgroup analyses
showed that interventions based on

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
