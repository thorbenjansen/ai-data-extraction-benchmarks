# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `needs-further-coding` |
| Branch role | `background meta-research or synthesis-methods evidence` |
| Top terms | data extraction (1), screening (1) |
| Verification status | Needs human source-checking before exact citation |
