# Evidence README

## Source Pointer

- PDF: `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

RESEARCH ARTICLE

| SUSTAINABILITY SCIENCE

OPEN ACCESS

Field interventions for climate change mitigation behaviors:
A second-order meta-analysis
Magnus Bergquista,1, Maximilian Thiela, Matthew H. Goldbergb

, and Sander van der Lindenc

Edited by Elke Weber, Princeton University, Princeton, NJ; received August 30, 2022; accepted January 27, 2023

Downloaded from https://www.pnas.org by 134.245.76.71 on December 11, 2025 from IP address 134.245.76.71.

Behavioral change is essential to mitigate climate change. To advance current knowledge,
we synthesize research on interventions aiming to promote climate change mitigation
behaviors in field settings. In a preregistered second-order meta-analysis, we assess the
overall effect of 10 meta-analyses, incorporating a total of 430 primary studies. In
addition, we assess subgroup analyses for six types of interventions, five behaviors,
and three publication bias adjustments. Results showed that climate change mitigation
interventions were generally effective (dunadjusted = 0.31, 95% CI [0.30, 0.32]). A follow-up
analysis using only unique primary studies, adjusted for publication bias, provides a
more conservative overall estimate (d = 0.18, 95% CI [0.13, 0.24]). This translates
into a mean treatment effect of 7 percentage points. Furthermore, in a subsample of
adequately powered large-scale interventions (n > 9,000, k = 32), the effect was adjusted
downward to approximately 2 percentage points. This discrepancy might be because
large-scale interventions often target nonvoluntary participants by less direct techniques
(e.g., “home energy reports”) while small-scale interventions often target voluntary participants by more direct techniques (e.g., face-to-face interactions). Subgroup analyses
showed that interventions based on
