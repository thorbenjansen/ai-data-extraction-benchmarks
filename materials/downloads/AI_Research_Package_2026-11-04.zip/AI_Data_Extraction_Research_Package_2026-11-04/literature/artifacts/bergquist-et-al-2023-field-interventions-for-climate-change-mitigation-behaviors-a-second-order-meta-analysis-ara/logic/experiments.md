# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf`.
- Raw Markdown path: `not available`.
