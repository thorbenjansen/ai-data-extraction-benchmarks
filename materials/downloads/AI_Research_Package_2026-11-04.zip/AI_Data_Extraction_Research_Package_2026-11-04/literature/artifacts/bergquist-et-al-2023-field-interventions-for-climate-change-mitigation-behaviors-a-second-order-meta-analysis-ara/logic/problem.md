# Problem

This ARA preserves a branch-local retrieval entry point for `Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
