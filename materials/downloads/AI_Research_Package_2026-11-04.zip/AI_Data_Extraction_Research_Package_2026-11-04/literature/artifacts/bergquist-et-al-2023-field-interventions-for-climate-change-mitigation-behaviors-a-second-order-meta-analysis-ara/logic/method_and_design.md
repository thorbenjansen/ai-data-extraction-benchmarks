# Method And Design

## Source Identity

- Title: Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis
- ARA: `bergquist-et-al-2023-field-interventions-for-climate-change-mitigation-behaviors-a-second-order-meta-analysis-ara`
- Source PDF: `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `needs-further-coding`
- Branch role: `background meta-research or synthesis-methods evidence`

## Data, Sample, Or Source Material

Journal of Environmental Psychology, Environment and Behavior, Sustainability, Frontiers in Psychology, Appetite, Journal of Environmental Education, Environmental Education Research, Transportation, Transportation Research, Transportation Policy, Energy Policy, Journal of Consumer Policy, Journal of Social Issues, Journal of Applied Social Psychology, Global Environmental Change, Psychological Bulletin, Journal of Applied Communications, Nature Sustainability, Renewable and Sustainable Energy Reviews, Nature communications, Nature Climate Change, Nature Energy, Frontiers in Communication Data Screening and Assessing Study Overlap. First, we excluded all hits that did not include either of the “methods” search terms (e.g., meta-analy*) in the title, abstract, or keywords. Second, all remaining hits were blindly assessed for eligibility by two researchers using criteria 2 to 5. The interrater reliability showed strong agreement (Cohen’s Kappa = 0.996). Six conflicting cases were resolved by a discussion based on the eligibility criteria. Third, for all studies not providing adequate data, the first author was contacted and asked for the missing data and/ or raw data. In five cases, we could not access either of these, and therefore these studies were excluded. Fourth, we followed the recommendations by Hennessy and Johnson (72) for addressing study overlap. Initially, we calculated the corrected covered area (CCA) for the entire matrix of included primary studies (73). The CCA represents the degree of study overlap between included meta-analyses and can range from 0 to 100%. The initial CCA was 4%, which can be interpreted as a slight overlap (for the formula, see SI Appendix, Appendix B). However, the overall CCA may conceal a large overlap between two individual meta-analyses that examined, for example, the same outcome variable. Therefore, we calculated the CCA between each pair of meta-analyses sharing more than one primary article. We used the recommendations by Pieper et al. (73) and excluded studies with an overlap of over 15%. This led to the exclusion of three articles. Importantly, the CCA has some methodological limitations, as it does not take the added value of a meta-analysis into account and is highly dependent on the number of included studies. We, therefore, computed a complementary measure of overlap, assessing the unique contribution of eac

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

contributed more than 25% of unique primary studies. This procedure led to the exclusion of another four meta-analyses. In addition, we examined how robust our results are to study overlap by limiting overlap to less than 50%. An overview of the exclusion process is given in Fig. 2. Data Extraction. For each meta-analysis included in this second-order meta-anal-

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
