# Claims

- C01: `Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf`.
