# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `background meta-research or synthesis-methods evidence`.
- Provisional design: `needs-further-coding`.
- Top automated-data-extraction terms in source text: data extraction (1), screening (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- These results
provide a comprehensive
state-of-the-art summary of
climate change mitigation
interventions, guiding both
future research and practice.

intervention | climate change mitigation | pro-environmental behavior | meta-analysis | synthesis

Climate change is worsening extreme weather events, causing loss of biodiversity, and
threatening human health.
- Human behavioral change is essential to mitigate climate change.
- The proportion of the observed variance accounted for by the
second-order sampling error was approaching zero (proportion of
true variance (ProVar) < 0.001), meaning that differences in effect
sizes across meta-analyses cannot be explained by sampling error
alone, but are likely driven by moderating factors.
- See Appendix for 7) observed variance across first-order mean
standardized difference estimates; 8) expected second-order sampling error variance; 9) estimated true variance across first-order mean standardized difference estimates (expected
sampling error variance removed).
- Thus, the estimate of the population variance of the uncorrected
mean differences equals the weighted variance of the mean differences minus the
expected second-order sampling error across(first-order
) meta-analyses (20).
- Our second aim was to model the variance between the included first-order
meta-analyses that is attributable to second-order sampling error, which can be
calculated as:
� �
m
= ∑m .
- First-order meta-analyses reduce sampling error by integrating
effect sizes across different primary studies.
- However, the amount of included primary studies is limited and thus, the sampling error will never reach zero (83).
- The
goal of a second-order meta-analysis is to calculate this remaining sampling error,
the so-called second-order sampling error.
- As second-order meta-analyses compute how much of the variance between
effect sizes of first-order meta-analyses is due to sampling error or systematic variance,
they can reveal the existence of possible moderators between meta-analyses (20).
- In bare-bones meta-analyses,
the sampling error is the only artifact that is corrected for within the first-order

8 of 10

https://doi.org/10.1073/pnas.2214851120

The second-order sampling error can be estimated by dividing the number
of meta-analyses by the sum of the weight applied to each meta-analysis.
- Using
these estimates, the proportion of the observed variance accounted for by the second-order sampling error was calculated by dividing the expected second-order
sampling error by the weighted variance of the mean differences (20):
( )
E Se2
̂
di
ProportionVar =
.
