# Read-Through Result

## Source Identity Check

- Title: Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis
- Source PDF: `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `needs-further-coding`
- Branch role: `background meta-research or synthesis-methods evidence`

## Results Or Findings Check

contributed more than 25% of unique primary studies. This procedure led to the exclusion of another four meta-analyses. In addition, we examined how robust our results are to study overlap by limiting overlap to less than 50%. An overview of the exclusion process is given in Fig. 2. Data Extraction. For each meta-analysis included in this second-order meta-anal-

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
