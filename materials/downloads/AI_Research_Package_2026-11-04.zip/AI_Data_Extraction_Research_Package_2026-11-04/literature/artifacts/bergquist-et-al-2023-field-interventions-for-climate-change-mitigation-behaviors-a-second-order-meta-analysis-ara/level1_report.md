# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Bergquist et al. - 2023 - Field interventions for climate change mitigation behaviors A second-order meta-analysis.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
