# Read-Through Result

## Source Identity Check

- Title: Calvert - 2025 - Principles and Framework for the Operationalisation of Meaningful Human Control Over Autonomous Syst
- Source PDF: `raw/Calvert - 2025 - Principles and Framework for the Operationalisation of Meaningful Human Control Over Autonomous Syst.pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `guidance/framework`
- Branch role: `branch-adjacent context`

## Results Or Findings Check

Science and Engineering Ethics (2025) 31:27
https://doi.org/10.1007/s11948-025-00554-z
ORIGINAL RESEARCH/SCHOLARSHIP

Principles and Framework for the Operationalisation of
Meaningful Human Control Over Autonomous Systems
Simeon C. Calvert1
Received: 23 September 2024 / Accepted: 4 August 2025 / Published online: 24 September 2025
© The Author(s) 2025

Abstract
With a plethora of different seemingly diverging expansions for use of Meaningful
Human Control (MHC) in practice, this paper proposes an alignment for the operationalisation of MHC for autonomous systems by proposing operational principles
for MHC and introducing a generic framework for its application. The increasing
integration of autonomous systems in various domains emphasises a critical need to
maintain human control to ensure responsible safety, accountability, and ethical operation of these systems. The concept of MHC offers an ideal concept for the design
and evaluation of human control over autonomous systems, while considering human and technology capabilities.

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
