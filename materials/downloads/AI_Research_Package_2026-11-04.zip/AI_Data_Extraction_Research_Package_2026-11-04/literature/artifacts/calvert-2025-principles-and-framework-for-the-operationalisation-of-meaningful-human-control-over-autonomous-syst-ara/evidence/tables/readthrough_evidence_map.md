# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Calvert - 2025 - Principles and Framework for the Operationalisation of Meaningful Human Control Over Autonomous Syst.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `guidance/framework` |
| Branch role | `branch-adjacent context` |
| Top terms | artificial intelligence (14) |
| Verification status | Needs human source-checking before exact citation |
