# Evidence README

## Source Pointer

- PDF: `raw/Calvert - 2025 - Principles and Framework for the Operationalisation of Meaningful Human Control Over Autonomous Syst.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Science and Engineering Ethics (2025) 31:27
https://doi.org/10.1007/s11948-025-00554-z
ORIGINAL RESEARCH/SCHOLARSHIP

Principles and Framework for the Operationalisation of
Meaningful Human Control Over Autonomous Systems
Simeon C. Calvert1
Received: 23 September 2024 / Accepted: 4 August 2025 / Published online: 24 September 2025
© The Author(s) 2025

Abstract
With a plethora of different seemingly diverging expansions for use of Meaningful
Human Control (MHC) in practice, this paper proposes an alignment for the operationalisation of MHC for autonomous systems by proposing operational principles
for MHC and introducing a generic framework for its application. The increasing
integration of autonomous systems in various domains emphasises a critical need to
maintain human control to ensure responsible safety, accountability, and ethical operation of these systems. The concept of MHC offers an ideal concept for the design
and evaluation of human control over autonomous systems, while considering human and technology capabilities. Through conceptual synthesis of existing literature
and investigation across various domains and related concepts, principles for the
operationalisation of MHC are set out to provide tangible guidelines for researchers
and practitioners aiming to implement MHC in their systems. The proposed framework dissects generic components of systems and their subsystems aligned with
different agents, stakeholders and processes at different levels of proximity to an
autonomous technology. The framework is domain-agnostic, emphasizing the universal applicability of the MHC principles irrespective of the technological context,
paving the way for safer and more responsible autonomous systems.
Keywords Meaningful human control · Autonomous systems · Human-machi
