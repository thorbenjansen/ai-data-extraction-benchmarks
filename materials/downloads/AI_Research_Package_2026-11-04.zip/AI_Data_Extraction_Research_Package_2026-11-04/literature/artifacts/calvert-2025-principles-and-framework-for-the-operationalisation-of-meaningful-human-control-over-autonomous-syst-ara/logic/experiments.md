# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Calvert - 2025 - Principles and Framework for the Operationalisation of Meaningful Human Control Over Autonomous Syst.pdf`.
- Raw Markdown path: `not available`.
