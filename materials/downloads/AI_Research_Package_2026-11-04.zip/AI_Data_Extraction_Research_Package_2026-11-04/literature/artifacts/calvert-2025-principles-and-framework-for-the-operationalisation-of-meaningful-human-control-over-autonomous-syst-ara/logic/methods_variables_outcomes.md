# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `branch-adjacent context`.
- Provisional design: `guidance/framework`.
- Top automated-data-extraction terms in source text: artificial intelligence (14).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Science and Engineering Ethics (2025) 31:27
https://doi.org/10.1007/s11948-025-00554-z
ORIGINAL RESEARCH/SCHOLARSHIP

Principles and Framework for the Operationalisation of
Meaningful Human Control Over Autonomous Systems
Simeon C.
- Calvert1
Received: 23 September 2024 / Accepted: 4 August 2025 / Published online: 24 September 2025
© The Author(s) 2025

Abstract
With a plethora of different seemingly diverging expansions for use of Meaningful
Human Control (MHC) in practice, this paper proposes an alignment for the operationalisation of MHC for autonomous systems by proposing operational principles
for MHC and introducing a generic framework for its application.
- The increasing
integration of autonomous systems in various domains emphasises a critical need to
maintain human control to ensure responsible safety, accountability, and ethical operation of these systems.
- The concept of MHC offers an ideal concept for the design
and evaluation of human control over autonomous systems, while considering human and technology capabilities.
- Keywords Meaningful human control · Autonomous systems · Human-machine
interaction · Ethical AI

Simeon C.
- Calvert

Introduction
Autonomous systems interacting with humans and performing highly complex tasks
are on the increase and are expected to increase in dominance in society.
- Meaningful Human Control (MHC) is a concept
that describes how humans can exert control over an autonomous system even when
they are not in operational control.
- There is a premise
that autonomous systems should adhere to MHC-like norms, which are necessary to
uphold a balance of human moral responsibility, accountability, and ethical governance over autonomous systems.
- This ensures transparency, safety, and alignment
with human values while preventing harm and legal responsibility gaps, but requires
further steps towards operationalisation for use in practice.
- The framework allows industry
and scientific stakeholders alike to further detail the required conditions to the context of their systems’ applications to ensure safe and humanly acceptable behaviour
of autonomy and adhere to the three pillars of accountability, responsibility and
transparency.
- It prescribes the conditions
for a relationship between controlling human agents and a controlled autonomous
system that preserves moral responsibility and clear human accountability even in
the absence of any specific form of human operational.
- Santoni de Sio & Van den
Hoven (2018) distinguish two key conditions for human control to be meaningful,
namely the tracing and tracking conditions.
