# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Calvert - 2025 - Principles and Framework for the Operationalisation of Meaningful Human Control Over Autonomous Syst.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Calvert - 2025 - Principles and Framework for the Operationalisation of Meaningful Human Control Over Autonomous Syst.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
