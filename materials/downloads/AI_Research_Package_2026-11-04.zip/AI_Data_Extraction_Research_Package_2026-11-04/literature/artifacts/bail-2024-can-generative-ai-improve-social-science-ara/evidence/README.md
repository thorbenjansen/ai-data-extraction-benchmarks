# Evidence README

## Source Pointer

- PDF: `raw/Bail - 2024 - Can Generative AI improve social science.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

OPEN ACCESS

PERSPECTIVE

Can Generative AI improve social science?
Christopher A. Baila,b,c,1
Edited by David Lazer, Northeastern University, Boston, MA; received September 7, 2023; accepted April 5, 2024, by Editorial Board Member

Downloaded from https://www.pnas.org by 134.245.76.71 on December 11, 2025 from IP address 134.245.76.71.

Mark Granovetter

Generative AI that can produce realistic text, images,
and other human-like outputs is currently transforming
many different industries. Yet it is not yet known how
such tools might influence social science research. I argue
Generative AI has the potential to improve survey research, online experiments, automated content analyses,
agent-based models, and other techniques commonly
used to study human behavior. In the second section of
this article, I discuss the many limitations of Generative
AI. I examine how bias in the data used to train these
tools can negatively impact social science research—as
well as a range of other challenges related to ethics,
replication, environmental impact, and the proliferation
of low-quality research. I conclude by arguing that social
scientists can address many of these limitations by creating open-source infrastructure for research on human
behavior. Such infrastructure is not only necessary to
ensure broad access to high-quality research tools, I
argue, but also because the progress of AI will require
deeper understanding of the social forces that guide
human behavior.
Generative AI | computational social science | agent-based model |
survey research | algorithmic bias

Generative AI—technology capable of producing realistic
text, images, music, and other creative forms—continues to
captivate large audiences. Many speculate such technology
will impact a range of industries and scien
