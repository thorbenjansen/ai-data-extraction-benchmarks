# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Bail - 2024 - Can Generative AI improve social science.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `experiment` |
| Branch role | `branch-adjacent context` |
| Top terms | generative ai (98), llm (88), large language model (19), chatgpt (7), gpt-4 (5), annotation (2) |
| Verification status | Needs human source-checking before exact citation |
