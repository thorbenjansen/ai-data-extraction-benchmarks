# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Bail - 2024 - Can Generative AI improve social science.pdf`.
- Raw Markdown path: `not available`.
