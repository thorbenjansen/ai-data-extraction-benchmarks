# Problem

This ARA preserves a branch-local retrieval entry point for `Bail - 2024 - Can Generative AI improve social science`.

## Provisional Role

- Document category: `branch-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
