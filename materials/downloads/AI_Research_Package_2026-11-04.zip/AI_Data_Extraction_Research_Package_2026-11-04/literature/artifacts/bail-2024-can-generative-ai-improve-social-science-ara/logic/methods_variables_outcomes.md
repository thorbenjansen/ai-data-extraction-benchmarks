# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `branch-adjacent context`.
- Provisional design: `experiment`.
- Top automated-data-extraction terms in source text: generative ai (98), llm (88), large language model (19), chatgpt (7), gpt-4 (5), annotation (2).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Mark Granovetter

Generative AI that can produce realistic text, images,
and other human-like outputs is currently transforming
many different industries.
- I argue
Generative AI has the potential to improve survey research, online experiments, automated content analyses,
agent-based models, and other techniques commonly
used to study human behavior.
- I conclude by arguing that social
scientists can address many of these limitations by creating open-source infrastructure for research on human
behavior.
- Such infrastructure is not only necessary to
ensure broad access to high-quality research tools, I
argue, but also because the progress of AI will require
deeper understanding of the social forces that guide
human behavior.
- In the second section,
I ask whether Generative AI can effectively simulate human
behavior for the purposes of social science research.
- Next, I review recent studies that employ Generative AI
models to simulate dynamic human behaviors.
- These include
experiments where human respondents interact with Generative AI, or simulations where researchers prompt models to
interact with each other to study emergent group behaviors.
- I argue such research may help social scientists begin to
reverse engineer the “social sense” of human beings—or
how we create shared understandings of acceptable behavior

PNAS

2024

Vol.
- Much of the public discourse surrounding this new
technology focuses on the possibility of a “singularity” where
AI models supersede human intelligence and threaten our
well-being.
- I discuss how these issues may negatively impact the quality,
efficiency, interpretability, and replicability of social science
research as well—and generate new questions about ethics
and the protection of human subjects.
- By developing our own Generative AI
models, social scientists can more effectively diagnose how
the model training process impacts scientific analysis of
human behavior and ensure these new tools evolve according
to the interest of science, and not only the corporations that
produce many of the most popular models at present.
- Instead of a “user’s
guide” for Generative AI in social science research, I hope
to inspire ongoing dialog among researchers about how this
new technology should be used to study human behavior in
different settings.
