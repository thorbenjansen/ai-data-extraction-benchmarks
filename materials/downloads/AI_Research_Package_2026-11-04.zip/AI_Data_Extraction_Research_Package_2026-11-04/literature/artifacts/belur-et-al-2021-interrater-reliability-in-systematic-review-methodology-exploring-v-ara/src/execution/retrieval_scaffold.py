"""Retrieval scaffold for the ARA: Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin."""
from pathlib import Path

BRANCH_ROOT = Path(__file__).resolve().parents[5]
SOURCE_NOTE = BRANCH_ROOT / "wiki" / "sources" / 'Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md'
RAW_MARKDOWN = BRANCH_ROOT / 'rawmarkdown_full/belur-et-al-2021-interrater-reliability-in-systematic-review-methodology-exploring-variation-in-coder-decision-makin.md'
SOURCE_PATH = BRANCH_ROOT / 'raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf' if True else None


def available_paths():
    paths = {"source_note": SOURCE_NOTE}
    if RAW_MARKDOWN:
        paths["raw_markdown"] = RAW_MARKDOWN
    if SOURCE_PATH:
        paths["source_path"] = SOURCE_PATH
    return {k: str(v) for k, v in paths.items() if v.exists()}
