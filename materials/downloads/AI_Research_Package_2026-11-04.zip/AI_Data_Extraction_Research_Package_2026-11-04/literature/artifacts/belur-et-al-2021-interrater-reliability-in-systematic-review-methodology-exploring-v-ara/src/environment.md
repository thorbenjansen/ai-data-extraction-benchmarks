# Environment

## Source Environment

- Branch: `Sub_Branch_AI Data Extraction`
- Source note: `wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md`
- Source path: `raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf`
- Raw Markdown: `rawmarkdown_full/belur-et-al-2021-interrater-reliability-in-systematic-review-methodology-exploring-variation-in-coder-decision-makin.md`

## Agent Environment

This artifact was generated from local wiki/source metadata on 2026-05-04.
