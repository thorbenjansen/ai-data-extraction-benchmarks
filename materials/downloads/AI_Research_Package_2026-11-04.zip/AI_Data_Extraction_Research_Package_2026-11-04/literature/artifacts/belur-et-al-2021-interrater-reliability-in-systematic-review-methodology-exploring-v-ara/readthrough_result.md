# Read-Through Result

## Source Identity Check

- Title: Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin
- Source PDF: `raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf`
- Raw Markdown: `rawmarkdown_full/belur-et-al-2021-interrater-reliability-in-systematic-review-methodology-exploring-variation-in-coder-decision-makin.md`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `review`
- Branch role: `direct automated-data-extraction evidence`

## Results Or Findings Check

account for differences in decision-making that result from differences in perspectives of decision makers and the variation in the contexts within which they make those decisions (LeBoeuf and Eldar 2003). In other words, evidence suggests that the way a task is framed affects the decision-making process. Thus, it can be argued that the way in which the end objective of the screening task is framed and how it is interpreted by individual coders could influence their decision-making. A positive frame presents the task whereby fulfillment of a condition would result in a desired outcome, whereas a negative frame would suggest that the nonfulfillment of a condition would result in an undesirable outcome. Further, Roussen, Gasser, and Seifert (2002) suggest that individual coder performance is affected by what they call “learning effect” and “fatigue effect.” These effects have opposite results on individual coders’ behavior in a test–retest situation. Learning effect refers to the improvement in accuracy against codebook in decision-making in the test–retest situation, whereas “fatigue” effect refers to worsening in decision-making as a result of prolonged exposure to the task (Roussen et al, 2002). Similarly, when multiple coders are used for coding data, customarily the degree of agreement should be reported as a measure of the reliability of coding. However, agreement between coders reported in percentage terms (as is often the case) tells us nothing about the accuracy or precision of the coding exercise. The degree of both accuracy and precision are important in assessing the quality of interobserver agreement (Viera and Garrett 2005). Further, the causes of disagreements and how they were resolved are equally important in ensuring quality of the final coding. IRR or intercoder agreement can be defined as “the extent to which independent coders evaluate a characteristic of a message or artefact and reach the same conclusions” (Lombard et al. 2002:589). Intrarater reliability on the other hand measures the extent to which one person will interpret the data in the same way and assign it the same code over time. Thus, reliability across multiple coders is measured by IRR and reliability over time for the same coder is measured by intrarater reliability (McHugh 2012).

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
