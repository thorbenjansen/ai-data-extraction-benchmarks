# Constraints

- Do not cite this ARA as the ultimate source for exact quotes or numerical values.
- If `grounding_status` is not `full_markdown`, perform PDF checking before using fine-grained claims.
- Preserve the distinction between empirical results, conceptual recommendations, and branch-level interpretation.
- Keep future edits linked to `wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md` and the canonical source file.
