# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `review`.
- Top automated-data-extraction terms in source text: screening (64), data extraction (9), llm (2), risk of bias (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- However, little attention
has been paid to reporting the details of interrater reliability (IRR) when
multiple coders are used to make decisions at various points in the screening
and data extraction stages of a study.
- This article examines and reflects on the human factors that affect
decision-making in systematic reviews via reporting on three IRR tests,
conducted at three different points in the screening process, for two distinct
reviews.
- Results of the two studies are discussed in the context of IRR and
intrarater reliability in terms of the accuracy, precision, and reliability of
coding behavior of multiple coders.
- Email: j.belur@ucl.ac.uk

838

Sociological Methods & Research 50(2)

tests, especially when multiple coders are involved, to ensure consistency
and clarity at the screening and coding stages.
- Implications for good practice
while screening/coding for systematic reviews are discussed.
- Keywords
interrater reliability, systematic review, screening, coding, k statistic,
precision, replicability

The initial phase of searching and selecting relevant studies is a crucial
aspect of conducting a systematic review (Petrosino 1995).
- The process of conducting a systematic review entails decisions to be made at various points,
often subjectively, and unless detailed information is provided about how
coding and screening decisions were made and disagreements (if any)
resolved between various members of the research team, the review can
scarcely be replicable.
- Surprisingly, little attention is paid to reporting the details of interrater
reliability (IRR) when multiple coders are used to make decisions at various
points in the screening and data extraction stages of a study.
- We further explore the reasons for variability in human decision-making, even within a tightly defined
framework.
- This article will also demonstrate how an IRR exercise can be
used to develop and refine a codebook to guide and improve coding behavior
in terms of stability, accuracy, and reproducibility.
- By way of a preamble, coding can be accomplished by a single coder or a
team of multiple coders at various stages in a systematic review for quality
appraisal purposes, for example, at the initial screening on the title and
abstract, the second screening on full text, or the data extraction stage.
- Thus, the k statistic measures not only
accuracy (getting the coding aligned with the codebook) but precision
(ensuring that agreement between coders is not due to chance alone) too.
