# Claims

- C01: The source is highly connected in the branch graph with degree 7 (0 incoming, 7 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: A methodologically sound systematic review is characterized by transparency, replicability, and a clear inclusion criterion. However, little attention has been paid to reporting the details of interrater reliability (IRR) when multiple coders are used to make decisions at various points in the screening and data extraction stages of a study. Prior research has mentioned the paucity of information on IRR including...
- C03: The source note classifies the work as secondary-evidence using systematic-review, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.

## Claim Status

- Supported by: `raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf` and `wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md`
- Grounding status: `full_markdown`
- Verification priority: high for numerical or methodological details; medium for conceptual linkage claims.
