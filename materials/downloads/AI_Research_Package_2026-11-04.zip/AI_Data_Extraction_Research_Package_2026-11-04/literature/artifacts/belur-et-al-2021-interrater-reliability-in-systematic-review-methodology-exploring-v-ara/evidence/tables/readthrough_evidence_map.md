# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf` |
| Raw Markdown | `rawmarkdown_full/belur-et-al-2021-interrater-reliability-in-systematic-review-methodology-exploring-variation-in-coder-decision-makin.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `review` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | screening (64), data extraction (9), llm (2), risk of bias (1) |
| Verification status | Needs human source-checking before exact citation |
