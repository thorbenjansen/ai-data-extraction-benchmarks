# Source Grounding Table

| Field | Value |
|---|---|
| Source title | Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin |
| Source note | wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md |
| Source path | raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf |
| Raw Markdown | not available |
| Grounding status | full_markdown |
| Branch degree | 7 |
| Incoming links | 0 |
| Outgoing links | 7 |
| Study kind | secondary-evidence |
| Study method | systematic-review |
| Article role | supporting-rejoinder-evidence |
