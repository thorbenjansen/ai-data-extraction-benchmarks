# Evidence Layer

## Source Pointers

- Source note: `wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md`
- Source path: `raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/belur-et-al-2021-interrater-reliability-in-systematic-review-methodology-exploring-variation-in-coder-decision-makin.md`
- Grounding status: `full_markdown`

## Evidence Policy

This ARA is grounded only to the level stated above. For exact claims, quotes, table values, sample sizes, or model performance numbers, open the Markdown sidecar/PDF and add a specific evidence file with page or section pointers.

## Current Evidence Records

- `evidence/tables/source_grounding.md`: source and graph metadata.
