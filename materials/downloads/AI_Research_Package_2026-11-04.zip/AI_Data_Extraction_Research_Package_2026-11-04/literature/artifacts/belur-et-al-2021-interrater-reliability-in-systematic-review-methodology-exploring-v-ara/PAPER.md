---
type: agent_native_research_artifact
date: 2026-05-04
source_title: "Interrater Reliability in Systematic Review Methodology: Exploring Variation in Coder Decision-Making"
source_note: "wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md"
source_path: "raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf"
rawmarkdown_path: "rawmarkdown_full/belur-et-al-2021-interrater-reliability-in-systematic-review-methodology-exploring-variation-in-coder-decision-makin.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
ranking_degree: 7
ranking_incoming: 0
ranking_outgoing: 7
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
title: "Interrater Reliability in Systematic Review Methodology: Exploring Variation in Coder Decision-Making"
authors:
  - "J. Belur"
  - "L. Tompson"
  - "A. Thornton"
  - "M. Simon"
year: "2021"
---

# Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin

## Retrieval Contract

Use this ARA as the first agent-facing layer for the source, then verify important claims against `evidence/README.md`, `the PDF/source note pointer`, and the branch source note `wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md`.

## Source Grounding

- Source note: `wiki/sources/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.md`
- Source path: `raw/Belur et al. - 2021 - Interrater reliability in systematic review methodology exploring variation in coder decision-makin.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/belur-et-al-2021-interrater-reliability-in-systematic-review-methodology-exploring-variation-in-coder-decision-makin.md`
- Grounding status: `full_markdown`
- Branch graph rank signal: degree 7 = 0 incoming + 7 outgoing links.

## Abstracted Contribution

A methodologically sound systematic review is characterized by transparency, replicability, and a clear inclusion criterion. However, little attention has been paid to reporting the details of interrater reliability (IRR) when multiple coders are used to make decisions at various points in the screening and data extraction stages of a study. Prior research has mentioned the paucity of information on IRR including...

## Branch Use

This artifact was generated for the Top-20 connected-paper pass. It is designed for retrieval, rejoinder drafting, and source triage, not as a substitute for checking the PDF or full Markdown when making exact empirical claims.

## Main Ideas

- A methodologically sound systematic review is characterized by transparency, replicability, and a clear inclusion criterion.
- However, little attention has been paid to reporting the details of interrater reliability (IRR) when multiple coders are used to make decisions at various points in the screening and data extraction stages of a study.
- Prior research has mentioned the paucity of information on IRR including number of coders involved, at what stages and how IRR tests were conducted, and how disagreements were resolved.

## Key Claims

- C01: The source is highly connected in the branch graph with degree 7 (0 incoming, 7 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: A methodologically sound systematic review is characterized by transparency, replicability, and a clear inclusion criterion. However, little attention has been paid to reporting the details of interrater reliability (IRR) when multiple coders are used to make decisions at various points in the screening and data extraction stages of a study. Prior research has mentioned the paucity of information on IRR including...
- C03: The source note classifies the work as secondary-evidence using systematic-review, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.

## APA Reference

Belur, J., Tompson, L., Thornton, A., & Simon, M. (2021). Interrater reliability in systematic review methodology: Exploring variation in coder decision-making. Sociological Methods & Research.
