# Read-Through Result

## Source Identity Check

- Title: Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might
- Source PDF: `raw/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `background meta-research or synthesis-methods evidence`

## Results Or Findings Check

Results Descriptive Analysis Before moving into the ﬁndings (broken down by path in Figure 2), we contextualize the results by outlining descriptive features of the primary studies included in analyses. We ﬁrst outline the number of effects for each level. Next, we include information related to the population, intervention, and context.8 We then include information related to methodological features of the studies. The details are broken down by end result. For additional details on the populations, intervention, comparison groups, and outcomes (PICO), see Table 7. Altogether, 52 articles supplied 55 studies, which resulted in 53 distinct interventions9 testing intervention effectiveness, with 279 effects in total across the outcomes. In terms of descriptive information for each of our outcomes and analyses (Table 2), for Levels 1–3, growth mindsets were reported in 34 studies, expectations in 12 studies, and goal-directed behaviors were tested in 22 studies. In 47 of the 53 distinct interventions, an effect size relevant to an end result was provided—academic performance (32 studies); mental health (8 studies); or social functioning (7 studies). As for descriptive information, for academic achievement, in terms of samples, 97% are drawn from Western, educated, industrialized, rich, and democratic (WEIRD) nations—those that are Western, educated, industrialized, rich, and democratic (Henrich et al., 2010). Here, 70% are from the United States, with 55.3% women on average, and 62% of the sample were primary or high school aged. In terms of research design, 75.7% used an active control group and 73% randomized at the individual level. The majority of the studies (78.4%) were conducted in the last 5 years and 78.4% were published. As for features related to the intervention delivery, information was not uniformly available regarding key characteristics of the interventions used in the analytic sample. Yet, information related to dose, in terms of sessions and duration, was more routinely accessible. Most academic interventions consisted of relatively few sessions (the median number was two), and were relatively brief (the median duration was 75 min), attesting to the comparatively low cost of most growth mindset interventions. In these interventions, all but three interventions focused on fostering stronger growth mindsets of intelligence (91.2%). For mental h

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
