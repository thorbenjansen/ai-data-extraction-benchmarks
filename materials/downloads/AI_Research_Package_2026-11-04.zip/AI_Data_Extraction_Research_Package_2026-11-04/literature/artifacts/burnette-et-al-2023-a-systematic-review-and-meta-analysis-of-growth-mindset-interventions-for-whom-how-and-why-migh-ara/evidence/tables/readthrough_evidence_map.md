# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `systematic-review/meta-analysis` |
| Branch role | `background meta-research or synthesis-methods evidence` |
| Top terms | pico (3) |
| Verification status | Needs human source-checking before exact citation |
