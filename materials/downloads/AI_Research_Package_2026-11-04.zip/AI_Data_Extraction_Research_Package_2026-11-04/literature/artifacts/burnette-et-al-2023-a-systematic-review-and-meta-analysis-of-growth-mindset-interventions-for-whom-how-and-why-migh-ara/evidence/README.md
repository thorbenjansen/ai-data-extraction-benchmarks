# Evidence README

## Source Pointer

- PDF: `raw/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Psychological Bulletin
A Systematic Review and Meta-Analysis of Growth Mindset Interventions:
For Whom, How, and Why Might Such Interventions Work?
Jeni L. Burnette, Joseph Billingsley, George C. Banks, Laura E. Knouse, Crystal L. Hoyt, Jeffrey M. Pollack, and Stefanie
Simon
Online First Publication, October 13, 2022. http://dx.doi.org/10.1037/bul0000368

CITATION
Burnette, J. L., Billingsley, J., Banks, G. C., Knouse, L. E., Hoyt, C. L., Pollack, J. M., & Simon, S. (2022, October 13). A
Systematic Review and Meta-Analysis of Growth Mindset Interventions: For Whom, How, and Why Might Such
Interventions Work?. Psychological Bulletin. Advance online publication. http://dx.doi.org/10.1037/bul0000368

Psychological Bulletin
© 2022 American Psychological Association
ISSN: 0033-2909

https://doi.org/10.1037/bul0000368

A Systematic Review and Meta-Analysis of Growth Mindset Interventions: For
Whom, How, and Why Might Such Interventions Work?
Jeni L. Burnette1, Joseph Billingsley2, George C. Banks3, Laura E. Knouse4, Crystal L. Hoyt5,
Jeffrey M. Pollack6, and Stefanie Simon7

This document is copyrighted by the American Psychological Association or one of its allied publishers.
This article is intended solely for the personal use of the individual user and is not to be disseminated broadly.

1

Department of Psychology, College of Humanities and Social Sciences, North Carolina State University
2
School of Science and Engineering, Tulane University
3
Belk College of Business, University of North Carolina Charlotte
4
School of Arts and Sciences, University of Richmond
5
Jepson School of Leadership Studies, University of Richmond
6
Poole College of Management, North Carolina State University
7
School of Liberal Arts, Siena College
As growth mindset interventions increase in scop
