# Problem

This ARA preserves a branch-local retrieval entry point for `Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
