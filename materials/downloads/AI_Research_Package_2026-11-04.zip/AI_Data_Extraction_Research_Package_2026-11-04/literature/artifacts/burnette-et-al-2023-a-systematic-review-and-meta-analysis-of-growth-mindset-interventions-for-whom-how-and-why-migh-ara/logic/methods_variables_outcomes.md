# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `background meta-research or synthesis-methods evidence`.
- Provisional design: `systematic-review/meta-analysis`.
- Top automated-data-extraction terms in source text: pico (3).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Burnette, Department of Psychology, College of Humanities and Social
Sciences, North Carolina State University, 640 Poe Hall, Campus Box
7650, Raleigh, NC 27607, United States.
- Mindsets fall on a continuum, with stronger growth, relative to ﬁxed,
mindsets reﬂecting a belief that attributes and people can and do
1
We thank the reviewers and editor for their extensive feedback and
suggestions.
- These small
sample sizes are subject to overestimating effects and inﬂating Type
I errors.
- In the
absence of implementation ﬁdelity, null results from intervention
studies due to failure to implement can lead to the erroneous
conclusion that the theoretical underpinnings of an intervention
are not sound, also known as a Type III error (Dobson & Cook,
1980).
- Finally, we note that our model limits its focus to three theoretically
driven moderators outlined in the literature, but we recognize the
potential impact of a great number of methodological and other studyrelated differences and discuss these in our sensitivity analyses as well
as in the Limitations section.
- In adapting this model to examine growth mindset
interventions—which are training sessions designed to teach individuals to believe in the malleable nature of human attributes—we
offer an operational deﬁnition of each level (see Figure 1).
- For Table 2, we report the number of
effects, samples, and studies, the N, Cohen’s d, the standard error,
95% conﬁdence intervals (CIs), and τ2 as well as prediction intervals
to indicate the degree of heterogeneity (Borenstein et al., 2009).
- In
Table 3 and Table 4, for moderators, we report the estimates,
standard errors, 95% conﬁdence intervals (CIs), τ2, variance accounted for (VAF), and the prediction intervals.
- In Table 5, for the
focal effects, we report the estimated effect at the speciﬁed moderator values, as well as the corresponding standard error, 95% conﬁdence intervals for the estimate, and 95% prediction intervals (PIs).
- In Table 6, for the correlations among constructs, we report the
summary correlation coefﬁcient, along with its standard error, 95%
conﬁdence intervals, τ2, and 95% prediction intervals.
- SE = standard error; 95% CI = 95%
conﬁdence interval; 95% PI = 95% prediction interval.
- A brief overview of pertinent decisions
that could have an impact is elaborated on below—note, we did
not preregister the search protocol or decisions outlined below, and
some decisions are a result of multiple rounds of reviewer feedback.
