# Method And Design

## Source Identity

- Title: Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might
- ARA: `burnette-et-al-2023-a-systematic-review-and-meta-analysis-of-growth-mindset-interventions-for-whom-how-and-why-migh-ara`
- Source PDF: `raw/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `background meta-research or synthesis-methods evidence`

## Data, Sample, Or Source Material

sessions and time spent delivering the message). However, because there is not an agreed-upon gold-standard implementation approach for these additional components, we did not include this as part of our overall ﬁdelity score. Here, we outline the three key components that go into our continuous overall ﬁdelity moderator: adherence, delivery competence, and message control. Adherence. Adherence means including “core components” that constitute an intervention and is often deﬁned as delivering the intervention as prescribed (Dane & Schneider, 1998). To be considered a growth mindset intervention, there must be a message that the attribute is malleable. Yet, to help make this attribute stick, interventions also often include an attitude change tactic such as a saying is believing activity. For example, this often involves writing a pen-pal letter to a struggling student—a note that stresses the opportunity for growth and development despite challenges. Having participants put the growth mindset message into their own words helps to instill the mindset belief. In the present work, 18.9% of interventions failed to include this type of attitude change tactic. Interventions that are implemented with this component and adhere to best practices are likely more impactful. Thus, those that included the saying is believing type of exercise received a score of 1, and those that did not, received a score of 0. Delivery Competence. Delivery competence relates to the skillful delivery of the intervention content. Experts in mindset research delineate several components that should improve the delivery of growth mindset interventions, most of which are delineated in the context of mindsets of intelligence and academic performance. These components for mindset interventions are as follows: (a) include neuroscience information, (b) use credible sources, (c) provide scientiﬁc evidence of the potential for change, (d) respect autonomy (e.g., ask the participant to collaborate), (e) incorporate social norms and social modeling, (f ) include content to avoid blame and encourage self-compassion, (g) make it personally relevant and (h) incorporate metaphors that make the message “sticky” (Yeager, Romero, et al., 2016). In developing the coding procedures for delivery competence, we arrived at ﬁve categories that could be coded in the existing data. First, was scientiﬁc evidence (in

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Results Descriptive Analysis Before moving into the ﬁndings (broken down by path in Figure 2), we contextualize the results by outlining descriptive features of the primary studies included in analyses. We ﬁrst outline the number of effects for each level. Next, we include information related to the population, intervention, and context.8 We then include information related to methodological features of the studies. The details are broken down by end result. For additional details on the populations, intervention, comparison groups, and outcomes (PICO), see Table 7. Altogether, 52 articles supplied 55 studies, which resulted in 53 distinct interventions9 testing intervention effectiveness, with 279 effects in total across the outcomes. In terms of descriptive information for each of our outcomes and analyses (Table 2), for Levels 1–3, growth mindsets were reported in 34 studies, expectations in 12 studies, and goal-directed behaviors were tested in 22 studies. In 47 of the 53 distinct interventions, an effect size relevant to an end result was provided—academic performance (32 studies); mental health (8 studies); or social functioning (7 studies). As for descriptive information, for academic achievement, in terms of samples, 97% are drawn from Western, educated, industrialized, rich, and democratic (WEIRD) nations—those that are Western, educated, industrialized, rich, and democratic (Henrich et al., 2010). Here, 70% are from the United States, with 55.3% women on average, and 62% of the sample were primary or high school aged. In terms of research design, 75.7% used an active control group and 73% randomized at the individual level. The majority of the studies (78.4%) were conducted in the last 5 years and 78.4% were published. As for features related to the intervention delivery, information was not uniformly available regarding key characteristics of the interventions used in the analytic sample. Yet, information related to dose, in terms of sessions and duration, was more routinely accessible. Most academic interventions consisted of relatively few sessions (the median number was two), and were relatively brief (the median duration was 75 min), attesting to the comparatively low cost of most growth mindset interventions. In these interventions, all but three interventions focused on fostering stronger growth mindsets of intelligence (91.2%). For mental h

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
