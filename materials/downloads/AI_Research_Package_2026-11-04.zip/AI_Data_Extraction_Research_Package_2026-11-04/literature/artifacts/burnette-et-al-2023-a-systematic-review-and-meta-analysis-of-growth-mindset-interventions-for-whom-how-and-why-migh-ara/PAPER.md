---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might"
source_note: "wiki/sources/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.md"
source_path: "raw/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.md`
- Source path: `raw/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Psychological Bulletin
A Systematic Review and Meta-Analysis of Growth Mindset Interventions:
For Whom, How, and Why Might Such Interventions Work?
Jeni L. Burnette, Joseph Billingsley, George C. Banks, Laura E. Knouse, Crystal L. Hoyt, Jeffrey M. Pollack, and Stefanie
Simon
Online First Publication, October 13, 2022. http://dx.doi.org/10.1037/bul0000368

CITATION
Burnette, J. L., Billingsley, J., Banks, G. C., Knouse, L. E., Hoyt, C. L., Pollack, J. M., & Simon, S. (2022, October 13). A
Systematic Review and Meta-Analysis of Growth Mindset Interventions: For Whom, How, and Why Might Such
Interventions Work?. Psychological Bulletin. Advance online publication. http://dx.doi.org/10.1037/bul0000368

Psychological Bulletin
© 2022 American Psychological Association
ISSN: 0033-2909

https://doi.org/10.1037/bul0000368

A Systematic Review and Meta-Analysis of Growth Mindset Interventions: For
Whom, How, and Why Might Such Interventions Work?
Jeni L. Burnette1, Joseph Billingsley2, George C. Banks3, Laura E. Knouse4, Crystal L. Hoyt5,
Jeffrey M. Pollack6, and Stefanie Simon7

This document is copyrighted by the American Psychological Association or one of its allied publishers.
This article is intended solely for the personal use of the individual user and is not to be disseminated broadly.

1

Department of Psychology, College of Humanities and Social Sciences, North Carolina State University
2
School of Science and Engineering, Tulane University
3
Belk College of Business, University of North Carolina Charlotte
4
School of Arts and Sciences, University of Richmond
5
Jepson School of Leadership Studies, University of Richmond
6
Poole College of Management, North Carolina State University
7
School of Liberal Arts, Siena College
As growth mindset interventions increase in scop

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
