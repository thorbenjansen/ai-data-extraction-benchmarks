# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Burnette et al. - 2023 - A systematic review and meta-analysis of growth mindset interventions For whom, how, and why might.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
