# Method And Design

## Source Identity

- Title: BUL-2025-2146
- ARA: `bul-2025-2146-ara`
- Source PDF: `raw/BUL-2025-2146.pdf`
- Raw Markdown: `rawmarkdown_full/bul-2025-2146.md`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `direct automated-data-extraction evidence`

## Data, Sample, Or Source Material

Using an Additional Coder Only When AI and Human Disagree One approach offered for maximizing efficiency while implementing human verification is to bring in a second human coder only when the primary coder disagrees with the majority of LLMs on a data point (Jansen et al., 2026). In addition to this approach not yet being tested, two further considerations are offered. First, there are multiple decision points for how to work with AI that might alter the effectiveness of this approach. One example decision point is determining who is engaging with the LLMs. If the primary human coder is also the person iteratively optimizing prompts in the LLMs, the coder might be reinforcing agreement with their coding rather than independently verifying it. An empirical question is how decisions differ depending on the role of the person optimizing the prompts, as well as the role of the LLMs: independent coder, judge, or assistant. A second concern is related to the experience of the second human coder who only steps in as needed. If a second coder is only asked to occasionally engage in extraction, they will have less experience with the body of literature. A quirk found in one primary study (e.g., different descriptions in different parts of the paper, degrees of freedom that do not match reported sample sizes) can not only lead to further investigation for clarity but reinforce checking for similar quirks in other papers. A coder who is fully engaged in the extraction process may be more likely to develop a rigorous process to find, identify, and verify data points than one who only engages when a coder and AI disagree. Conclusion This commentary describes potential extensions to Jansen et al.’s (2026) recommended research agenda for using AI in meta-analyses. These suggestions include investigating potential AI-induced bias, AI-induced complacency, and the illusion of exploratory breadth. Another

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Artificial Intelligence as a Partner in Meta-analysis: Research Agenda, User Recommendations, and Speed-Accuracy Tradeoffs Meta-analyses summarize findings, test theories, and provide a framework for researchers to develop future investigations. High levels of rigor during data extraction are needed to make valid coding decisions, which in turn are necessary to produce reliable and valid meta-analyses (Villiger et al., 2022). Nevertheless, high levels of rigor are time consuming and costly. In one sample, Li et al. (2019) found that extracting variables from primary studies took researchers anywhere from less than 1 hour to greater than 6.5 hours per paper. With an aim of reducing the time needed for meta-analytic data extraction, Jansen et al. (2026) investigated the accuracy of multiple large language models (LLMs) compared with the data extracted by human metaanalysts. Based on their findings, Jansen et al. (2026) recommended 1) a research agenda for investigating the use of AI for data extraction and 2) methods for using AI as a meta-analysis partner. This commentary offers both an extension to Jansen et al.’s (2026) research agenda and further considerations regarding some of the recommended methods that have not yet been tested and evaluated. Research Agenda for Investigating the Use of AI for Data Extraction Jansen et al. (2026) propose a research agenda focused on investigating efficiency and accuracy of AI for meta-analysis data extraction. Specifically, they suggest that researchers examine speed-accuracy tradeoffs of using AI in different roles during data extraction: as an assistant, a judge, and an independent second coder. This commentary offers extensions to the proposed research agenda.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
