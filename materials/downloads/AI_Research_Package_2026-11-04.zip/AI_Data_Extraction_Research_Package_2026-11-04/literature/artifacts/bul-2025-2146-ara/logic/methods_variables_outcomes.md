# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `systematic-review/meta-analysis`.
- Top automated-data-extraction terms in source text: data extraction (16), llm (15), artificial intelligence (11), large language model (5), risk of bias (2), information extraction (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Efficiency was
impressive: Across thousands of studies and hundreds of variables, 10 LLMs took less
than an hour combined to extract hundreds of thousands of data points—work
estimated to take a human coder > 6,500 hours.
- Nevertheless, accuracy was
inconsistent, ranging from high to low depending on the variable.
- From these results,
Jansen et al. recommended 1) a research agenda for investigating the use of artificial
intelligence (AI) for data extraction and 2) methods for using AI as a meta-analysis
partner.
- Finally, the commentary discusses speed-accuracy
tradeoffs in meta-analyses.
- Efficiency was impressive: Across thousands of studies
and hundreds of variables, 10 LLMs took less than an hour combined to extract hundreds of
thousands of data points—work estimated to take a human coder > 6,500 hours.
- Nevertheless,
accuracy was inconsistent, ranging from high to low depending on the variable.
- From these
results, Jansen et al. recommended 1) a research agenda for investigating the use of artificial
intelligence (AI) for data extraction and 2) methods for using AI as a meta-analysis partner.
- Finally, the
commentary discusses speed-accuracy tradeoffs in meta-analyses.
- Keywords: meta-analysis, artificial intelligence, systematic reviews, large language models

AI PARTNER IN META

3
Public Significance Statement

This commentary evaluates the research agenda and use of artificial intelligence
recommendations for meta-analyses by Jansen et al. (2026).
- AI PARTNER IN META

4

Artificial Intelligence as a Partner in Meta-analysis:
Research Agenda, User Recommendations, and Speed-Accuracy Tradeoffs
Meta-analyses summarize findings, test theories, and provide a framework for researchers
to develop future investigations.
- High levels of rigor during data extraction are needed to make
valid coding decisions, which in turn are necessary to produce reliable and valid meta-analyses
(Villiger et al., 2022).
- With an aim of reducing the
time needed for meta-analytic data extraction, Jansen et al. (2026) investigated the accuracy of
multiple large language models (LLMs) compared with the data extracted by human metaanalysts.
