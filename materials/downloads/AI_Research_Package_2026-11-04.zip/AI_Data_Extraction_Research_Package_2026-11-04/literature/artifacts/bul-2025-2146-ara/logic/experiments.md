# Experiments and Empirical Structure

## Study Type

- Study kind: `secondary-evidence`
- Study method: `meta-analysis`

## What to Extract When Needed

- Unit of analysis and comparison frame.
- Accuracy, agreement, bias, reliability, or workflow metrics if reported.
- Human baseline and validation procedure.
- Whether the source evaluates an AI system, proposes guidance, or synthesizes a research agenda.

## Current Structural Status

This Level-1 ARA records the retrieval scaffold and source-grounded claims. A later Level-2 pass should extract tables, samples, metrics, prompts, and datasets directly from the full Markdown/PDF where applicable.
