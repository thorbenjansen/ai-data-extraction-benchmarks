# Claims

- C01: The source is highly connected in the branch graph with degree 8 (0 incoming, 8 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: Using a metascience framework for improving meta-analyses, Jansen et al. (2026) tested the accuracy and efficiency of data extraction from primary studies used in meta-analyses with a range of large language models (LLMs). Efficiency was impressive: Across thousands of studies and hundreds of variables, 10 LLMs took less than an hour combined to extract hundreds of thousands of data points—work estimated to take a...
- C03: The source note classifies the work as secondary-evidence using meta-analysis, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.

## Claim Status

- Supported by: `raw/BUL-2025-2146.pdf` and `wiki/sources/BUL-2025-2146.md`
- Grounding status: `full_markdown`
- Verification priority: high for numerical or methodological details; medium for conceptual linkage claims.
