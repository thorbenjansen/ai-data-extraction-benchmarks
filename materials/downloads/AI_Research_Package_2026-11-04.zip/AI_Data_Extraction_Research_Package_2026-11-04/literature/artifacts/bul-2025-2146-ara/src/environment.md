# Environment

## Source Environment

- Branch: `Sub_Branch_AI Data Extraction`
- Source note: `wiki/sources/BUL-2025-2146.md`
- Source path: `raw/BUL-2025-2146.pdf`
- Raw Markdown: `rawmarkdown_full/bul-2025-2146.md`

## Agent Environment

This artifact was generated from local wiki/source metadata on 2026-05-04.
