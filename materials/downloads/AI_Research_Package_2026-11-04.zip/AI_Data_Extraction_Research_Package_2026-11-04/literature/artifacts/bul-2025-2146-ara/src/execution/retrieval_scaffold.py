"""Retrieval scaffold for the ARA: BUL-2025-2146."""
from pathlib import Path

BRANCH_ROOT = Path(__file__).resolve().parents[5]
SOURCE_NOTE = BRANCH_ROOT / "wiki" / "sources" / 'BUL-2025-2146.md'
RAW_MARKDOWN = BRANCH_ROOT / 'rawmarkdown_full/bul-2025-2146.md'
SOURCE_PATH = BRANCH_ROOT / 'raw/BUL-2025-2146.pdf' if True else None


def available_paths():
    paths = {"source_note": SOURCE_NOTE}
    if RAW_MARKDOWN:
        paths["raw_markdown"] = RAW_MARKDOWN
    if SOURCE_PATH:
        paths["source_path"] = SOURCE_PATH
    return {k: str(v) for k, v in paths.items() if v.exists()}
