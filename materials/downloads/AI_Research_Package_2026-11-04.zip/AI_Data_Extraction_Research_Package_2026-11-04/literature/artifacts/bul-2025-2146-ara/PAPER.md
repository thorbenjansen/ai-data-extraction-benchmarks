---
type: agent_native_research_artifact
date: 2026-05-04
source_title: "BUL-2025-2146"
source_note: "wiki/sources/BUL-2025-2146.md"
source_path: "raw/BUL-2025-2146.pdf"
rawmarkdown_path: "rawmarkdown_full/bul-2025-2146.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
ranking_degree: 8
ranking_incoming: 0
ranking_outgoing: 8
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# BUL-2025-2146

## Retrieval Contract

Use this ARA as the first agent-facing layer for the source, then verify important claims against `evidence/README.md`, `the PDF/source note pointer`, and the branch source note `wiki/sources/BUL-2025-2146.md`.

## Source Grounding

- Source note: `wiki/sources/BUL-2025-2146.md`
- Source path: `raw/BUL-2025-2146.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/bul-2025-2146.md`
- Grounding status: `full_markdown`
- Branch graph rank signal: degree 8 = 0 incoming + 8 outgoing links.

## Abstracted Contribution

Using a metascience framework for improving meta-analyses, Jansen et al. (2026) tested the accuracy and efficiency of data extraction from primary studies used in meta-analyses with a range of large language models (LLMs). Efficiency was impressive: Across thousands of studies and hundreds of variables, 10 LLMs took less than an hour combined to extract hundreds of thousands of data points—work estimated to take a...

## Branch Use

This artifact was generated for the Top-20 connected-paper pass. It is designed for retrieval, rejoinder drafting, and source triage, not as a substitute for checking the PDF or full Markdown when making exact empirical claims.

## Main Ideas

- Using a metascience framework for improving meta-analyses, Jansen et al.
- (2026) tested the accuracy and efficiency of data extraction from primary studies used in meta-analyses with a range of large language models (LLMs).
- Efficiency was impressive: Across thousands of studies and hundreds of variables, 10 LLMs took less than an hour combined to extract hundreds of thousands of data points—work estimated to take a human coder > 6,500 hours.

## Key Claims

- C01: The source is highly connected in the branch graph with degree 8 (0 incoming, 8 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: Using a metascience framework for improving meta-analyses, Jansen et al. (2026) tested the accuracy and efficiency of data extraction from primary studies used in meta-analyses with a range of large language models (LLMs). Efficiency was impressive: Across thousands of studies and hundreds of variables, 10 LLMs took less than an hour combined to extract hundreds of thousands of data points—work estimated to take a...
- C03: The source note classifies the work as secondary-evidence using meta-analysis, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.
