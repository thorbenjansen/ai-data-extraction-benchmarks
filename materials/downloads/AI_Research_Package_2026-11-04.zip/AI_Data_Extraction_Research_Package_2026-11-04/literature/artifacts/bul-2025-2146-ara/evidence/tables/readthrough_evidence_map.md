# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/BUL-2025-2146.pdf` |
| Raw Markdown | `rawmarkdown_full/bul-2025-2146.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `systematic-review/meta-analysis` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | data extraction (16), llm (15), artificial intelligence (11), large language model (5), risk of bias (2), information extraction (1) |
| Verification status | Needs human source-checking before exact citation |
