# Evidence Layer

## Source Pointers

- Source note: `wiki/sources/BUL-2025-2146.md`
- Source path: `raw/BUL-2025-2146.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/bul-2025-2146.md`
- Grounding status: `full_markdown`

## Evidence Policy

This ARA is grounded only to the level stated above. For exact claims, quotes, table values, sample sizes, or model performance numbers, open the Markdown sidecar/PDF and add a specific evidence file with page or section pointers.

## Current Evidence Records

- `evidence/tables/source_grounding.md`: source and graph metadata.
