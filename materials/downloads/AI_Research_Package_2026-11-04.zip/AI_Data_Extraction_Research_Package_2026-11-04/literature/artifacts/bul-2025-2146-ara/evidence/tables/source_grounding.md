# Source Grounding Table

| Field | Value |
|---|---|
| Source title | BUL-2025-2146 |
| Source note | wiki/sources/BUL-2025-2146.md |
| Source path | raw/BUL-2025-2146.pdf |
| Raw Markdown | not available |
| Grounding status | full_markdown |
| Branch degree | 8 |
| Incoming links | 0 |
| Outgoing links | 8 |
| Study kind | secondary-evidence |
| Study method | meta-analysis |
| Article role | supporting-rejoinder-evidence |
