# Source Grounding Table

| Field | Value |
|---|---|
| Source title | Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions |
| Source note | wiki/sources/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.md |
| Source path | raw/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf |
| Raw Markdown | rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md |
| Grounding status | full_markdown |
| Branch degree | 8 |
| Incoming links | 0 |
| Outgoing links | 8 |
| Study kind | randomized-human-ai-annotation-experiment |
| Study method | unspecified |
| Article role | supporting-adjacent-literature |
