# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf` |
| Raw Markdown | `rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `experiment` |
| Branch role | `adjacent evidence-synthesis automation evidence` |
| Top terms | annotation (143), human-ai (35), llm (8), screening (3), large language model (2), generative ai (2), artificial intelligence (2), information extraction (1) |
| Verification status | Needs human source-checking before exact citation |
