---
type: agent_native_research_artifact
date: 2026-05-04
source_title: "Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions"
source_note: "wiki/sources/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.md"
source_path: "raw/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf"
rawmarkdown_path: "rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
ranking_degree: 8
ranking_incoming: 0
ranking_outgoing: 8
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions

## Retrieval Contract

Use this ARA as the first agent-facing layer for the source, then verify important claims against `evidence/README.md`, `rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md`, and the branch source note `wiki/sources/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.md`.

## Source Grounding

- Source note: `wiki/sources/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.md`
- Source path: `raw/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md`
- Grounding status: `full_markdown`
- Branch graph rank signal: degree 8 = 0 incoming + 8 outgoing links.

## Abstracted Contribution

# Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions **Source path:** [[Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf]] ## Core Contribution Beck, Eckman, Kern, and Kreuter (2025) experimentally study how humans evaluate AI-generated suggestions in a pre-annotation workflow. The task is directly relevant to AI-assisted extraction: participants...

## Branch Use

This artifact was generated for the Top-20 connected-paper pass. It is designed for retrieval, rejoinder drafting, and source triage, not as a substitute for checking the PDF or full Markdown when making exact empirical claims.

## Main Ideas

- # Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions **Source path:** [[Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf]] ## Core Contribution Beck, Eckman, Kern, and Kreuter (2025) experimentally study how humans evaluate AI-generated suggestions in a pre-annotation workflow. The task is directly relevant to AI-assisted extraction: participants...

## Key Claims

- C01: The source is highly connected in the branch graph with degree 8 (0 incoming, 8 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: # Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions **Source path:** [[Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf]] ## Core Contribution Beck, Eckman, Kern, and Kreuter (2025) experimentally study how humans evaluate AI-generated suggestions in a pre-annotation workflow. The task is directly relevant to AI-assisted extraction: participants...
- C03: The source note classifies the work as randomized-human-ai-annotation-experiment using unspecified, with article role supporting-adjacent-literature.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.
