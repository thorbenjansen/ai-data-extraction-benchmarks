# Environment

## Source Environment

- Branch: `Sub_Branch_AI Data Extraction`
- Source note: `wiki/sources/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.md`
- Source path: `raw/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf`
- Raw Markdown: `rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md`

## Agent Environment

This artifact was generated from local wiki/source metadata on 2026-05-04.
