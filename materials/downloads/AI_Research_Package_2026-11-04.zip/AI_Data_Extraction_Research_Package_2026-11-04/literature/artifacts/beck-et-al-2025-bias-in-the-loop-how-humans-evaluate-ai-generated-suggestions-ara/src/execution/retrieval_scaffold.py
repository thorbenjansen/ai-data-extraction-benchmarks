"""Retrieval scaffold for the ARA: Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions."""
from pathlib import Path

BRANCH_ROOT = Path(__file__).resolve().parents[5]
SOURCE_NOTE = BRANCH_ROOT / "wiki" / "sources" / 'Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.md'
RAW_MARKDOWN = BRANCH_ROOT / 'rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md'
SOURCE_PATH = BRANCH_ROOT / 'raw/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf' if True else None


def available_paths():
    paths = {"source_note": SOURCE_NOTE}
    if RAW_MARKDOWN:
        paths["raw_markdown"] = RAW_MARKDOWN
    if SOURCE_PATH:
        paths["source_path"] = SOURCE_PATH
    return {k: str(v) for k, v in paths.items() if v.exists()}
