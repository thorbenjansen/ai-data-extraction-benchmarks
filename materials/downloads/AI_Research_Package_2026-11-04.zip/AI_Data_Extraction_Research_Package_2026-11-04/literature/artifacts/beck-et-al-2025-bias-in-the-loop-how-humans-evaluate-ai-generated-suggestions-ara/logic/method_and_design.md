# Method And Design

## Source Identity

- Title: Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions
- ARA: `beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions-ara`
- Source PDF: `raw/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf`
- Raw Markdown: `rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `experiment`
- Branch role: `adjacent evidence-synthesis automation evidence`

## Data, Sample, Or Source Material

have been extensively studied, automated methods remain poorly understood and likely reproduce biases present in their training data (Das et al., 2024; Felkner et al., 2024). Human validation of automated pre-annotations offers a promising alternative to fully automated annotations. In this collaborative setup, AI-generated labels are reviewed and corrected by humans. This approach can reduce both time and costs compared to manual annotation while achieving higher accuracy than standalone AI systems. While pre-annotations may improve efficiency, they can also introduce or reinforce cognitive biases. Research on data quality through human review of pre-annotations remains limited. While preannotations reduce annotation time and costs (Mikulová et al., 2023), their effects on data quality and bias mitigation are underexplored. Studies suggesting high data quality from pre-annotations often measure quality with inter-rater agreement (Lingren et al., 2012, 2014), which may overestimate quality when multiple annotators are influenced by the same pre-annotations. Errors from pre-annotation workflows exhibit a more systematic pattern, whereas errors from traditional humanonly annotation tend to be more random (Fort & Sagot, 2010). In addition, AI collaboration can improve immediate task performance but reduce intrinsic motivation and increase boredom when users return to working alone (S. Wu et al., 2025). Traditional sources of annotation biases also remain relevant, including the structure and design of annotation tasks, annotator characteristics, and incentive structures (Al Kuwatly et al., 2020; Beck et al., 2022, 2024; Eckman et al., 2024; Ho et al., 2015; Kern et al., 2023; Rogstadius et al., 2011; Sap et al., 2022). Finally, human-AI collaborative annotation setups introduce new risks: annotators may undercorrect by overlooking mistakes or overcorrect by unnecessarily changing correct suggestions. In practice, the pre-annotation setting brings together multiple bias sources: cognitive bias in human judgment, structural bias from task design, and bias emerging through interaction with AI systems.

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

5. Results 5.1. Descriptive Results. We first address the hypotheses using descriptive analyses. We further examine patterns based on annotation time and explore differences between types of pre-annotation errors.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
