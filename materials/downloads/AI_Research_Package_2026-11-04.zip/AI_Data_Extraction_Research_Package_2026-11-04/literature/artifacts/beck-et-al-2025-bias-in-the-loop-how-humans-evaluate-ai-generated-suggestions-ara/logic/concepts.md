# Concepts

- AI Data Extraction
- Evidence Synthesis Automation

## Anchor Documents

- Not specified

## Retrieval Tags

- branch-ai-data-extraction
- theme-ai-data-extraction
- article-role: `supporting-adjacent-literature`
- study-kind: `randomized-human-ai-annotation-experiment`
- method: `unspecified`
