# Claims

- C01: The source is highly connected in the branch graph with degree 8 (0 incoming, 8 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: # Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions **Source path:** [[Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.pdf]] ## Core Contribution Beck, Eckman, Kern, and Kreuter (2025) experimentally study how humans evaluate AI-generated suggestions in a pre-annotation workflow. The task is directly relevant to AI-assisted extraction: participants...
- C03: The source note classifies the work as randomized-human-ai-annotation-experiment using unspecified, with article role supporting-adjacent-literature.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.

## Claim Status

- Supported by: `rawmarkdown_full/beck-et-al-2025-bias-in-the-loop-how-humans-evaluate-ai-generated-suggestions.md` and `wiki/sources/Beck et al. - 2025 - Bias in the Loop How Humans Evaluate AI-Generated Suggestions.md`
- Grounding status: `full_markdown`
- Verification priority: high for numerical or methodological details; medium for conceptual linkage claims.
