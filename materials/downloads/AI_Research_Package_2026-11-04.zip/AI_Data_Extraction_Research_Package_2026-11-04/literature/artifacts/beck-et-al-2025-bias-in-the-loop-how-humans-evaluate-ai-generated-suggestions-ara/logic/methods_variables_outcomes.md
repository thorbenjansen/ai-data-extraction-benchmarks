# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `adjacent evidence-synthesis automation evidence`.
- Provisional design: `experiment`.
- Top automated-data-extraction terms in source text: annotation (143), human-ai (35), llm (8), screening (3), large language model (2), generative ai (2), artificial intelligence (2), information extraction (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- While AI systems promise efficiency gains by providing automated
suggestions for human review, these workflows can trigger cognitive biases that degrade performance.
- We conducted a randomized experiment with 2,784 participants to
examine how task design and individual characteristics shape human responses to AI-generated
suggestions.
- We collected demographics, attitudes toward AI, and behavioral data to assess
four performance metrics: accuracy, correction activity, overcorrection, and undercorrection.
- Two
patterns emerged that challenge conventional assumptions about human-AI collaboration.
- First,
requiring corrections for flagged AI errors reduced human engagement and increased the tendency
to accept incorrect suggestions, demonstrating how cognitive shortcuts influence collaborative outcomes.
- Participants skeptical of AI detected errors more
reliably and achieved higher accuracy, while those favorable toward automation exhibited dangerous overreliance on algorithmic suggestions.
- These findings reveal that successful human-AI collaboration depends not only on algorithmic performance but also on who reviews AI outputs and how review processes are structured.
- Effective human-AI collaborations
*

jacob.beck@stat.uni-muenchen.de

This article is © 2025 by author(s) as listed above.
- Bias in the Loop: How Humans Evaluate AI-Generated Suggestions

2

require careful consideration of human psychology: selecting diverse evaluator samples, measuring
relevant attitudes, and designing workflows that counteract rather than amplify cognitive biases.
- Even objective tasks with clear ground truth depend on the beliefs and characteristics of the humans
in the loop.
- Introduction
Across industries and institutions, consequential decisions are increasingly made by teams that include both humans and artificial intelligence.
- From radiologists reviewing AI-flagged medical scans
to judges considering algorithmic risk assessments to content moderators evaluating AI-detected
hate speech, human-AI collaborations are reshaping how we work, learn, and govern.
