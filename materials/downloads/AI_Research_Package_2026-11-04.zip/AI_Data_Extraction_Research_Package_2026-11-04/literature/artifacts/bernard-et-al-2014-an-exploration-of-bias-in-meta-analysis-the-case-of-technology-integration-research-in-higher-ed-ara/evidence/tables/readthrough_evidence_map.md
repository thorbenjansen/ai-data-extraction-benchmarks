# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `systematic-review/meta-analysis` |
| Branch role | `background meta-research or synthesis-methods evidence` |
| Top terms | none found |
| Verification status | Needs human source-checking before exact citation |
