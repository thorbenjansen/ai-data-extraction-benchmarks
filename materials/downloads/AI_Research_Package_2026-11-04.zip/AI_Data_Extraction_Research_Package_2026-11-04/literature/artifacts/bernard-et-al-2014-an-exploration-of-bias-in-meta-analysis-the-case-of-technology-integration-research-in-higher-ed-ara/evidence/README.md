# Evidence README

## Source Pointer

- PDF: `raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

J Comput High Educ (2014) 26:183–209
DOI 10.1007/s12528-014-9084-z

An exploration of bias in meta-analysis: the case
of technology integration research in higher education
Robert M. Bernard • Eugene Borokhovski •
Richard F. Schmid • Rana M. Tamim

Published online: 12 November 2014
 Springer Science+Business Media New York 2014

Abstract This article contains a second-order meta-analysis and an exploration of
bias in the technology integration literature in higher education. Thirteen metaanalyses, dated from 2000 to 2014 were selected to be included based on the
questions asked and the presence of adequate statistical information to conduct a
quantitative synthesis. The weighted random effects average was g?? = 0.393,
p \ .000. The article goes on to report an assessment of the methodological quality
of the thirteen studies based on Cooper’s (Research synthesis and meta-analysis: a
step-by-step approach. Sage, Thousand Oaks, 2010) seven stages in the development of a meta-analysis. Two meta-analyses were found to have five out of seven
stages where methodological flaws could potentially create biased results. Five
meta-analyses contained two flawed stages and one contained one flawed stage.
Four of the stages where methodological flaws can create bias are described in
detail. The final section attempts to determine how much influence the methodological flaws exerted on the results of the second-order meta-analysis.
Keywords

Technology  Computers  Meta-analysis  Bias  Higher education

Introduction
In April of 2014 our research team published an article (Bernard et al. 2014) in the
Journal of Computing in Higher Education entitled ‘‘A Meta-analysis of Blended
Learning and Technology use in Higher Education: From the General to the
R. M. Bernard (&)  E. Borokhovsk
