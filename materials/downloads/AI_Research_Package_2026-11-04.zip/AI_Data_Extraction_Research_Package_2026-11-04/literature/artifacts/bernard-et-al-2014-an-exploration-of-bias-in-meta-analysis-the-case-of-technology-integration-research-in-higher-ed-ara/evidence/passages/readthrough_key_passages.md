# Read-Through Key Passages

## Abstract Or Opening

Abstract This article contains a second-order meta-analysis and an exploration of bias in the technology integration literature in higher education. Thirteen metaanalyses, dated from 2000 to 2014 were selected to be included based on the questions asked and the presence of adequate statistical information to conduct a quantitative synthesis. The weighted random effects average was g?? = 0.393, p \ .000. The article goes on to report an assessment of the methodological quality of the thirteen studies based on Cooper’s (Research synthesis and meta-analysis: a step-by-step approach. Sage, Thousand Oaks, 2010) seven stages in the development of a meta-analysis. Two meta-analyses were found to have five out of seven stages where methodological flaws could potentially create biased results. Five meta-analyses contained two flawed stages and one contained one flawed stage. Four of the stages where methodological flaws can create bias are described in detail. The final section attempts to determine how much influence the methodological flaws exerted on the results of the second-order meta-analysis. Keywords

## Methods

Abstract This article contains a second-order meta-analysis and an exploration of bias in the technology integration literature in higher education. Thirteen metaanalyses, dated from 2000 to 2014 were selected to be included based on the questions asked and the presence of adequate statistical information to conduct a quantitative synthesis. The weighted random effects average was g?? = 0.393, p \ .000. The article goes on to report an assessment of the methodological quality of the thirteen studies based on Cooper’s (Research synthesis and meta-analysis: a step-by-step approach. Sage, Thousand Oaks, 2010) seven stages in the development of a meta-analysis. Two meta-analyses were found to have five out of seven stages where methodological flaws could potentially create biased results. Five meta-analyses contained two flawed stages and one contained one flawed stage. Four of the stages where methodological flaws can create bias are described in detail. The final section attempts to determine how much influence the methodological flaws exerted on the results of the second-order meta-analysis. Keywords

## Results Or Findings

A related goal is to
estimate the variability (i.e., between-study variance) of a distribution of effect sizes in
order to judge whether it exceeds what would be expected by chance (i.e., sampling
error). These overlaps lead to dependencies in the data
that tend to inflate a and increase the possibility of making a Type I error (i.e.,
rejecting the null hypothesis when it should be accepted). In a secondorder meta-analysis the possibility of overlapping studies is high, but because the
standard error (i.e., the denominator of a z-ratio) is based on the number of studies,
instead of participants, the problem is less severe. We used the reported average adjusted
weighted effect sizes but produced separately calculated standard errors.

## Discussion Or Conclusion

As a result, the standard error for each metaanalysis is more conservative (i.e., larger) than was reported in the original firstorder meta-analyses. In addition, an effect size by sample size (represented by the standard error)
plot, called a ‘‘funnel plot’’ can help a meta-analyst visualize the shape and
symmetry of the distribution. As stated previously, a
funnel plot (i.e., effect size by standard error) of these effect sizes produced
symmetry around the weighted average of random effects mean of 0.393 indicating
that no additional studies needed to be imputed. Bias in meta-analysis
Methodological bias has been defined as systematic inaccuracy in data due to
characteristics of the processes employed in its collection, manipulation, analysis,
interpretation and/or presentation of research findings (Bernard 2014).

## Limitations

No clean limitations passage isolated automatically.
