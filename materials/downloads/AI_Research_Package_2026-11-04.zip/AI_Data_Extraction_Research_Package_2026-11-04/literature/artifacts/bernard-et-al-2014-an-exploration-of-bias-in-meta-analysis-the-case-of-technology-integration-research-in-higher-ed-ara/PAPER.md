---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa"
source_note: "wiki/sources/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.md"
source_path: "raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.md`
- Source path: `raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

J Comput High Educ (2014) 26:183–209
DOI 10.1007/s12528-014-9084-z

An exploration of bias in meta-analysis: the case
of technology integration research in higher education
Robert M. Bernard • Eugene Borokhovski •
Richard F. Schmid • Rana M. Tamim

Published online: 12 November 2014
 Springer Science+Business Media New York 2014

Abstract This article contains a second-order meta-analysis and an exploration of
bias in the technology integration literature in higher education. Thirteen metaanalyses, dated from 2000 to 2014 were selected to be included based on the
questions asked and the presence of adequate statistical information to conduct a
quantitative synthesis. The weighted random effects average was g?? = 0.393,
p \ .000. The article goes on to report an assessment of the methodological quality
of the thirteen studies based on Cooper’s (Research synthesis and meta-analysis: a
step-by-step approach. Sage, Thousand Oaks, 2010) seven stages in the development of a meta-analysis. Two meta-analyses were found to have five out of seven
stages where methodological flaws could potentially create biased results. Five
meta-analyses contained two flawed stages and one contained one flawed stage.
Four of the stages where methodological flaws can create bias are described in
detail. The final section attempts to determine how much influence the methodological flaws exerted on the results of the second-order meta-analysis.
Keywords

Technology  Computers  Meta-analysis  Bias  Higher education

Introduction
In April of 2014 our research team published an article (Bernard et al. 2014) in the
Journal of Computing in Higher Education entitled ‘‘A Meta-analysis of Blended
Learning and Technology use in Higher Education: From the General to the
R. M. Bernard (&)  E. Borokhovsk

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
