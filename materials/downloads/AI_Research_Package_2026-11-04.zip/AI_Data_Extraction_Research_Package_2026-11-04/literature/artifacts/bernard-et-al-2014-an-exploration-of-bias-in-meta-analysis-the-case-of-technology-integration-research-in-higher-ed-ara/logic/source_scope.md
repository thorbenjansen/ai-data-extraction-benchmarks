# Source Scope

## Strong Uses

- Use as `background meta-research or synthesis-methods evidence` in the AI Data Extraction branch.
- Use for retrieval around AI/evidence-synthesis methods.

## Weak Uses

- Do not treat this automated ARA as citation-grade for exact numbers without checking the PDF.
- Do not infer model superiority from abstract-level claims alone.
- Do not treat human-AI agreement or model confidence as validation unless the source itself defines and tests that standard.

## Transfer Boundaries

- Domain, document type, extraction target, model/tool version, and human adjudication design may limit transfer to the main AI data extraction paper.

## Citation-Grade Verification Needs

- Re-open `raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf`.
- Confirm the exact extraction task and evaluation metric.
- Confirm whether the source evaluates data extraction specifically or an adjacent task such as screening, annotation, risk-of-bias, or literature search.
