# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `background meta-research or synthesis-methods evidence`.
- Provisional design: `systematic-review/meta-analysis`.
- Top automated-data-extraction terms in source text: none found.

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- A related goal is to
estimate the variability (i.e., between-study variance) of a distribution of effect sizes in
order to judge whether it exceeds what would be expected by chance (i.e., sampling
error).
- These overlaps lead to dependencies in the data
that tend to inflate a and increase the possibility of making a Type I error (i.e.,
rejecting the null hypothesis when it should be accepted).
- In a secondorder meta-analysis the possibility of overlapping studies is high, but because the
standard error (i.e., the denominator of a z-ratio) is based on the number of studies,
instead of participants, the problem is less severe.
- We used the reported average adjusted
weighted effect sizes but produced separately calculated standard errors.
- As a result, the standard error for each metaanalysis is more conservative (i.e., larger) than was reported in the original firstorder meta-analyses.
- In addition, an effect size by sample size (represented by the standard error)
plot, called a ‘‘funnel plot’’ can help a meta-analyst visualize the shape and
symmetry of the distribution.
- As stated previously, a
funnel plot (i.e., effect size by standard error) of these effect sizes produced
symmetry around the weighted average of random effects mean of 0.393 indicating
that no additional studies needed to be imputed.
- Bias in meta-analysis
Methodological bias has been defined as systematic inaccuracy in data due to
characteristics of the processes employed in its collection, manipulation, analysis,
interpretation and/or presentation of research findings (Bernard 2014).
- Where disagreements did arise,
they were settled through discussion between the reviewers.
- Since studies found in
this way are, by definition, not present in the public record, another reviewer
attempting a replication cannot examine the original studies without contacting the
same authors.
- Creating and maintaining a ‘‘trials register’’ (i.e., a very large
database of individual intervention studies) is one way of providing reviewers with
difficult to access studies.
- Accuracy in these processes is critical to maintaining the
quality of a meta-analysis and minimizing bias.
