# Method And Design

## Source Identity

- Title: Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa
- ARA: `bernard-et-al-2014-an-exploration-of-bias-in-meta-analysis-the-case-of-technology-integration-research-in-higher-ed-ara`
- Source PDF: `raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `background meta-research or synthesis-methods evidence`

## Data, Sample, Or Source Material

Abstract This article contains a second-order meta-analysis and an exploration of bias in the technology integration literature in higher education. Thirteen metaanalyses, dated from 2000 to 2014 were selected to be included based on the questions asked and the presence of adequate statistical information to conduct a quantitative synthesis. The weighted random effects average was g?? = 0.393, p \ .000. The article goes on to report an assessment of the methodological quality of the thirteen studies based on Cooper’s (Research synthesis and meta-analysis: a step-by-step approach. Sage, Thousand Oaks, 2010) seven stages in the development of a meta-analysis. Two meta-analyses were found to have five out of seven stages where methodological flaws could potentially create biased results. Five meta-analyses contained two flawed stages and one contained one flawed stage. Four of the stages where methodological flaws can create bias are described in detail. The final section attempts to determine how much influence the methodological flaws exerted on the results of the second-order meta-analysis. Keywords

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

A related goal is to
estimate the variability (i.e., between-study variance) of a distribution of effect sizes in
order to judge whether it exceeds what would be expected by chance (i.e., sampling
error). These overlaps lead to dependencies in the data
that tend to inflate a and increase the possibility of making a Type I error (i.e.,
rejecting the null hypothesis when it should be accepted). In a secondorder meta-analysis the possibility of overlapping studies is high, but because the
standard error (i.e., the denominator of a z-ratio) is based on the number of studies,
instead of participants, the problem is less severe. We used the reported average adjusted
weighted effect sizes but produced separately calculated standard errors.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
