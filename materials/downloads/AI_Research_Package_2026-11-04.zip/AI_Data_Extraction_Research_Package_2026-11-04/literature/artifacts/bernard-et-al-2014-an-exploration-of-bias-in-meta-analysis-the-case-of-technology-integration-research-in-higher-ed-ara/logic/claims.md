# Claims

- C01: `Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf`.
