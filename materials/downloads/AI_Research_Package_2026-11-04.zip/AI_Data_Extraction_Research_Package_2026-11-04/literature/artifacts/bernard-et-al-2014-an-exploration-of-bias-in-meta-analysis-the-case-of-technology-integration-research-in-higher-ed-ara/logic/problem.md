# Problem

This ARA preserves a branch-local retrieval entry point for `Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
