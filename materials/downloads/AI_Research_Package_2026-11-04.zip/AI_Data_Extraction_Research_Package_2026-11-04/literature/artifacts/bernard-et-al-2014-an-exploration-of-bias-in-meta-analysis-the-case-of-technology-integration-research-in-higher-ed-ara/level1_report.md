# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Bernard et al. - 2014 - An exploration of bias in meta-analysis The case of technology integration research in higher educa.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
