---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication"
source_note: "wiki/sources/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.md"
source_path: "raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.md`
- Source path: `raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Beller et al. Systematic Reviews 2013, 2:36
http://www.systematicreviewsjournal.com/content/2/1/36

RESEARCH

Open Access

Are systematic reviews up-to-date at the time of
publication?
Elaine M Beller1, Joyce Kee-Hsin Chen2,3,4,5, Una Li-Hsiang Wang3,6 and Paul P Glasziou1*

Abstract
Background: Systematic reviews provide a synthesis of evidence for practitioners, for clinical practice guideline
developers, and for those designing and justifying primary research. Having an up-to-date and comprehensive
review is therefore important. Our main objective was to determine the recency of systematic reviews at the time
of their publication, as measured by the time from last search date to publication. We also wanted to study the
time from search date to acceptance, and from acceptance to publication, and measure the proportion of
systematic reviews with recorded information on search dates and information sources in the abstract and full text
of the review.
Methods: A descriptive analysis of published systematic reviews indexed in Medline in 2009, 2010 and 2011 by
three reviewers, independently extracting data.
Results: Of the 300 systematic reviews included, 271 (90%) provided the date of search in the full-text article, but
only 141 (47%) stated this in the abstract. The median (standard error; minimum to maximum) survival time from
last search to acceptance was 5.1 (0.58; 0 to 43.8) months (95% confidence interval = 3.9 to 6.2) and from last
search to first publication time was 8.0 (0.35; 0 to 46.7) months (95% confidence interval = 7.3 to 8.7), respectively.
Of the 300 reviews, 295 (98%) stated which databases had been searched, but only 181 (60%) stated the databases
in the abstract. Most researchers searched three (35%) or four (21%) databases. The top-three most used da

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
