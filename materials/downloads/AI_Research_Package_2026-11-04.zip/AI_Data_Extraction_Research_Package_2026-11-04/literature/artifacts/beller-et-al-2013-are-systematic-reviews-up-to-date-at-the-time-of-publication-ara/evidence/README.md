# Evidence README

## Source Pointer

- PDF: `raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Beller et al. Systematic Reviews 2013, 2:36
http://www.systematicreviewsjournal.com/content/2/1/36

RESEARCH

Open Access

Are systematic reviews up-to-date at the time of
publication?
Elaine M Beller1, Joyce Kee-Hsin Chen2,3,4,5, Una Li-Hsiang Wang3,6 and Paul P Glasziou1*

Abstract
Background: Systematic reviews provide a synthesis of evidence for practitioners, for clinical practice guideline
developers, and for those designing and justifying primary research. Having an up-to-date and comprehensive
review is therefore important. Our main objective was to determine the recency of systematic reviews at the time
of their publication, as measured by the time from last search date to publication. We also wanted to study the
time from search date to acceptance, and from acceptance to publication, and measure the proportion of
systematic reviews with recorded information on search dates and information sources in the abstract and full text
of the review.
Methods: A descriptive analysis of published systematic reviews indexed in Medline in 2009, 2010 and 2011 by
three reviewers, independently extracting data.
Results: Of the 300 systematic reviews included, 271 (90%) provided the date of search in the full-text article, but
only 141 (47%) stated this in the abstract. The median (standard error; minimum to maximum) survival time from
last search to acceptance was 5.1 (0.58; 0 to 43.8) months (95% confidence interval = 3.9 to 6.2) and from last
search to first publication time was 8.0 (0.35; 0 to 46.7) months (95% confidence interval = 7.3 to 8.7), respectively.
Of the 300 reviews, 295 (98%) stated which databases had been searched, but only 181 (60%) stated the databases
in the abstract. Most researchers searched three (35%) or four (21%) databases. The top-three most used da
