# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `review` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | data extraction (3), screening (1) |
| Verification status | Needs human source-checking before exact citation |
