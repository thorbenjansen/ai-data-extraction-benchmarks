# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `review`.
- Top automated-data-extraction terms in source text: data extraction (3), screening (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Methods: A descriptive analysis of published systematic reviews indexed in Medline in 2009, 2010 and 2011 by
three reviewers, independently extracting data.
- The median (standard error; minimum to maximum) survival time from
last search to acceptance was 5.1 (0.58; 0 to 43.8) months (95% confidence interval = 3.9 to 6.2) and from last
search to first publication time was 8.0 (0.35; 0 to 46.7) months (95% confidence interval = 7.3 to 8.7), respectively.
- Secondary objectives were to ascertain
how much of the time from search date to publication
was caused by delays in submission and revision of manuscripts, as compared with delays in the publishing lead
time, and to determine whether authors provided information on search dates and database sources in the
abstract of the review, as this is often the only part of a
systematic review that is read by someone screening for
relevant papers.
- Methods
Data search, study selection and data extraction

We collected all systematic review articles indexed in
Medline each year from 2009 to 2011 from the

Page 2 of 6

National Library of Medicine’s Core Clinical Journals
(CCJ) subset of journals [11].
- One reviewer screened titles
and abstracts initially, and then full texts, to determine
whether the article was a systematic review using only
two criteria: that a search strategy was described, and
it appeared that all eligible papers were used in the review (for example, table of included studies or similar).
- A second reviewer independently assessed any reports
where the classification was deemed unclear.
- Data were collected from abstracts and full texts by
one reviewer (EMB), with a 10% sample also independently extracted by two reviewers (JK-HC and UL-HW)
for quality checking.
- The data extraction items included
the following descriptive information: name of the journal, first author, and year of publication.
- Systematic Reviews 2013, 2:36
http://www.systematicreviewsjournal.com/content/2/1/36

Data management and statistical analysis

All data extraction was managed by Microsoft Office
InfoPath.
- Since reviews can date rapidly [8], this
delay is important to users of reviewers.
- Editors and peer
reviewers should expect authors to demonstrate compliance with the PRISMA Statement guidance on submission of their article.
- Sutton A, Cooper N, Jones D: Evidence synthesis as the key to more
coherent and efficient research.
