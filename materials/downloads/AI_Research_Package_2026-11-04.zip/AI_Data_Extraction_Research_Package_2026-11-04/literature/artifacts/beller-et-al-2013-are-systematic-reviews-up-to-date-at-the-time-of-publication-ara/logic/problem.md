# Problem

This ARA preserves a branch-local retrieval entry point for `Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
