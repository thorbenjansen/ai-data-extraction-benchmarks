# Claims

- C01: `Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]], [[LLM Accuracy]], [[Speed-Accuracy Tradeoff]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf`.
