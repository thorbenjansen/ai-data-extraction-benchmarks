# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf`.
- Raw Markdown path: `not available`.
