# Method And Design

## Source Identity

- Title: Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication
- ARA: `beller-et-al-2013-are-systematic-reviews-up-to-date-at-the-time-of-publication-ara`
- Source PDF: `raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `review`
- Branch role: `direct automated-data-extraction evidence`

## Data, Sample, Or Source Material

National Library of Medicine’s Core Clinical Journals (CCJ) subset of journals [11]. The CCJ subset was chosen because we wanted a broader selection of journals than the major general medical ones, but needed to limit the search due to the large number of citations to screen to determine which of these were systematic reviews. The CCJ journals are those ‘recommended for individual practitioners and libraries of small hospitals and clinics’ [11]. We used the broad definition of a systematic review previously used by Moher and colleagues in their study of the epidemiology of systematic reviews: ‘… the authors’ stated objective was to summarize evidence from multiple studies, and the article described explicit methods, regardless of the details provided’ [12]. The eligible reviews were found using the same search strategy as was used in their study. One reviewer screened titles and abstracts initially, and then full texts, to determine whether the article was a systematic review using only two criteria: that a search strategy was described, and it appeared that all eligible papers were used in the review (for example, table of included studies or similar). A second reviewer independently assessed any reports where the classification was deemed unclear. All systematic reviews about interventions (n = 860) formed the population from which to sample. Using the random number generator in Excel, we randomly selected 100 intervention reviews from each year. Data were collected from abstracts and full texts by one reviewer (EMB), with a 10% sample also independently extracted by two reviewers (JK-HC and UL-HW) for quality checking. The data extraction items included the following descriptive information: name of the journal, first author, and year of publication. From each study we extracted details on date of search, date of first publication (for example, online publication if ahead of print), and date of acceptance (where available). If the exact search date was not presented, the end of the month was used (for example, 31 October). Additionally, we checked the date of publication from the journal website if it was not printed on the article. Finally, the databases that had been searched in each systematic review were recorded.

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

All data extraction was managed by Microsoft Office InfoPath. Statistical analysis was conducted with SPSS, v.17 (Chicago, IL, USA). Descriptive statistics were used to summarize the data, using the number and proportion (%) to describe categorical variables and the mean, median, minimum, maximum and standard deviation for continuous variables. A survival analysis was conducted to determine the median time from search to acceptance and publication in published systematic reviews. A Kaplan–Meier curve was used to represent graphically the results of the survival analysis.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
