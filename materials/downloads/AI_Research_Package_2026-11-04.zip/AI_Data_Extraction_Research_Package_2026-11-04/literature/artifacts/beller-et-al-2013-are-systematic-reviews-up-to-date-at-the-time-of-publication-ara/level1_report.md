# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Beller et al. - 2013 - Are systematic reviews up-to-date at the time of publication.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
