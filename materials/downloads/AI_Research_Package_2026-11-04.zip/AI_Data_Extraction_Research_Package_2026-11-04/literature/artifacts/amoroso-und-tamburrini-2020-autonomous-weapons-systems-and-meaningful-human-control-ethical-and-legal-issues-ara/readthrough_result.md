# Read-Through Result

## Source Identity Check

- Title: Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues
- Source PDF: `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `needs-further-coding`
- Branch role: `branch-adjacent context`

## Results Or Findings Check

Abstract Purpose of Review To provide readers with a compact account of ongoing academic and diplomatic debates about autonomy in weapons systems, that is, about the moral and legal acceptability of letting a robotic system to unleash destructive force in warfare and take attendant life-or-death decisions without any human intervention. Recent Findings A précis of current debates is provided, which focuses on the requirement that all weapons systems, including autonomous ones, should remain under meaningful human control (MHC) in order to be ethically acceptable and lawfully employed. Main approaches to MHC are described and briefly analyzed, distinguishing between uniform, differentiated, and prudential policies for human control on weapons systems. Summary The review highlights the crucial role played by the robotics research community to start ethical and legal debates about autonomy in weapons systems. A concise overview is provided of the main concerns emerging in those early debates: respect of the laws of war, responsibility ascription issues, violation of the human dignity of potential victims of autonomous weapons systems, and increased risks for global stability. It is pointed out that these various concerns have been jointly taken to support the idea that all weapons systems, including autonomous ones, should remain under meaningful human control (MHC). Main approaches to MHC are described and briefly analyzed. Finally, it is emphasized that the MHC idea looms large on shared control policies to adopt in other ethically and legally sensitive application domains for robotics and artificial intelligence. Keywords Autonomous weapons systems . Roboethics . International humanitarian law . Human-robot shared control . Meaningful human control

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
