# Problem

This ARA preserves a branch-local retrieval entry point for `Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
