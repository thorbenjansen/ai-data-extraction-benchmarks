# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `branch-adjacent context`.
- Provisional design: `needs-further-coding`.
- Top automated-data-extraction terms in source text: llm (2), artificial intelligence (2).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Recent Findings A précis of current debates is provided, which focuses on the requirement that all weapons systems, including
autonomous ones, should remain under meaningful human control (MHC) in order to be ethically acceptable and lawfully
employed.
- Main approaches to MHC are described and briefly analyzed, distinguishing between uniform, differentiated, and
prudential policies for human control on weapons systems.
- A concise overview is provided of the main concerns emerging in those early debates:
respect of the laws of war, responsibility ascription issues, violation of the human dignity of potential victims of autonomous
weapons systems, and increased risks for global stability.
- It is pointed out that these various concerns have been jointly taken to
support the idea that all weapons systems, including autonomous ones, should remain under meaningful human control (MHC).
- Meaningful human control

Introduction
Robotics has extensively contributed to modify defense systems.
- These targeted
killings have raised concerns about the infringement of other
States’ sovereignty and overly permissive application of lethal
force in counter-terrorism operations [5–7].
- One should carefully note that the release of destructive
force by any weaponized robot in the above list is firmly in
the hands of human operators.
- To count as autonomous, a weapons system must be able to
select and engage targets without any human intervention after
its activation [8••, 9, 10].
- The technological realities and prospects of AWS raise a
major ethical and legal issue: Is it permissible to let a robotic
system unleash destructive force and take attendant life-or-death
decisions without any human intervention?
- An
idea that has rapidly gained ground across the opinion spectrum
in this debate is that all weapons systems, including autonomous
ones, should remain under meaningful human control (MHC) in
order to be ethically acceptable and lawfully employed (see the
reports by the UK-based NGO Article 36 [26, 27]).
- Then, the main
proposals regarding the MHC content are introduced and analyzed, including our own proposal of a “differentiated and
prudential” human control policy on AWS.
- He was concerned about the poor record of
human compliance with international norms governing the
conduct of belligerent parties in warfare (Laws of War or
international humanitarian law (IHL)).
