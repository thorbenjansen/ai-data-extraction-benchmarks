# Claims

- C01: `Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf`.
