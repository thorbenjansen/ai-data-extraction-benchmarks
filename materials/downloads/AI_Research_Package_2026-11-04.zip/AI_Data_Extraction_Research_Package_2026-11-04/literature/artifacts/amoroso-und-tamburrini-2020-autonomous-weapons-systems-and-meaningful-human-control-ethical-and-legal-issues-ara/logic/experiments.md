# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf`.
- Raw Markdown path: `not available`.
