# Method And Design

## Source Identity

- Title: Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues
- ARA: `amoroso-und-tamburrini-2020-autonomous-weapons-systems-and-meaningful-human-control-ethical-and-legal-issues-ara`
- Source PDF: `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `needs-further-coding`
- Branch role: `branch-adjacent context`

## Data, Sample, Or Source Material

Concluding Remarks Recent advances in autonomous military robotics have raised unprecedented ethical and legal issues. Regrettably, diplomatic discussions at the GGE in Geneva not only have so far fallen short of working out a veritable legal regime on meaningful human control over AWS, but—what is worse—are currently facing a stalemate, which is mainly determined by the opposition of major military powers, including the US and the Russian Federation, to the adoption of any kind of international regulation on the matter. Our proposal of relinquishing the quest for a one-size-fitsall solution to the MHC issue in favor of a suitably differentiated approach may help sidestep current stumbling blocks. Diplomatic and political discontent about an MHC requirement that is overly restrictive with respect to the limited autonomy of some weapons systems might indeed be mitigated recognizing the possibility of negotiating exceptions to L1–L2 human control, by identifying weapons systems and contexts of use where milder forms of human control will suffice to ensure the fulfillment of the fail-safe, accountability, and moral agency properties whose preservation generally underpins the normative concerns about weapons’ autonomy in targeting critical functions. In a broader perspective, a differentiated approach to MHC may be of some avail as regards the general issue of human control over intelligent machines operating in ethically and legally sensitive domains, insofar as the MHC language has been recently used about autonomous vehicles [76, 77] and surgical robots [78]. Funding Information Open access funding provided by Università degli Studi di Cagliari within the CRUI-CARE Agreement.

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Abstract Purpose of Review To provide readers with a compact account of ongoing academic and diplomatic debates about autonomy in weapons systems, that is, about the moral and legal acceptability of letting a robotic system to unleash destructive force in warfare and take attendant life-or-death decisions without any human intervention. Recent Findings A précis of current debates is provided, which focuses on the requirement that all weapons systems, including autonomous ones, should remain under meaningful human control (MHC) in order to be ethically acceptable and lawfully employed. Main approaches to MHC are described and briefly analyzed, distinguishing between uniform, differentiated, and prudential policies for human control on weapons systems. Summary The review highlights the crucial role played by the robotics research community to start ethical and legal debates about autonomy in weapons systems. A concise overview is provided of the main concerns emerging in those early debates: respect of the laws of war, responsibility ascription issues, violation of the human dignity of potential victims of autonomous weapons systems, and increased risks for global stability. It is pointed out that these various concerns have been jointly taken to support the idea that all weapons systems, including autonomous ones, should remain under meaningful human control (MHC). Main approaches to MHC are described and briefly analyzed. Finally, it is emphasized that the MHC idea looms large on shared control policies to adopt in other ethically and legally sensitive application domains for robotics and artificial intelligence. Keywords Autonomous weapons systems . Roboethics . International humanitarian law . Human-robot shared control . Meaningful human control

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
