# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
