---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues"
source_note: "wiki/sources/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.md"
source_path: "raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.md`
- Source path: `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Current Robotics Reports (2020) 1:187–194
https://doi.org/10.1007/s43154-020-00024-3

ROBOETHICS (G VERUGGIO, SECTION EDITOR)

Autonomous Weapons Systems and Meaningful Human Control:
Ethical and Legal Issues
Daniele Amoroso 1

& Guglielmo Tamburrini

2

Published online: 24 August 2020
# The Author(s) 2020

Abstract
Purpose of Review To provide readers with a compact account of ongoing academic and diplomatic debates about autonomy in
weapons systems, that is, about the moral and legal acceptability of letting a robotic system to unleash destructive force in warfare
and take attendant life-or-death decisions without any human intervention.
Recent Findings A précis of current debates is provided, which focuses on the requirement that all weapons systems, including
autonomous ones, should remain under meaningful human control (MHC) in order to be ethically acceptable and lawfully
employed. Main approaches to MHC are described and briefly analyzed, distinguishing between uniform, differentiated, and
prudential policies for human control on weapons systems.
Summary The review highlights the crucial role played by the robotics research community to start ethical and legal debates
about autonomy in weapons systems. A concise overview is provided of the main concerns emerging in those early debates:
respect of the laws of war, responsibility ascription issues, violation of the human dignity of potential victims of autonomous
weapons systems, and increased risks for global stability. It is pointed out that these various concerns have been jointly taken to
support the idea that all weapons systems, including autonomous ones, should remain under meaningful human control (MHC).
Main approaches to MHC are described and briefly analyzed. Finally, it is emphasized that the MHC idea

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
