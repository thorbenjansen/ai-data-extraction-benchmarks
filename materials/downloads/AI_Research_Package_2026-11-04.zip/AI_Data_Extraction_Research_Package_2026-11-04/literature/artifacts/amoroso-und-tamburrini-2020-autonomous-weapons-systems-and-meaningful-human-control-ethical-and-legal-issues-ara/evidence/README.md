# Evidence README

## Source Pointer

- PDF: `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Current Robotics Reports (2020) 1:187–194
https://doi.org/10.1007/s43154-020-00024-3

ROBOETHICS (G VERUGGIO, SECTION EDITOR)

Autonomous Weapons Systems and Meaningful Human Control:
Ethical and Legal Issues
Daniele Amoroso 1

& Guglielmo Tamburrini

2

Published online: 24 August 2020
# The Author(s) 2020

Abstract
Purpose of Review To provide readers with a compact account of ongoing academic and diplomatic debates about autonomy in
weapons systems, that is, about the moral and legal acceptability of letting a robotic system to unleash destructive force in warfare
and take attendant life-or-death decisions without any human intervention.
Recent Findings A précis of current debates is provided, which focuses on the requirement that all weapons systems, including
autonomous ones, should remain under meaningful human control (MHC) in order to be ethically acceptable and lawfully
employed. Main approaches to MHC are described and briefly analyzed, distinguishing between uniform, differentiated, and
prudential policies for human control on weapons systems.
Summary The review highlights the crucial role played by the robotics research community to start ethical and legal debates
about autonomy in weapons systems. A concise overview is provided of the main concerns emerging in those early debates:
respect of the laws of war, responsibility ascription issues, violation of the human dignity of potential victims of autonomous
weapons systems, and increased risks for global stability. It is pointed out that these various concerns have been jointly taken to
support the idea that all weapons systems, including autonomous ones, should remain under meaningful human control (MHC).
Main approaches to MHC are described and briefly analyzed. Finally, it is emphasized that the MHC idea
