# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Amoroso und Tamburrini - 2020 - Autonomous Weapons Systems and Meaningful Human Control Ethical and Legal Issues.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `needs-further-coding` |
| Branch role | `branch-adjacent context` |
| Top terms | llm (2), artificial intelligence (2) |
| Verification status | Needs human source-checking before exact citation |
