# Level 3 Report

- Automated read-through completed: 2026-05-12.
- Status assigned: `automated-level-3`.
- Source considered: `raw/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.pdf`.
- Evidence files added:
  - `evidence/passages/readthrough_key_passages.md`
  - `evidence/tables/readthrough_evidence_map.md`
- Logic files added/refreshed:
  - `logic/method_and_design.md`
  - `logic/methods_variables_outcomes.md`
  - `logic/source_scope.md`
- Remaining work: human close-reading curation before `curated-level-3`.
