# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `background meta-research or synthesis-methods evidence`.
- Provisional design: `systematic-review/meta-analysis`.
- Top automated-data-extraction terms in source text: screening (5), data extraction (4).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Keywords: male suicide, suicide prevention, systematic review, metasynthesis, qualitative meta-analysis
Supplemental materials: https://doi.org/10.1037/bul0000397.supp

Suicide is one of the most complex human behaviors to understand,
transgressing our biological drive to survive and reproduce, and the
cultural idea of existence as sacred (Aubin et al., 2013; Perry, 2014;
Ringel, 1976; Soper, 2018).
- Humans are social beings, and the
propensity to accrue psychological pain is woven into our
interpersonal dynamics.
- Nonetheless, considering
evolutionary pressures for effective regulation in speciﬁc domains
of human life could help shape hypotheses as to why the
dysregulation of certain phenomena could lead to the emergence
and enactment of a behavior contrary to the evolutionary drive
to live.
- In a species where social
connection became increasingly critical to survival, this co-option
may have provided humans with a biological mechanism by which
to regulate their behavior in service of maintaining social safety and
indicate when they might be in social danger.
- Soper (2018) went further in his
“pain and brain” theory and claimed suicide was the detrimental
by-product of not just the evolution of pain but also the evolution
of the mature human brain that could conceive and enact suicide to
escape that pain.
- Culture permeates human behavior, including the meanings
and understandings shared by people (Heine, 2007; Laubscher,
2003); for example, what emotions are considered socially acceptable
for men?
- All
methodologies have their strengths and weaknesses, and the lack of
concrete progress in suicidology has led to a growing recognition
that qualitative and quantitative researchers need to work together to
utilize each other’s strengths in support of enhancing our
understanding of this painful human plight (Goldney, 2002;
Greenhalgh et al., 2016; Hjelmeland & Knizek, 2010; Lester,
2002; Ojagbemi, 2017).
- In recognition of our own implicit and
explicit biases, we employed a rigorous methodological approach—
documented here—to ensure the validity and reliability of our
ﬁndings, triangulated through multiple coauthors, peer reviewers,
and the editorial process.
- Screening
Inclusion and Exclusion Criteria
Studies included in this review were required to meet the following
criteria: (a) English language research published in the last 20 years in
peer-reviewed journals; (b) Qualitative or mixed-methods research
conducted anywhere in the world; (c) Participants aged 18 and over;
(d) Participants included men who have experienced suicidal
thoughts/feelings/attempts and/or people bereaved by male suicide.
- A
20-year timeframe also helped us accommodate sensitivity and
speciﬁcity, that is, sourcing a robust volume of studies (sensitivity)
that could purposefully address our research questions (speciﬁcity;
Siddaway et al., 2019; Willig & Wirth, 2018).
- While we wanted
to have good sensitivity of reach, we also wanted to maintain
speciﬁcity by ensuring ﬁndings were as relevant as possible to
understanding male risk and recovery factors in contemporary
environments—a 20-year framework felt appropriate for this.
- Thomas and Harden (2008) noted that it is important to

A scoping search was conducted on January 14, 2020, and the
review was then registered on PROSPERO (CRD42020166686)
before the ofﬁcial screening process began.
