# Problem

This ARA preserves a branch-local retrieval entry point for `Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
