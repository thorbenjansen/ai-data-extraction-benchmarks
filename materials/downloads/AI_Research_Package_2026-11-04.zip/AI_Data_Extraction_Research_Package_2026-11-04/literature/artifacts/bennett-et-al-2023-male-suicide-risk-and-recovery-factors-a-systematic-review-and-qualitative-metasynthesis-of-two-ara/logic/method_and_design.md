# Method And Design

## Source Identity

- Title: Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec
- ARA: `bennett-et-al-2023-male-suicide-risk-and-recovery-factors-a-systematic-review-and-qualitative-metasynthesis-of-two-ara`
- Source PDF: `raw/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `background meta-research or synthesis-methods evidence`

## Data, Sample, Or Source Material

Data Extraction There are various ways of conducting a qualitative metasynthesis and our systematic review employed Thomas and Harden’s Thematic Synthesis method (2008). Like Levitt (2018), “we wanted the analysis to be anchored in the original data, but use this as a means to establish wider theoretical conceptualizations” (p. 372). We employed an inductive approach to the analysis, which involved interpreting patterns and themes from within the data without being guided by a preexisting theoretical framework. Instead, we used the contents of the studies as the basis for exploring potential relationships and patterns within the texts (Thomas & Harden, 2008). When conducting a qualitative metasynthesis, authors must decide what text from primary studies will constitute data for their review (Finfgeld, 2003). To gain as much insight as possible, our data extraction included data from the ﬁndings, discussion, and conclusions of each primary study, including both participant quotes and the authors’ interpretations (Lachal et al., 2015). Two studies included participants under 18, but only ﬁndings attributed to all participants, or quotes attributed to men over 18, were included. Similarly, in studies where participants’ gender was mixed, only ﬁndings relating speciﬁcally to men, male attributed quotes, or ﬁndings relating to all project participants were reviewed. Data for this analysis were reviewed for anything that pertained to a risk or recovery factor as perceived or understood by participants or author/s. Risk factors were experiences identiﬁed in primary studies as potentially contributing to suicidal thoughts, feelings, and behaviors. Recovery factors were experiences identiﬁed in primary studies as potentially helping men live with thoughts and feelings of suicide. It is important to ﬂag that the qualitative nature of our data means the risk and recovery factors identiﬁed in this review do not imply a causal relationship (Van Orden et al., 2010). We operationalized the terms “risk factor” and “recovery factor” to refer to themes that were deemed sufﬁciently common across studies as to indicate a potential association between that theme and suicide risk/ recovery. This was an interpretative perspective and cannot be read as causal. A qualitative metasynthesis is iterative and as the coding developed there was enough variety in risk factor descriptions t

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Keywords: male suicide, suicide prevention, systematic review, metasynthesis, qualitative meta-analysis
Supplemental materials: https://doi.org/10.1037/bul0000397.supp

Suicide is one of the most complex human behaviors to understand,
transgressing our biological drive to survive and reproduce, and the
cultural idea of existence as sacred (Aubin et al., 2013; Perry, 2014;
Ringel, 1976; Soper, 2018). Humans are social beings, and the
propensity to accrue psychological pain is woven into our
interpersonal dynamics. Nonetheless, considering
evolutionary pressures for effective regulation in speciﬁc domains
of human life could help shape hypotheses as to why the
dysregulation of certain phenomena could lead to the emergence
and enactment of a behavior contrary to the evolutionary drive
to live. In a species where social
connection became increasingly critical to survival, this co-option
may have provided humans with a biological mechanism by which
to regulate their behavior in service of maintaining social safety and
indicate when they might be in social danger.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
