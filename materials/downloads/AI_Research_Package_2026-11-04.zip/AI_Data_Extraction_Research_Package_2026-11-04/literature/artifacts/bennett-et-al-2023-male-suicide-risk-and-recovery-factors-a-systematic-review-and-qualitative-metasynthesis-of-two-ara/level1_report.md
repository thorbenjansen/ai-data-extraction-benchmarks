# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
