---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec"
source_note: "wiki/sources/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.md"
source_path: "raw/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.md`
- Source path: `raw/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Psychological Bulletin
© 2023 American Psychological Association
ISSN: 0033-2909

2023, Vol. 149, Nos. 7–8, 371–417
https://doi.org/10.1037/bul0000397

Male Suicide Risk and Recovery Factors: A Systematic Review and
Qualitative Metasynthesis of Two Decades of Research
Susanna Bennett1, Kathryn A. Robb2, Tiago C. Zortea1, 3, Adele Dickson4,
Cara Richardson1, and Rory C. O’Connor1

This document is copyrighted by the American Psychological Association or one of its allied publishers.
This article is intended solely for the personal use of the individual user and is not to be disseminated broadly.

1

Suicidal Behaviour Research Laboratory, School of Health and Wellbeing, University of Glasgow
2
Cancer Behaviour Research Group, School of Health and Wellbeing, University of Glasgow
3
Oxford Institute of Clinical Psychology Training and Research, University of Oxford
4
Department of Psychology, School of Social Sciences, Heriot-Watt University Edinburgh
Suicide is a gendered phenomenon, where male deaths outnumber those of women virtually everywhere
in the world. Quantitative work has dominated suicide research producing important insights but only a
limited understanding of why more men die by suicide. We conducted a qualitative metasynthesis and
systematic review of 20 years of narratives both from men who are suicidal and from people who are
bereaved by male suicide to identify putative risk and recovery factors. We identiﬁed 78 studies that
encapsulated insights from over 1,695 people. Using Thomas and Harden’s Thematic Synthesis Method,
our analysis is built on 1,333 basic codes, 24 descriptive themes, and four analytical themes. We noted an
association between cultural norms of masculinity and suicide risk in 96% of studies. Norms relating to
male emotional suppression

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
