# Evidence README

## Source Pointer

- PDF: `raw/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Psychological Bulletin
© 2023 American Psychological Association
ISSN: 0033-2909

2023, Vol. 149, Nos. 7–8, 371–417
https://doi.org/10.1037/bul0000397

Male Suicide Risk and Recovery Factors: A Systematic Review and
Qualitative Metasynthesis of Two Decades of Research
Susanna Bennett1, Kathryn A. Robb2, Tiago C. Zortea1, 3, Adele Dickson4,
Cara Richardson1, and Rory C. O’Connor1

This document is copyrighted by the American Psychological Association or one of its allied publishers.
This article is intended solely for the personal use of the individual user and is not to be disseminated broadly.

1

Suicidal Behaviour Research Laboratory, School of Health and Wellbeing, University of Glasgow
2
Cancer Behaviour Research Group, School of Health and Wellbeing, University of Glasgow
3
Oxford Institute of Clinical Psychology Training and Research, University of Oxford
4
Department of Psychology, School of Social Sciences, Heriot-Watt University Edinburgh
Suicide is a gendered phenomenon, where male deaths outnumber those of women virtually everywhere
in the world. Quantitative work has dominated suicide research producing important insights but only a
limited understanding of why more men die by suicide. We conducted a qualitative metasynthesis and
systematic review of 20 years of narratives both from men who are suicidal and from people who are
bereaved by male suicide to identify putative risk and recovery factors. We identiﬁed 78 studies that
encapsulated insights from over 1,695 people. Using Thomas and Harden’s Thematic Synthesis Method,
our analysis is built on 1,333 basic codes, 24 descriptive themes, and four analytical themes. We noted an
association between cultural norms of masculinity and suicide risk in 96% of studies. Norms relating to
male emotional suppression
