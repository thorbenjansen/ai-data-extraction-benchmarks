# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Bennett et al. - 2023 - Male suicide risk and recovery factors A systematic review and qualitative metasynthesis of two dec.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `systematic-review/meta-analysis` |
| Branch role | `background meta-research or synthesis-methods evidence` |
| Top terms | screening (5), data extraction (4) |
| Verification status | Needs human source-checking before exact citation |
