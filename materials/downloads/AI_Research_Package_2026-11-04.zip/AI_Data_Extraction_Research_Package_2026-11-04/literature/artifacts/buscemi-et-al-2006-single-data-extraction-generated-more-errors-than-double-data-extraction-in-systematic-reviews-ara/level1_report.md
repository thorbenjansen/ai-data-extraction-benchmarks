# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
