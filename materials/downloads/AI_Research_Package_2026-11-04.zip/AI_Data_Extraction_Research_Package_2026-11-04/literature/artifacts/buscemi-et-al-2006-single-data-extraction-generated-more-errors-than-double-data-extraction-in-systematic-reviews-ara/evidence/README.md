# Evidence README

## Source Pointer

- PDF: `raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Journal of Clinical Epidemiology 59 (2006) 697–703

Single data extraction generated more errors than double data
extraction in systematic reviews
Nina Buscemi*, Lisa Hartling, Ben Vandermeer, Lisa Tjosvold, Terry P. Klassen
Department of Pediatrics, University of Alberta/Capital Health Evidence-Based Practice Centre, 11402 University Avenue,
Aberhart Centre One, Room 8414, Edmonton, Alberta T6G 2J3, Canada
Accepted 15 November 2005

Abstract
Background and Objective: To conduct a pilot study to compare the frequency of errors that accompany single vs. double data
extraction, compare the estimate of treatment effect derived from these methods, and compare the time requirements for these methods.
Methods: Reviewers were randomized to the role of data extractor or data verifier, and were blind to the study hypothesis. The frequency of errors associated with each method of data extraction was compared using the McNemar test. The data set for each method
was used to calculate an efficacy estimate by each method, using standard meta-analytic techniques. The time requirement for each method
was compared using a paired t-test.
Results: Single data extraction resulted in more errors than double data extraction (relative difference: 21.7%, P 5 .019). There was no
substantial difference between methods in effect estimates for most outcomes. The average time spent for single data extraction was less
than the average time for double data extraction (relative difference: 36.1%, P 5 .003).
Conclusion: In the case that single data extraction is used in systematic reviews, reviewers and readers need to be mindful of the possibility for more errors and the potential impact these errors may have on effect estimates. Ó 2006 Elsevier Inc. All rights reserved.
Keywords: Data extraction; Dat
