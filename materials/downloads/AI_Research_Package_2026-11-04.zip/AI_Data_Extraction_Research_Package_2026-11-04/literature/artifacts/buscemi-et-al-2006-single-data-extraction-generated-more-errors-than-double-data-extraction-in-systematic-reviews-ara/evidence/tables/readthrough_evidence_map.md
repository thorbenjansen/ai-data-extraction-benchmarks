# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `systematic-review/meta-analysis` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | data extraction (112) |
| Verification status | Needs human source-checking before exact citation |
