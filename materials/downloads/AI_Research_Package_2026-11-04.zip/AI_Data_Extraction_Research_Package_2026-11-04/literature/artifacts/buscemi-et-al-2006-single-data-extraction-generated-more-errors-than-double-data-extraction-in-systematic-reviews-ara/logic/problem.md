# Problem

This ARA preserves a branch-local retrieval entry point for `Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
