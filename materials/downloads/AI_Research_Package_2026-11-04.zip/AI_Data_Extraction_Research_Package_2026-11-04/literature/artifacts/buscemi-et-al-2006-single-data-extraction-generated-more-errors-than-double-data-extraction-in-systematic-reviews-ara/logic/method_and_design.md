# Method And Design

## Source Identity

- Title: Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews
- ARA: `buscemi-et-al-2006-single-data-extraction-generated-more-errors-than-double-data-extraction-in-systematic-reviews-ara`
- Source PDF: `raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `direct automated-data-extraction evidence`

## Data, Sample, Or Source Material

To our best knowledge, there is no empirical evidence regarding the types and magnitude of errors arising from these two methods and their relative impact on the results of meta-analysis. Our objective was to conduct a pilot study to describe and compare the types and frequency of errors that accompany single vs. double data extraction; compare the estimate of treatment effect derived from single vs. double data extraction; and compare the time required for single vs. double data extraction. 2. Methods Our Center recently conducted a systematic review of the efficacy and safety of melatonin for the management of sleep disorders [6], under contract with the Agency for Healthcare Research and Quality. The efficacy review included 30 randomized controlled trials of the effect of melatonin on people with sleep disorders. The outcomes of interest were sleep onset latency, sleep efficiency, wakefulness after sleep onset, total sleep time, sleep quality, REM latency and percent time in REM sleep. This review formed the basis for the current study, and the studies included in the review were used as a source for data extraction. We used an electronic data extraction form that was similar to the one used for the review of the efficacy and safety of melatonin [6]. Information relevant to the following variables was extracted for each study: first author and year of publication; language of publication and country where study took place; source of funding (public, private, or other); objectives of the study; study design; study population; inclusion and exclusion criteria; number of people eligible for the study; number of people enrolled in the study; number and type of comparison groups; number of people allocated to each comparison group; number of people who withdrew from the study and group from which they withdrew; metabolic disorders suffered by participants, if applicable; medication used by participants, if applicable; gender, age, and ethnicity of population; type of sleep disorder suffered by participants (primary, secondary, or sleep restriction); intervention; formulation of melatonin administered to participants; content and quality of melatonin formulation administered to participants; dosage, regimen and route of melatonin administration; magnitude, units, statistic, n-value, and P-value relevant to each of the following outcomes: sleep onset latency, t

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

To our best knowledge, there is no empirical evidence regarding the types and magnitude of errors arising from these two methods and their relative impact on the results of meta-analysis. Our objective was to conduct a pilot study to describe and compare the types and frequency of errors that accompany single vs. double data extraction; compare the estimate of treatment effect derived from single vs. double data extraction; and compare the time required for single vs. double data extraction. 2. Methods Our Center recently conducted a systematic review of the efficacy and safety of melatonin for the management of sleep disorders [6], under contract with the Agency for Healthcare Research and Quality. The efficacy review included 30 randomized controlled trials of the effect of melatonin on people with sleep disorders. The outcomes of interest were sleep onset latency, sleep efficiency, wakefulness after sleep onset, total sleep time, sleep quality, REM latency and percent time in REM sleep. This review formed the basis for the current study, and the studies included in the review were used as a source for data extraction. We used an electronic data extraction form that was similar to the one used for the review of the efficacy and safety of melatonin [6]. Information relevant to the following variables was extracted for each study: first author and year of publication; language of publication and country where study took place; source of funding (public, private, or other); objectives of the study; study design; study population; inclusion and exclusion criteria; number of people eligible for the study; number of people enrolled in the study; number and type of comparison groups; number of people allocated to each comparison group; number of people who withdrew from the study and group from which they withdrew; metabolic disorders suffered by participants, if applicable; medication used by participants, if applicable; gender, age, and ethnicity of population; type of sleep disorder suffered by participants (primary, secondary, or sleep restriction); intervention; formulation of melatonin administered to participants; content and quality of melatonin formulation administered to participants; dosage, regimen and route of melatonin administration; magnitude, units, statistic, n-value, and P-value relevant to each of the following outcomes: sleep onset latency, t

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
