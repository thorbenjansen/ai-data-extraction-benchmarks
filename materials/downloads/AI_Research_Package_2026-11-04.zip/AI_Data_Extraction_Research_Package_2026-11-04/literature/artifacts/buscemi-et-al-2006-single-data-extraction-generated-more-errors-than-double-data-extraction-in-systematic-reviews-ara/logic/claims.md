# Claims

- C01: `Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]], [[LLM Accuracy]], [[Speed-Accuracy Tradeoff]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf`.
