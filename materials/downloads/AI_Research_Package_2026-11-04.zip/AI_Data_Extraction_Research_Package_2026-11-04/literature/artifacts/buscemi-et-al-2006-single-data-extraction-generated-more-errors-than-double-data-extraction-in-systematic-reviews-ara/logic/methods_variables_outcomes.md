# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `systematic-review/meta-analysis`.
- Top automated-data-extraction terms in source text: data extraction (112).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Journal of Clinical Epidemiology 59 (2006) 697–703

Single data extraction generated more errors than double data
extraction in systematic reviews
Nina Buscemi*, Lisa Hartling, Ben Vandermeer, Lisa Tjosvold, Terry P.
- Klassen
Department of Pediatrics, University of Alberta/Capital Health Evidence-Based Practice Centre, 11402 University Avenue,
Aberhart Centre One, Room 8414, Edmonton, Alberta T6G 2J3, Canada
Accepted 15 November 2005

Abstract
Background and Objective: To conduct a pilot study to compare the frequency of errors that accompany single vs. double data
extraction, compare the estimate of treatment effect derived from these methods, and compare the time requirements for these methods.
- Methods: Reviewers were randomized to the role of data extractor or data verifier, and were blind to the study hypothesis.
- The frequency of errors associated with each method of data extraction was compared using the McNemar test.
- Results: Single data extraction resulted in more errors than double data extraction (relative difference: 21.7%, P 5 .019).
- The average time spent for single data extraction was less
than the average time for double data extraction (relative difference: 36.1%, P 5 .003).
- Conclusion: In the case that single data extraction is used in systematic reviews, reviewers and readers need to be mindful of the possibility for more errors and the potential impact these errors may have on effect estimates. Ó 2006 Elsevier Inc.
- Keywords: Data extraction; Data-handling error; Meta-analysis; Systematic review

1.
- The stage of data extraction
involves transcribing information reported in the primary
studies to a standard form that has been developed to capture all relevant information in a format specific to the review question.
- Recent investigations have raised questions regarding
the accuracy and reliability of the data extraction process
in systematic reviews.
- All rights reserved.
doi: 10.1016/j.jclinepi.2005.11.010

recommended enhanced rigor in data extraction including
systematic, double extraction.
- The rate of inaccuracies
was found to be ‘‘unacceptably high,’’ which has led to
new policies to reduce errors associated with data extraction.
