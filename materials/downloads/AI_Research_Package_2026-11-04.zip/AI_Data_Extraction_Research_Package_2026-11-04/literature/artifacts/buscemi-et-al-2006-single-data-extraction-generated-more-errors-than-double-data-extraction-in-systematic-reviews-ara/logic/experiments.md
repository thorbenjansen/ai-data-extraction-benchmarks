# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf`.
- Raw Markdown path: `not available`.
