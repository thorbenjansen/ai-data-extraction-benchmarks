---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews"
source_note: "wiki/sources/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.md"
source_path: "raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.md`
- Source path: `raw/Buscemi et al. - 2006 - Single data extraction generated more errors than double data extraction in systematic reviews.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Journal of Clinical Epidemiology 59 (2006) 697–703

Single data extraction generated more errors than double data
extraction in systematic reviews
Nina Buscemi*, Lisa Hartling, Ben Vandermeer, Lisa Tjosvold, Terry P. Klassen
Department of Pediatrics, University of Alberta/Capital Health Evidence-Based Practice Centre, 11402 University Avenue,
Aberhart Centre One, Room 8414, Edmonton, Alberta T6G 2J3, Canada
Accepted 15 November 2005

Abstract
Background and Objective: To conduct a pilot study to compare the frequency of errors that accompany single vs. double data
extraction, compare the estimate of treatment effect derived from these methods, and compare the time requirements for these methods.
Methods: Reviewers were randomized to the role of data extractor or data verifier, and were blind to the study hypothesis. The frequency of errors associated with each method of data extraction was compared using the McNemar test. The data set for each method
was used to calculate an efficacy estimate by each method, using standard meta-analytic techniques. The time requirement for each method
was compared using a paired t-test.
Results: Single data extraction resulted in more errors than double data extraction (relative difference: 21.7%, P 5 .019). There was no
substantial difference between methods in effect estimates for most outcomes. The average time spent for single data extraction was less
than the average time for double data extraction (relative difference: 36.1%, P 5 .003).
Conclusion: In the case that single data extraction is used in systematic reviews, reviewers and readers need to be mindful of the possibility for more errors and the potential impact these errors may have on effect estimates. Ó 2006 Elsevier Inc. All rights reserved.
Keywords: Data extraction; Dat

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
