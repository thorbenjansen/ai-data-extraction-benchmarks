# Algorithm

1. Retrieve the source through this ARA.
2. Open the branch source note for metadata and concept links.
3. Use the raw Markdown sidecar when available: `rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md`.
4. Verify exact details against the PDF before using them as evidence.
5. Feed verified claims into branch synthesis pages or rejoinder drafting.

This is a retrieval algorithm, not a claim that the paper itself implements executable software.
