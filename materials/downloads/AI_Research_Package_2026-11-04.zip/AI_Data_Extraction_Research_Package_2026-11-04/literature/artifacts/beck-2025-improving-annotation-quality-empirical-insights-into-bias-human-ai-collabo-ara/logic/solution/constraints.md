# Constraints

- Do not cite this ARA as the ultimate source for exact quotes or numerical values.
- If `grounding_status` is not `full_markdown`, perform PDF checking before using fine-grained claims.
- Preserve the distinction between empirical results, conceptual recommendations, and branch-level interpretation.
- Keep future edits linked to `wiki/sources/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.md` and the canonical source file.
