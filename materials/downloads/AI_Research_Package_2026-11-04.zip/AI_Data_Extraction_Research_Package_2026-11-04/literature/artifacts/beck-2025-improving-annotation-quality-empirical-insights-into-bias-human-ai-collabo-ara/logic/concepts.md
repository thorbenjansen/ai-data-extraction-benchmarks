# Concepts

- AI Data Extraction
- Evidence Synthesis Automation

## Anchor Documents

- Not specified

## Retrieval Tags

- branch-ai-data-extraction
- theme-ai-data-extraction
- article-role: `supporting-rejoinder-evidence`
- study-kind: `dissertation-with-embedded-empirical-studies`
- method: `unspecified`
