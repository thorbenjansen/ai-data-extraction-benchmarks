# Environment

## Source Environment

- Branch: `Sub_Branch_AI Data Extraction`
- Source note: `wiki/sources/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.md`
- Source path: `raw/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.pdf`
- Raw Markdown: `rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md`

## Agent Environment

This artifact was generated from local wiki/source metadata on 2026-05-04.
