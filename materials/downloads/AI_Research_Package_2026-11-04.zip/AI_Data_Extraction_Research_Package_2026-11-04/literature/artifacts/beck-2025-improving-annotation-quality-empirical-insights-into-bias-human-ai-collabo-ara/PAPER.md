---
type: agent_native_research_artifact
date: 2026-05-04
source_title: "Improving Annotation Quality: Empirical Insights into Bias, Human-AI Collaboration and Workflow Design"
source_note: "wiki/sources/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.md"
source_path: "raw/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.pdf"
rawmarkdown_path: "rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
ranking_degree: 7
ranking_incoming: 1
ranking_outgoing: 6
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
title: "Improving Annotation Quality: Empirical Insights into Bias, Human-AI Collaboration and Workflow Design"
authors:
  - "Julia Beck"
year: "2025"
---

# Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design

## Retrieval Contract

Use this ARA as the first agent-facing layer for the source, then verify important claims against `evidence/README.md`, `rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md`, and the branch source note `wiki/sources/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.md`.

## Source Grounding

- Source note: `wiki/sources/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.md`
- Source path: `raw/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md`
- Grounding status: `full_markdown`
- Branch graph rank signal: degree 7 = 1 incoming + 6 outgoing links.

## Abstracted Contribution

Beck's dissertation is useful for the AI data extraction rejoinder because it treats annotation as a designed data-generation workflow rather than as a neutral clerical step. The key transferable insight is that humans who check AI-generated pre-annotations are not passive validators: their judgments are shaped by task design, workload, order, attitudes toward AI, and the way the AI suggestion is displayed. For...

## Branch Use

This artifact was generated for the Top-20 connected-paper pass. It is designed for retrieval, rejoinder drafting, and source triage, not as a substitute for checking the PDF or full Markdown when making exact empirical claims.

## Main Ideas

- Beck's dissertation is useful for the AI data extraction rejoinder because it treats annotation as a designed data-generation workflow rather than as a neutral clerical step. The key transferable insight is that humans who check AI-generated pre-annotations are not passive validators: their judgments are shaped by task design, workload, order, attitudes toward AI, and the way the AI suggestion is displayed. For...

## Key Claims

- C01: The source is highly connected in the branch graph with degree 7 (1 incoming, 6 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: Beck's dissertation is useful for the AI data extraction rejoinder because it treats annotation as a designed data-generation workflow rather than as a neutral clerical step. The key transferable insight is that humans who check AI-generated pre-annotations are not passive validators: their judgments are shaped by task design, workload, order, attitudes toward AI, and the way the AI suggestion is displayed. For...
- C03: The source note classifies the work as dissertation-with-embedded-empirical-studies using unspecified, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.

## APA Reference

Beck, J. (2025). Improving annotation quality: Empirical insights into bias, human-AI collaboration, and workflow design [Doctoral dissertation, Ludwig-Maximilians-Universitat Munchen].
