# Source Grounding Table

| Field | Value |
|---|---|
| Source title | Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design |
| Source note | wiki/sources/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.md |
| Source path | raw/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.pdf |
| Raw Markdown | rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md |
| Grounding status | full_markdown |
| Branch degree | 7 |
| Incoming links | 1 |
| Outgoing links | 6 |
| Study kind | dissertation-with-embedded-empirical-studies |
| Study method | unspecified |
| Article role | supporting-rejoinder-evidence |
