# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.pdf` |
| Raw Markdown | `rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `benchmark/evaluation` |
| Branch role | `adjacent evidence-synthesis automation evidence` |
| Top terms | annotation (631), llm (38), chatgpt (13), artificial intelligence (13), human-ai (13), large language model (11), screening (6), generative ai (4) |
| Verification status | Needs human source-checking before exact citation |
