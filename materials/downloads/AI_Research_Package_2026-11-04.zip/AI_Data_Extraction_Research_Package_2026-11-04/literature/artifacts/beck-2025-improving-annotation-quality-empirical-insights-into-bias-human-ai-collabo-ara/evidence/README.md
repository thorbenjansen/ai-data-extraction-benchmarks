# Evidence Layer

## Source Pointers

- Source note: `wiki/sources/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.md`
- Source path: `raw/Beck - 2025 - Improving Annotation Quality Empirical Insights into Bias Human-AI Collaboration and Workflow Design.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/beck-2025-improving-annotation-quality-empirical-insights-into-bias-human-ai-collaboration-and-workflow-design.md`
- Grounding status: `full_markdown`

## Evidence Policy

This ARA is grounded only to the level stated above. For exact claims, quotes, table values, sample sizes, or model performance numbers, open the Markdown sidecar/PDF and add a specific evidence file with page or section pointers.

## Current Evidence Records

- `evidence/tables/source_grounding.md`: source and graph metadata.
