# Method And Design

## Source Identity

- Title: Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis
- ARA: `adam-et-al-2025-machine-learning-tools-to-semi-automate-evidence-synthesis-ara`
- Source PDF: `raw/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `review`
- Branch role: `direct automated-data-extraction evidence`

## Data, Sample, Or Source Material

Evidence synthesis, which includes systematic reviews (SRs), among other similar products, involves the application of scientific methods to identify, summarize, and evaluate studies, yielding rigorous appraisals of the evidence for a given topic.1–3 Evidence synthesis products (ESPs) serve as the foundation of evidence-based healthcare and health policy, aiding clinicians and patients by evaluating and summarizing evidence, as well as guiding medical and policy decision making through guidelines.4 However, ESPs are costly and time-consuming to produce and require extensive clinical and methodological expertise. A 2019 analysis estimated the average cost of developing an SR to be $141,195.5 Moreover, such activities as searching for studies, screening citations, and extracting data account for most of the time and resource use.6 Broadly scoped, high-quality SRs that meet Institute of Medicine (IOM)7 and Preferred Reporting Items for Systematic Reviews and MetaAnalyses (PRISMA)2 standards, such as those produced by the Agency for Healthcare Research and Quality (AHRQ) Evidence-based Practice Center (EPC) Program, are typically several times more expensive. As the demand for timely and well-conducted SRs increases, and the volume of literature continues to grow, it is important to identify ways to improve efficiency, including through automating or semi-automating SR production tasks.8, 9 Tools to semi-automate SR production tasks use natural language processing (NLP), which combines text mining and machine learning (ML) models (a subset of artificial intelligence [AI]) to make sense of unstructured human language for specific objectives, including classification, ranking, retrieval of relevant documents, text generation, text extraction, and relation extraction. Recent advances in NLP have yielded generative large language models that are pretrained on textual data from large amounts of text (usually from the Internet) to predict which words generally follow specific sequences of other words. These models were implemented in two ways: (1) zero-shot learning, where a pretrained deep learning model is applied to tasks that it has not explicitly seen before (e.g., ChatGPT), or (2) fine-tuning, where the pretrained deep learning model is retrained on a smaller dataset that is specific to the desired task (e.g., the Literature Search Sandbox).10 Although there is 

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Performance results are reported by SR task and then by use case. The full extracted data are provided in Appendixes C and D. When possible, the reference standard and results of the manual process are given. In most cases, the reference standard for the search/screening tools is the citations included in the final report. The reference standard for data extraction and risk of bias assessment is either the extracted data or the risk of bias in the final report or extractions produced by a person.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
