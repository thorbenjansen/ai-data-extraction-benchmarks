# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `review`.
- Top automated-data-extraction terms in source text: screening (95), risk of bias (39), data extraction (35), chatgpt (34), large language model (17), artificial intelligence (17), gpt-4 (16), llm (14).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Department of Health and Human Services
5600 Fishers Lane
Rockville, MD 20857
www.ahrq.gov
Contract Nos.
- Department of Health and Human Services.
- Department of Health and Human Services endorsement of any derivative
products that may be developed from this report, such as clinical practice guidelines, other
quality enhancement tools, or reimbursement or coverage policies may not be stated or implied.
- Suggested language for
acknowledgment: This work was based on an evidence report, Machine Learning Tools to
(Semi)Automate Evidence Synthesis, by the Evidence-based Practice Center Program at the
Agency for Healthcare Research and Quality (AHRQ).
- Machine Learning Tools To (Semi-)
Automate Evidence Synthesis.
- Tools that leverage machine learning, a subset of artificial intelligence, are
becoming increasingly important for conducting evidence synthesis as the volume and
complexity of primary literature expands exponentially.
- We searched PubMed, Embase, and the ACM Digital Library from January 1, 2021, to
April 3, 2024, for comparative studies, and identified older studies using the reference lists of
existing evidence synthesis products (ESPs).
- Two reviewers conducted title and abstract
screening independently, with disagreements resolved through discussion or adjudication by a
third reviewer.
- A single reviewer performed full-text screening and data extraction.
- Extracted data
included key characteristics of the tools (e.g., type of automation method, systematic review
tasks automated), evaluation methods, and performance results (e.g., recall, measures of
workload, accuracy, and the authors’ conclusions).
- We included 56 studies, which evaluated the performance of tools primarily relative to
standard human processes across various systematic review tasks.
- For search-related tools (7
studies), recall (the percent of relevant citations correctly identified) ranged from 0 to 97 percent
(median 26%) compared to human-developed search strategies, while precision (the percent of
identified citations that are relevant) ranged from 0 to 13.4 percent (median 4.3%).
