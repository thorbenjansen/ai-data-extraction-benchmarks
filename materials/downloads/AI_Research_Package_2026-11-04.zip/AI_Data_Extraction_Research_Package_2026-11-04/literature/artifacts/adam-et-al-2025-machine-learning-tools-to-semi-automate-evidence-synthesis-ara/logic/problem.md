# Problem

This ARA preserves a branch-local retrieval entry point for `Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
