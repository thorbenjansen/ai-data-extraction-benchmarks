---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis"
source_note: "wiki/sources/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.md"
source_path: "raw/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.md`
- Source path: `raw/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Research White Paper

Machine Learning Tools To (Semi-)Automate Evidence
Synthesis: A Rapid Review and Evidence Map

Research White Paper

Machine Learning Tools To (Semi-)Automate Evidence
Synthesis: A Rapid Review and Evidence Map
Prepared for:
Agency for Healthcare Research and Quality
U.S. Department of Health and Human Services
5600 Fishers Lane
Rockville, MD 20857
www.ahrq.gov
Contract Nos. 75Q80120D00001, 75Q80120D00004, 75Q80120D00006, 75Q80122C00002
Prepared by:
Brown Evidence-based Practice Center1
Providence, RI

Scientific Resource Center4
Portland, OR

Kaiser Permanente Research Affiliates
Evidence-based Practice Center2
Portland, OR

Agency for Healthcare Research
and Quality5
Rockville, MD

Pacific Northwest Evidence-based
Practice Center3
Portland, OR
Investigators:
Gaelen P. Adam, M.L.I.S., M.P.H., Ph.D.1
Melinda Davies, M.L.I.S.2
Jerusha George, B.S.3
Eduardo Caputo, Ph.D.1
Ja Mai Htun, M.B.B.S., M.P.H.1
Erin L. Coppola, M.P.H.2
Haley Holmer, Ph.D., M.P.H.4
Edi Kuhn4
Holly Wethington, Ph.D.5
Ilya Ivlev, M.D., M.B.I., Ph.D.3
Ethan M. Balk, M.D., M.P.H.1
Thomas A. Trikalinos, M.D., Ph.D.1
AHRQ Publication No. 25-EHC006
December 2024

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
