# Read-Through Result

## Source Identity Check

- Title: Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis
- Source PDF: `raw/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `review`
- Branch role: `direct automated-data-extraction evidence`

## Results Or Findings Check

Performance results are reported by SR task and then by use case. The full extracted data are provided in Appendixes C and D. When possible, the reference standard and results of the manual process are given. In most cases, the reference standard for the search/screening tools is the citations included in the final report. The reference standard for data extraction and risk of bias assessment is either the extracted data or the risk of bias in the final report or extractions produced by a person.

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
