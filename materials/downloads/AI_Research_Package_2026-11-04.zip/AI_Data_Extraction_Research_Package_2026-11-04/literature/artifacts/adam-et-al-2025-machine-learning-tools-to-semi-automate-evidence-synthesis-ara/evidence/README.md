# Evidence README

## Source Pointer

- PDF: `raw/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Research White Paper

Machine Learning Tools To (Semi-)Automate Evidence
Synthesis: A Rapid Review and Evidence Map

Research White Paper

Machine Learning Tools To (Semi-)Automate Evidence
Synthesis: A Rapid Review and Evidence Map
Prepared for:
Agency for Healthcare Research and Quality
U.S. Department of Health and Human Services
5600 Fishers Lane
Rockville, MD 20857
www.ahrq.gov
Contract Nos. 75Q80120D00001, 75Q80120D00004, 75Q80120D00006, 75Q80122C00002
Prepared by:
Brown Evidence-based Practice Center1
Providence, RI

Scientific Resource Center4
Portland, OR

Kaiser Permanente Research Affiliates
Evidence-based Practice Center2
Portland, OR

Agency for Healthcare Research
and Quality5
Rockville, MD

Pacific Northwest Evidence-based
Practice Center3
Portland, OR
Investigators:
Gaelen P. Adam, M.L.I.S., M.P.H., Ph.D.1
Melinda Davies, M.L.I.S.2
Jerusha George, B.S.3
Eduardo Caputo, Ph.D.1
Ja Mai Htun, M.B.B.S., M.P.H.1
Erin L. Coppola, M.P.H.2
Haley Holmer, Ph.D., M.P.H.4
Edi Kuhn4
Holly Wethington, Ph.D.5
Ilya Ivlev, M.D., M.B.I., Ph.D.3
Ethan M. Balk, M.D., M.P.H.1
Thomas A. Trikalinos, M.D., Ph.D.1
AHRQ Publication No. 25-EHC006
December 2024
