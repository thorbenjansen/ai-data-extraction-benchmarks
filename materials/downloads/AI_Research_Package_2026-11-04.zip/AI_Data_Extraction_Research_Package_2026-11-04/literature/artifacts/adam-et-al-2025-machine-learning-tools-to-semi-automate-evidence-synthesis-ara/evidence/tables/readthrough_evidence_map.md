# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `review` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | screening (95), risk of bias (39), data extraction (35), chatgpt (34), large language model (17), artificial intelligence (17), gpt-4 (16), llm (14) |
| Verification status | Needs human source-checking before exact citation |
