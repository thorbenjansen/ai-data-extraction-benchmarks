# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Adam et al. - 2025 - Machine Learning Tools To (Semi-) Automate Evidence Synthesis.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
