# Read-Through Key Passages

## Abstract Or Opening

Abstract Identifying effective literacy instruction programs has been a focal point for governments, educators and parents over the last few decades (Ontario Ministry of Education, 2004, 2006; Council of Ontario Directors of Education, 2011). Given the increasing use of computer technologies in the classroom and in the home, a variety of information communication technology (ICT) interventions for learning have been introduced. Meta-analyses comparing the impact of these programs on learning, however, have yielded inconsistent findings (Andrews, Freeman, Hou, McGuinn, Robinson, & Zhu, 2007; Slavin, Cheung, Groff, & Lake, 2008; Slavin, Lake, Chambers, Cheung, & Davis, 2009; Torgerson & Zhu, 2003). The present tertiary meta-analytic review reassesses outcomes presented in three previous meta-analyses, while taking into account instructional variables, specifically training and support, and implementation fidelity, which can significantly impact learning outcomes. When training and support were entered as a moderator variable the traditional small overall effectiveness of the ICTs (ES= 0.18) increased significantly (ES = .57). These findings indicate the importance of including implementation factors such as training and support, when considering the relative effectiveness of l ICT interventions.

## Methods

reviews will be contrasted to examine if the studies selected from different systematic reviews show different patterns. 2. Method 2.2 Study Selection At the outset, four prominent systematic reviews involving computer-based information and communication technologies for literacy instruction were selected for inclusion in this meta-analysis (Andrews, et al., 2007; Slavin, et al., 2008; Slavin, et al., 2009; Torgerson & Zhu, 2003). These reviews were selected because they used comparable review criteria: control groups, study duration, and valid achievement measures. One review, Andrews and colleagues (2007), was subsequently excluded because necessary statistical information (e.g., specific effect sizes, means or mean scores) was not provided in the review. Of the remaining three review papers, Torgerson and Zhu (2003) examined studies conducted between 1990 and 2002 that examined the impact of ICT on literacy learning for learners aged 5-16 years of age. Slavin and colleagues (2008) reviewed literacy studies using computer-assisted instruction for students in middle and high school between 1970 and 2007. The review by Slavin and colleagues (2009) examined students in kindergarten through grade 5 between 1970 and 2007. All of the reviews reported substantial variation in effect sizes across studies and overall, minimal evidence of ICT effectiveness. The present meta-analyses included all articles that could be retrieved from the original three reviews above. Specifically, Slavin and colleagues (2008) included 8 articles in their review of computer-assisted instruction. Of the 8 articles 6 were located,

## Results Or Findings

Using Cohen’s (1988)
definition of effect sizes, the overall effect size for all studies included together was small
0.181 (CI = 0.105 to 0.256) with a standard error of .039 (Cohen,1988). Dissertation Abstracts International Part
A: Humanities and [DISS. Spell checkers: Aids in identifying and correcting
spelling errors. Effective reading programs for
middle and high schools: A best-evidence synthesis.

## Discussion Or Conclusion

Effective reading
programs for the elementary grades: A best-evidence synthesis.

## Limitations

No clean limitations passage isolated automatically.
