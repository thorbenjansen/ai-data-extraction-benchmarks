# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `systematic-review/meta-analysis` |
| Branch role | `background meta-research or synthesis-methods evidence` |
| Top terms | none found |
| Verification status | Needs human source-checking before exact citation |
