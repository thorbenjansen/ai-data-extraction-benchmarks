# Evidence README

## Source Pointer

- PDF: `raw/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Running head: TRAINING AND TREATMENT INTEGRITY IN ICT STUDIES

1

Examining the Effectiveness of Technology use in Classrooms: A Tertiary Meta-Analysis

Karin Archer
Wilfrid Laurier University
Robert Savage
McGill University
Sukhbinder Sanghera-Sidhu
McGill University
Eileen Wood
Wilfrid Laurier University
Alexandra Gottardo
Wilfrid Laurier University
Victoria Chen
McGill University

TRAINING AND TREATMENT INTEGRITY IN ICT STUDIES

2

Abstract
Identifying effective literacy instruction programs has been a focal point for
governments, educators and parents over the last few decades (Ontario Ministry of
Education, 2004, 2006; Council of Ontario Directors of Education, 2011). Given the
increasing use of computer technologies in the classroom and in the home, a variety of
information communication technology (ICT) interventions for learning have been
introduced. Meta-analyses comparing the impact of these programs on learning, however,
have yielded inconsistent findings (Andrews, Freeman, Hou, McGuinn, Robinson, &
Zhu, 2007; Slavin, Cheung, Groff, & Lake, 2008; Slavin, Lake, Chambers, Cheung, &
Davis, 2009; Torgerson & Zhu, 2003). The present tertiary meta-analytic review reassesses outcomes presented in three previous meta-analyses, while taking into account
instructional variables, specifically training and support, and implementation fidelity,
which can significantly impact learning outcomes. When training and support were
entered as a moderator variable the traditional small overall effectiveness of the ICTs
(ES= 0.18) increased significantly (ES = .57). These findings indicate the importance of
including implementation factors such as training and support, when considering the
relative effectiveness of l ICT interventions.

Keywords: elementary education; evaluation o
