# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.pdf`.
- Raw Markdown path: `not available`.
