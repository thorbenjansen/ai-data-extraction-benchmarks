# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `background meta-research or synthesis-methods evidence`.
- Provisional design: `systematic-review/meta-analysis`.
- Top automated-data-extraction terms in source text: none found.

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Using Cohen’s (1988)
definition of effect sizes, the overall effect size for all studies included together was small
0.181 (CI = 0.105 to 0.256) with a standard error of .039 (Cohen,1988).
- Dissertation Abstracts International Part
A: Humanities and [DISS.
- Spell checkers: Aids in identifying and correcting
spelling errors.
- Effective reading programs for
middle and high schools: A best-evidence synthesis.
- Effective reading
programs for the elementary grades: A best-evidence synthesis.
