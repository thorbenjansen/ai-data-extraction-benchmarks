# Problem

This ARA preserves a branch-local retrieval entry point for `Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
