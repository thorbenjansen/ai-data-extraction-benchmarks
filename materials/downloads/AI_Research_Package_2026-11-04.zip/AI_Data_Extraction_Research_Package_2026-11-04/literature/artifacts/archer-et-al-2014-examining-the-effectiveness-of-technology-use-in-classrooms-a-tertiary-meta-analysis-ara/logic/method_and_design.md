# Method And Design

## Source Identity

- Title: Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis
- ARA: `archer-et-al-2014-examining-the-effectiveness-of-technology-use-in-classrooms-a-tertiary-meta-analysis-ara`
- Source PDF: `raw/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `systematic-review/meta-analysis`
- Branch role: `background meta-research or synthesis-methods evidence`

## Data, Sample, Or Source Material

reviews will be contrasted to examine if the studies selected from different systematic reviews show different patterns. 2. Method 2.2 Study Selection At the outset, four prominent systematic reviews involving computer-based information and communication technologies for literacy instruction were selected for inclusion in this meta-analysis (Andrews, et al., 2007; Slavin, et al., 2008; Slavin, et al., 2009; Torgerson & Zhu, 2003). These reviews were selected because they used comparable review criteria: control groups, study duration, and valid achievement measures. One review, Andrews and colleagues (2007), was subsequently excluded because necessary statistical information (e.g., specific effect sizes, means or mean scores) was not provided in the review. Of the remaining three review papers, Torgerson and Zhu (2003) examined studies conducted between 1990 and 2002 that examined the impact of ICT on literacy learning for learners aged 5-16 years of age. Slavin and colleagues (2008) reviewed literacy studies using computer-assisted instruction for students in middle and high school between 1970 and 2007. The review by Slavin and colleagues (2009) examined students in kindergarten through grade 5 between 1970 and 2007. All of the reviews reported substantial variation in effect sizes across studies and overall, minimal evidence of ICT effectiveness. The present meta-analyses included all articles that could be retrieved from the original three reviews above. Specifically, Slavin and colleagues (2008) included 8 articles in their review of computer-assisted instruction. Of the 8 articles 6 were located,

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Using Cohen’s (1988)
definition of effect sizes, the overall effect size for all studies included together was small
0.181 (CI = 0.105 to 0.256) with a standard error of .039 (Cohen,1988). Dissertation Abstracts International Part
A: Humanities and [DISS. Spell checkers: Aids in identifying and correcting
spelling errors. Effective reading programs for
middle and high schools: A best-evidence synthesis.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
