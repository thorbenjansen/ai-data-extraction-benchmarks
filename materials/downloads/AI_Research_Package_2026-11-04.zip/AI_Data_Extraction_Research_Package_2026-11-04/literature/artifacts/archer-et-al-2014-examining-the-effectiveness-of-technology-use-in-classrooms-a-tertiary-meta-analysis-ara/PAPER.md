---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis"
source_note: "wiki/sources/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.md"
source_path: "raw/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.md`
- Source path: `raw/Archer et al. - 2014 - Examining the effectiveness of technology use in classrooms A tertiary meta-analysis.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Running head: TRAINING AND TREATMENT INTEGRITY IN ICT STUDIES

1

Examining the Effectiveness of Technology use in Classrooms: A Tertiary Meta-Analysis

Karin Archer
Wilfrid Laurier University
Robert Savage
McGill University
Sukhbinder Sanghera-Sidhu
McGill University
Eileen Wood
Wilfrid Laurier University
Alexandra Gottardo
Wilfrid Laurier University
Victoria Chen
McGill University

TRAINING AND TREATMENT INTEGRITY IN ICT STUDIES

2

Abstract
Identifying effective literacy instruction programs has been a focal point for
governments, educators and parents over the last few decades (Ontario Ministry of
Education, 2004, 2006; Council of Ontario Directors of Education, 2011). Given the
increasing use of computer technologies in the classroom and in the home, a variety of
information communication technology (ICT) interventions for learning have been
introduced. Meta-analyses comparing the impact of these programs on learning, however,
have yielded inconsistent findings (Andrews, Freeman, Hou, McGuinn, Robinson, &
Zhu, 2007; Slavin, Cheung, Groff, & Lake, 2008; Slavin, Lake, Chambers, Cheung, &
Davis, 2009; Torgerson & Zhu, 2003). The present tertiary meta-analytic review reassesses outcomes presented in three previous meta-analyses, while taking into account
instructional variables, specifically training and support, and implementation fidelity,
which can significantly impact learning outcomes. When training and support were
entered as a moderator variable the traditional small overall effectiveness of the ICTs
(ES= 0.18) increased significantly (ES = .57). These findings indicate the importance of
including implementation factors such as training and support, when considering the
relative effectiveness of l ICT interventions.

Keywords: elementary education; evaluation o

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
