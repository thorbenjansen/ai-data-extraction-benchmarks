# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Buecker et al. - 2023 - The development of subjective well-being across the life span A meta-analytic review of longitudina.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `needs-further-coding` |
| Branch role | `background meta-research or synthesis-methods evidence` |
| Top terms | llm (1) |
| Verification status | Needs human source-checking before exact citation |
