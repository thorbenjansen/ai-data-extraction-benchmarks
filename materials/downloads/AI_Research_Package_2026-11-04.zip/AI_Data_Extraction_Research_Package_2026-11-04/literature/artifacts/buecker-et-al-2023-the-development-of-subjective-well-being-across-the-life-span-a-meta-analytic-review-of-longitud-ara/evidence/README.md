# Evidence README

## Source Pointer

- PDF: `raw/Buecker et al. - 2023 - The development of subjective well-being across the life span A meta-analytic review of longitudina.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Psychological Bulletin
© 2023 American Psychological Association
ISSN: 0033-2909

2023, Vol. 149, Nos. 7–8, 418–446
https://doi.org/10.1037/bul0000401

This document is copyrighted by the American Psychological Association or one of its allied publishers.
Content may be shared at no cost, but any requests to reuse this content in part or whole must go through the American Psychological Association.

The Development of Subjective Well-Being Across the Life Span:
A Meta-Analytic Review of Longitudinal Studies
Susanne Buecker1, 2, Maike Luhmann1, Peter Haehner1, Janina Larissa Bühler3,
Laura C. Dapp4, Eva C. Luciano5, and Ulrich Orth4
1
Faculty of Psychology, Ruhr University Bochum
Institute of Psychology, German Sport University Cologne
3
Institute of Psychology, Johannes Gutenberg University Mainz
4
Institute of Psychology, University of Bern
5
Faculty of Psychology, University of Basel
2

How does subjective well-being (SWB) develop across the life span? Theories and previous empirical research
suggest heterogeneous conclusions regarding this question. Therefore, in this meta-analysis, we synthesized
the available longitudinal data on mean-level change in three SWB components: life satisfaction, positive
affect, and negative affect. The analyses were based on 443 unique samples with a total of 460,902 participants.
Our results showed that life satisfaction decreased from age 9 to 16 (d = −0.56), increased slightly until age 70
(d = 0.16), and then decreased again until age 96 (i.e., the oldest age for which data on life satisfaction were
available; d = −0.24). Positive affect declined from age 9 for almost the entire time until age 94 (d = −1.71).
Negative affect showed small ups and downs between ages 9 and 22. After age 22, negative affect declined
until age 60 (d = −
