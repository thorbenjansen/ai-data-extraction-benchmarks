# Read-Through Key Passages

## Abstract Or Opening

Systematic Literature Search We searched for relevant studies in the databases APA PsycInfo and MEDLINE; the search covered all entries until November 10, 2022. We used the following search terms: life satisfaction OR satisfaction with life OR positive affect* OR negative affect* OR subjective well-being. The use of the asterisks allowed us to identify variants of the respective keyword (i.e., by using the term affect* we could identify studies using the terms affect and affectivity). The search terms were entered without quotation marks so that not only “subjective well-being” but also “well-being” in general (and thus also “psychological well-being”) appeared in the search hit list. The terms were searched in the title, abstract, key concepts, and subject headings. In APA PsycInfo, we restricted the search to empirical– quantitative studies and longitudinal studies by using the limitation options “empirical study,” “quantitative study,” and “longitudinal study.” Moreover, we restricted the search to studies using a human population and published them in English. As MEDLINE does not offer such limitation options, we added these methodological terms to our search string. We included only effect sizes from nondisordered populations. Therefore, this search procedure was performed once by setting an APA PsycInfo limit to “nondisordered populations” and once by setting the limit to “disordered populations”. As the APA PsycInfo tags on the clinical status of the sample are sometimes faulty

## Methods

Method The present meta-analysis used anonymized data and therefore was exempt from approval by the Ethics Committee of the ﬁrst author’s institution (German Sport University Cologne), in accordance with national law.

## Results Or Findings

Moreover, as described above, different life stages are
associated with unique demands and expectations, and their
fulﬁllment is related to SWB (Heckhausen et al., 2010). In APA PsycInfo, we restricted the search to empirical–
quantitative studies and longitudinal studies by using the limitation
options “empirical study,” “quantitative study,” and “longitudinal
study.” Moreover, we restricted the search to studies using a human
population and published them in English. The RVE approach

adjusts the standard errors and does not require accurate knowledge
of the within-study covariance structure (Tanner-Smith & Tipton,
2014). The basic idea of
Egger’s regression test is that a statistically signiﬁcant association
between the observed effect size and the standard error implies
asymmetry in the funnel plot, which may indicate publication bias.

## Discussion Or Conclusion

First, we visually inspected the funnel plots, which display
the association between the observed effect size and the standard
error. SE =
standard error; SWB = subjective well-being; T1 = Time 1; PANAS = Positive and Negative Affect Scale;
SWLS = Satisfaction With Life Scale.

middle childhood to late adolescence (i.e., between age 9 and age
18). Longitudinal evidence
for a midlife nadir in human well-being: Results from four data sets. Social identiﬁcation
and well-being following a terrorist attack: A longitudinal study of Israeli
adolescents.

## Limitations

No clean limitations passage isolated automatically.
