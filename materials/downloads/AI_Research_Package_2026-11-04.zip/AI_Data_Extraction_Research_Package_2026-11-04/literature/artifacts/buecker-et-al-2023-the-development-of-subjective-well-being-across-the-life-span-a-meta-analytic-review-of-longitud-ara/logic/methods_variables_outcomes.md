# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `background meta-research or synthesis-methods evidence`.
- Provisional design: `needs-further-coding`.
- Top automated-data-extraction terms in source text: llm (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Moreover, as described above, different life stages are
associated with unique demands and expectations, and their
fulﬁllment is related to SWB (Heckhausen et al., 2010).
- In APA PsycInfo, we restricted the search to empirical–
quantitative studies and longitudinal studies by using the limitation
options “empirical study,” “quantitative study,” and “longitudinal
study.” Moreover, we restricted the search to studies using a human
population and published them in English.
- The RVE approach

adjusts the standard errors and does not require accurate knowledge
of the within-study covariance structure (Tanner-Smith & Tipton,
2014).
- The basic idea of
Egger’s regression test is that a statistically signiﬁcant association
between the observed effect size and the standard error implies
asymmetry in the funnel plot, which may indicate publication bias.
- First, we visually inspected the funnel plots, which display
the association between the observed effect size and the standard
error.
- SE =
standard error; SWB = subjective well-being; T1 = Time 1; PANAS = Positive and Negative Affect Scale;
SWLS = Satisfaction With Life Scale.

middle childhood to late adolescence (i.e., between age 9 and age
18).
- Longitudinal evidence
for a midlife nadir in human well-being: Results from four data sets.
- Social identiﬁcation
and well-being following a terrorist attack: A longitudinal study of Israeli
adolescents.
- The Journal of Genetic Psychology: Research and Theory on
Human Development, 177(5), 172–184. https://doi.org/10.1080/00221325
.2016.1223010
*Daukantaitė, D., & Zukauskiene, R. (2012).
- International Journal of Aging & Human
Development, 91(1), 37–59. https://doi.org/10.1177/0091415019843448
*Lee, Y.-H., Cheng, C.-Y., & Lin, S.
- Computers in Human
Behavior, 27(1), 144–152. https://doi.org/10.1016/j.chb.2010.07.015
*Lent, R.
- Stähli (Eds.), Surveying human vulnerabilities across the life course
(pp.
