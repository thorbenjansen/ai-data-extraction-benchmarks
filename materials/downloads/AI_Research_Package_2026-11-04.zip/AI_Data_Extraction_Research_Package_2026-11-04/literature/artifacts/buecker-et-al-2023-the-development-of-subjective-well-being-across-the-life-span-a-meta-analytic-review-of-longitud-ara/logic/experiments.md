# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Buecker et al. - 2023 - The development of subjective well-being across the life span A meta-analytic review of longitudina.pdf`.
- Raw Markdown path: `not available`.
