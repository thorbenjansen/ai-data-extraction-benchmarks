# Source Scope

## Strong Uses

- Use as `background meta-research or synthesis-methods evidence` in the AI Data Extraction branch.
- Use for retrieval around llm.

## Weak Uses

- Do not treat this automated ARA as citation-grade for exact numbers without checking the PDF.
- Do not infer model superiority from abstract-level claims alone.
- Do not treat human-AI agreement or model confidence as validation unless the source itself defines and tests that standard.

## Transfer Boundaries

- Domain, document type, extraction target, model/tool version, and human adjudication design may limit transfer to the main AI data extraction paper.

## Citation-Grade Verification Needs

- Re-open `raw/Buecker et al. - 2023 - The development of subjective well-being across the life span A meta-analytic review of longitudina.pdf`.
- Confirm the exact extraction task and evaluation metric.
- Confirm whether the source evaluates data extraction specifically or an adjacent task such as screening, annotation, risk-of-bias, or literature search.
