# Read-Through Result

## Source Identity Check

- Title: Cao et al. - 2025 - Automation of systematic reviews with large language models
- Source PDF: `raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf`
- Raw Markdown: `rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `protocol`
- Branch role: `direct automated-data-extraction evidence`

## Results Or Findings Check

We previously found that GPT4-preview could achieve high screening performance with effective prompting strategies6 . Aiming to improve on these findings, we developed a screening agent leveraging GPT-4.1, a model which excels at instruction following10,11 , paired with optimized prompting strategies6 , to screen articles at abstract and full-text stages. The agent was prompted using the original, unaltered objectives and eligibility criteria from each respective review (Supplementary Notes). Full-text article PDFs were converted into markdown format with the Gemini 2.0 Flash model for full-text screening. We evaluated the performance of the otto-SR screening agent on the complete original search across five published reviews (n=32,357 citations) covering four Oxford Centre for Evidence-Based Medicine (CEBM) question types: prevalence, diagnostic test accuracy, prognosis, intervention benefits (Extended Data Table 1). Dual human reviewers and Elicit (a commercial LLM-based SR automation software) were evaluated against a random representative sample of records for each review (n=1,767 citations) (Methods). The reference standard for inclusion/exclusion decisions was based on the original authors’ final decisions after full-text screening. To validate the proficiency of our human reviewers in screening, we conducted a calibration exercise (n=400 citations) where we compared the SR screening performance of our reviewers to the original study authors12 , who had independently re-screened the same set of articles. We found that the performance of our human 2

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
