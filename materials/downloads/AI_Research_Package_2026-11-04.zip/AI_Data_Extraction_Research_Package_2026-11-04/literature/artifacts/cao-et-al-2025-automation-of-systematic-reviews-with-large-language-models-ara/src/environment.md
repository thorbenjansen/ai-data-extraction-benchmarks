# Environment

## Source Environment

- Branch: `Sub_Branch_AI Data Extraction`
- Source note: `wiki/sources/Cao et al. - 2025 - Automation of systematic reviews with large language models.md`
- Source path: `raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf`
- Raw Markdown: `rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md`

## Agent Environment

This artifact was generated from local wiki/source metadata on 2026-05-04.
