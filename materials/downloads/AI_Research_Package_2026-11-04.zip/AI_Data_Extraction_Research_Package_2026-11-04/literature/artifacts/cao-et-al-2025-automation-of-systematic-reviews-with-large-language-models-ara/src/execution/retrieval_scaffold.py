"""Retrieval scaffold for the ARA: Cao et al. - 2025 - Automation of systematic reviews with large language models."""
from pathlib import Path

BRANCH_ROOT = Path(__file__).resolve().parents[5]
SOURCE_NOTE = BRANCH_ROOT / "wiki" / "sources" / 'Cao et al. - 2025 - Automation of systematic reviews with large language models.md'
RAW_MARKDOWN = BRANCH_ROOT / 'rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md'
SOURCE_PATH = BRANCH_ROOT / 'raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf' if True else None


def available_paths():
    paths = {"source_note": SOURCE_NOTE}
    if RAW_MARKDOWN:
        paths["raw_markdown"] = RAW_MARKDOWN
    if SOURCE_PATH:
        paths["source_path"] = SOURCE_PATH
    return {k: str(v) for k, v in paths.items() if v.exists()}
