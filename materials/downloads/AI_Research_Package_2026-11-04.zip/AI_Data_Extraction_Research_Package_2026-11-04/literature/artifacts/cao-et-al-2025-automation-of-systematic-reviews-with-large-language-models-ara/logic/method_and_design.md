# Method And Design

## Source Identity

- Title: Cao et al. - 2025 - Automation of systematic reviews with large language models
- ARA: `cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models-ara`
- Source PDF: `raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf`
- Raw Markdown: `rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `protocol`
- Branch role: `direct automated-data-extraction evidence`

## Data, Sample, Or Source Material

compared randomized pairs of responses (otto-SR vs. original author) and selected the most accurate value (see Methods). We used these judgements to construct a corrected gold standard for performance evaluations. Across all seven reviews, the otto-SR extraction agent achieved an average weighted accuracy of 93.1% (91.1-97.0%), outperforming both dual human reviewers at 79.7% (69.1-91.0%), and Elicit at 74.8% (58.8-83.1%) (Fig. 3A, Extended Data Figure 6). When otto-SR extracted different values to the original authors, the blinded human reviewer panel sided with the otto-SR data extraction agent in 69.3% of cases (Fig. 3C). In contrast, for discrepancies between original authors and our two human extractors or Elicit, the blinded reviewer panel sided with the dual human extractors in 28.1% of cases, and Elicit in 22.4% of cases (Fig. 3C). In the 6.9% of cases where the otto-SR extraction agent was incorrect, post-hoc analysis revealed that 0.83% (39/4459) of data points were inaccessible to the model (supplementary files or data obtained through data request), 0.67% (30/4459) resulted from parsing errors, and 0.49% (22/4459) were cases where neither the otto-SR data extraction agent nor original author extraction was correct (Extended Data Figure 1).

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

We previously found that GPT4-preview could achieve high screening performance with effective prompting strategies6 . Aiming to improve on these findings, we developed a screening agent leveraging GPT-4.1, a model which excels at instruction following10,11 , paired with optimized prompting strategies6 , to screen articles at abstract and full-text stages. The agent was prompted using the original, unaltered objectives and eligibility criteria from each respective review (Supplementary Notes). Full-text article PDFs were converted into markdown format with the Gemini 2.0 Flash model for full-text screening. We evaluated the performance of the otto-SR screening agent on the complete original search across five published reviews (n=32,357 citations) covering four Oxford Centre for Evidence-Based Medicine (CEBM) question types: prevalence, diagnostic test accuracy, prognosis, intervention benefits (Extended Data Table 1). Dual human reviewers and Elicit (a commercial LLM-based SR automation software) were evaluated against a random representative sample of records for each review (n=1,767 citations) (Methods). The reference standard for inclusion/exclusion decisions was based on the original authors’ final decisions after full-text screening. To validate the proficiency of our human reviewers in screening, we conducted a calibration exercise (n=400 citations) where we compared the SR screening performance of our reviewers to the original study authors12 , who had independently re-screened the same set of articles. We found that the performance of our human 2

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
