# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `direct automated-data-extraction evidence`.
- Provisional design: `protocol`.
- Top automated-data-extraction terms in source text: screening (86), data extraction (59), llm (38), gpt-4 (9), large language model (6), systematic review automation (3), risk of bias (3), review automation (3).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Automation of Systematic Reviews
with Large Language Models
Christian Cao1†, Rohit Arora2†, Paul Cento3†, Katherine Manta1 , Elina Farahani1 , Matthew Cecere1 , Anabel
Selemon4 , Jason Sang3 , Ling Xi Gong2 , Robert Kloosterman1 , Scott Jiang5 , Richard Saleh1 ,
Denis Margalik1 , James Lin6 , Jane Jomy1 , Jerry Xie7 , David Chen1 , Jaswanth Gorla1 , Sylvia Lee8 ,
Kelvin Zhang7 , Harriet Ware9 , Mairead Whelan9 , Bijan Teja1,10 , Alexander A.
- Yet, they take over a year to complete, are
prone to human error, and face challenges with reproducibility; limiting access to timely and reliable information.
- We developed otto-SR, an end-to-end agentic workflow using large language models (LLMs) to support and
automate the SR workflow from initial search to analysis.
- We found that otto-SR outperformed traditional dual
human workflows in SR screening (otto-SR: 96.7% sensitivity, 97.9% specificity; human: 81.7% sensitivity, 98.1%
specificity) and data extraction (otto-SR: 93.1% accuracy; human: 79.7% accuracy).
- These findings demonstrate that LLMs can rapidly conduct and update
systematic reviews with superhuman performance, laying the foundation for automated, scalable, and reliable
evidence synthesis.
- While several tools have been developed to accelerate SRs4,5 , none are capable of full automation with
human-level accuracy.
- However, large language models (LLMs) offer new avenues to achieve automation with
their ability to process and reason about natural language.
- We previously demonstrated that LLMs can achieve
high screening performance6 .
- Other recent work has demonstrated promise for LLMs in data extraction7,8 ,
though these studies rely on self-defined reference standards and evaluate on small datasets.
- We introduce an LLM-based workflow (otto-SR) to support automated and human-in-the-loop SR workflows,
from initial search to data analysis.
- Our framework uses GPT-4.1 (OpenAI) for screening articles and o3-minihigh (OpenAI) for data extraction, targeting tasks that typically consume the majority of human researcher
time and effort.
- We evaluate our workflow on these core SR components, article screening and data extraction,
with direct comparisons to traditional human workflows and other SR automation tools.
