# Claims

- C01: The source is highly connected in the branch graph with degree 8 (0 incoming, 8 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: Systematic reviews (SRs) inform evidence-based decision making. Yet, they take over a year to complete, are prone to human error, and face challenges with reproducibility; limiting access to timely and reliable information. We developed otto-SR, an end-to-end agentic workflow using large language models (LLMs) to support and automate the SR workflow from initial search to analysis. We found that otto-SR outperformed...
- C03: The source note classifies the work as secondary-evidence using systematic-review, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.

## Claim Status

- Supported by: `raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf` and `wiki/sources/Cao et al. - 2025 - Automation of systematic reviews with large language models.md`
- Grounding status: `full_markdown`
- Verification priority: high for numerical or methodological details; medium for conceptual linkage claims.
