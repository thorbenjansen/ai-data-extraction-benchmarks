---
type: agent_native_research_artifact
date: 2026-05-04
source_title: "Cao et al. - 2025 - Automation of systematic reviews with large language models"
source_note: "wiki/sources/Cao et al. - 2025 - Automation of systematic reviews with large language models.md"
source_path: "raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf"
rawmarkdown_path: "rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
ranking_degree: 8
ranking_incoming: 0
ranking_outgoing: 8
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Cao et al. - 2025 - Automation of systematic reviews with large language models

## Retrieval Contract

Use this ARA as the first agent-facing layer for the source, then verify important claims against `evidence/README.md`, `the PDF/source note pointer`, and the branch source note `wiki/sources/Cao et al. - 2025 - Automation of systematic reviews with large language models.md`.

## Source Grounding

- Source note: `wiki/sources/Cao et al. - 2025 - Automation of systematic reviews with large language models.md`
- Source path: `raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md`
- Grounding status: `full_markdown`
- Branch graph rank signal: degree 8 = 0 incoming + 8 outgoing links.

## Abstracted Contribution

Systematic reviews (SRs) inform evidence-based decision making. Yet, they take over a year to complete, are prone to human error, and face challenges with reproducibility; limiting access to timely and reliable information. We developed otto-SR, an end-to-end agentic workflow using large language models (LLMs) to support and automate the SR workflow from initial search to analysis. We found that otto-SR outperformed...

## Branch Use

This artifact was generated for the Top-20 connected-paper pass. It is designed for retrieval, rejoinder drafting, and source triage, not as a substitute for checking the PDF or full Markdown when making exact empirical claims.

## Main Ideas

- Systematic reviews (SRs) inform evidence-based decision making.
- Yet, they take over a year to complete, are prone to human error, and face challenges with reproducibility; limiting access to timely and reliable information.
- We developed otto-SR, an end-to-end agentic workflow using large language models (LLMs) to support and automate the SR workflow from initial search to analysis.

## Key Claims

- C01: The source is highly connected in the branch graph with degree 8 (0 incoming, 8 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: Systematic reviews (SRs) inform evidence-based decision making. Yet, they take over a year to complete, are prone to human error, and face challenges with reproducibility; limiting access to timely and reliable information. We developed otto-SR, an end-to-end agentic workflow using large language models (LLMs) to support and automate the SR workflow from initial search to analysis. We found that otto-SR outperformed...
- C03: The source note classifies the work as secondary-evidence using systematic-review, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.
