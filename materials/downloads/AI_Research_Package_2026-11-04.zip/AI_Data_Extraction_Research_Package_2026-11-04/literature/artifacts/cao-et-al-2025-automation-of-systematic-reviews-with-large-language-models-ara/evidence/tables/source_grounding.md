# Source Grounding Table

| Field | Value |
|---|---|
| Source title | Cao et al. - 2025 - Automation of systematic reviews with large language models |
| Source note | wiki/sources/Cao et al. - 2025 - Automation of systematic reviews with large language models.md |
| Source path | raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf |
| Raw Markdown | rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md |
| Grounding status | full_markdown |
| Branch degree | 8 |
| Incoming links | 0 |
| Outgoing links | 8 |
| Study kind | secondary-evidence |
| Study method | systematic-review |
| Article role | supporting-rejoinder-evidence |
