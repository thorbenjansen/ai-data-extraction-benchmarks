# Evidence Layer

## Source Pointers

- Source note: `wiki/sources/Cao et al. - 2025 - Automation of systematic reviews with large language models.md`
- Source path: `raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md`
- Grounding status: `full_markdown`

## Evidence Policy

This ARA is grounded only to the level stated above. For exact claims, quotes, table values, sample sizes, or model performance numbers, open the Markdown sidecar/PDF and add a specific evidence file with page or section pointers.

## Current Evidence Records

- `evidence/tables/source_grounding.md`: source and graph metadata.
