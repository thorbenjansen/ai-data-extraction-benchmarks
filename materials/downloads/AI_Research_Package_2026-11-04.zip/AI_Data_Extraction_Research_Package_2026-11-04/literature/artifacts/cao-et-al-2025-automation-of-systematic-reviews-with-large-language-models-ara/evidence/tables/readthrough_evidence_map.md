# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Cao et al. - 2025 - Automation of systematic reviews with large language models.pdf` |
| Raw Markdown | `rawmarkdown_full/cao-et-al-2025-automation-of-systematic-reviews-with-large-language-models.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `protocol` |
| Branch role | `direct automated-data-extraction evidence` |
| Top terms | screening (86), data extraction (59), llm (38), gpt-4 (9), large language model (6), systematic review automation (3), risk of bias (3), review automation (3) |
| Verification status | Needs human source-checking before exact citation |
