# Read-Through Result

## Source Identity Check

- Title: Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility
- Source PDF: `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `experiment`
- Branch role: `branch-adjacent context`

## Results Or Findings Check

14. Spellman BA (2012b) Introduction to the special section on research practices. Perspect Psychol Sci 7(6):655–656. 15. Bollen K, Cacioppo JT, Kaplan RM, Krosnick JA, Olds JL (2015) Social, Behavioral, and Economic Sciences Perspectives on Robust and Reliable Science: Report of the Subcommittee on Replicability in Science, Advisory Committee to the National Science Foundation Directorate for Social, Behavioral, and Economic Sciences. Available at www.nsf.gov/sbe/AC_Materials/ SBE_Robust_and_Reliable_Research_Report.pdf. Accessed May 10, 2016. 16. Open Science Collaboration (2015) Psychology. Estimating the reproducibility of psychological science. Science 349(6251):aac4716. 17. Sample I (2015) Study delivers bleak verdict on validity of psychology experiment results. Available at https://www.theguardian.com/science/2015/aug/27/study-delivers-bleak-verdicton-validity-of-psychology-experiment-results. Accessed May 10, 2016. 18. Efferson ADP (2015) How many laws are based on psychology’s bad science. Available at thefederalist.com/2015/09/08/how-many-laws-are-based-on-psychologys-bad-science/. Accessed May 10, 2016. 19. Ferguson CJ (2015) “Everybody knows psychology is not a real science”: Public perceptions of psychology and how we can improve our relationship with policymakers, the scientific community, and the general public. Am Psychol 70(6):527–542. 20. Lilienfeld SO (2012) Public skepticism of psychology: Why many people perceive the study of human behavior as unscientific. Am Psychol 67(2):111–129. 21. Ferguson CJ, Heene M (2012) A vast graveyard of undead theories publication bias and psychological science’s aversion to the null. Perspect Psychol Sci 7(6):555–561. 22. Rosenthal R (1979) The file drawer problem and tolerance for null results. Psychol Bull 86(3):638–641. 23. Cohen J (1962) The statistical power of abnormal-social psychological research: A review. J Abnorm Soc Psychol 65:145–153. 24. Maxwell SE, Lau MY, Howard GS (2015) Is psychology suffering from a replication crisis? What does “failure to replicate” really mean? Am Psychol 70(6):487–498.

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
