# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `experiment` |
| Branch role | `branch-adjacent context` |
| Top terms | llm (1) |
| Verification status | Needs human source-checking before exact citation |
