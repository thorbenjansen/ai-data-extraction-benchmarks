# Evidence README

## Source Pointer

- PDF: `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Contextual sensitivity in scientific reproducibility
Jay J. Van Bavela,1, Peter Mende-Siedleckia, William J. Bradya, and Diego A. Reineroa
a

Department of Psychology, New York University, New York, NY 10003

Downloaded from https://www.pnas.org by 134.245.76.71 on December 11, 2025 from IP address 134.245.76.71.

Edited by Susan T. Fiske, Princeton University, Princeton, NJ, and approved April 25, 2016 (received for review December 3, 2015)

In recent years, scientists have paid increasing attention to reproducibility. For example, the Reproducibility Project, a large-scale replication
attempt of 100 studies published in top psychology journals found
that only 39% could be unambiguously reproduced. There is a growing consensus among scientists that the lack of reproducibility in psychology and other fields stems from various methodological factors,
including low statistical power, researcher’s degrees of freedom, and
an emphasis on publishing surprising positive results. However, there
is a contentious debate about the extent to which failures to reproduce
certain results might also reflect contextual differences (often termed
“hidden moderators”) between the original research and the replication
attempt. Although psychologists have found extensive evidence that
contextual factors alter behavior, some have argued that context is
unlikely to influence the results of direct replications precisely because
these studies use the same methods as those used in the original research. To help resolve this debate, we recoded the 100 original studies
from the Reproducibility Project on the extent to which the research
topic of each study was contextually sensitive. Results suggested that
the contextual sensitivity of the research topic was associated with
replication success, eve
