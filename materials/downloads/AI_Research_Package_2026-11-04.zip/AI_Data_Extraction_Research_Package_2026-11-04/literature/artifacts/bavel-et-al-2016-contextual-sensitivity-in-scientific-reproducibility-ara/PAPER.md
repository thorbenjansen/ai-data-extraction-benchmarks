---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility"
source_note: "wiki/sources/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.md"
source_path: "raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.md`
- Source path: `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Contextual sensitivity in scientific reproducibility
Jay J. Van Bavela,1, Peter Mende-Siedleckia, William J. Bradya, and Diego A. Reineroa
a

Department of Psychology, New York University, New York, NY 10003

Downloaded from https://www.pnas.org by 134.245.76.71 on December 11, 2025 from IP address 134.245.76.71.

Edited by Susan T. Fiske, Princeton University, Princeton, NJ, and approved April 25, 2016 (received for review December 3, 2015)

In recent years, scientists have paid increasing attention to reproducibility. For example, the Reproducibility Project, a large-scale replication
attempt of 100 studies published in top psychology journals found
that only 39% could be unambiguously reproduced. There is a growing consensus among scientists that the lack of reproducibility in psychology and other fields stems from various methodological factors,
including low statistical power, researcher’s degrees of freedom, and
an emphasis on publishing surprising positive results. However, there
is a contentious debate about the extent to which failures to reproduce
certain results might also reflect contextual differences (often termed
“hidden moderators”) between the original research and the replication
attempt. Although psychologists have found extensive evidence that
contextual factors alter behavior, some have argued that context is
unlikely to influence the results of direct replications precisely because
these studies use the same methods as those used in the original research. To help resolve this debate, we recoded the 100 original studies
from the Reproducibility Project on the extent to which the research
topic of each study was contextually sensitive. Results suggested that
the contextual sensitivity of the research topic was associated with
replication success, eve

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Context Engineering]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
