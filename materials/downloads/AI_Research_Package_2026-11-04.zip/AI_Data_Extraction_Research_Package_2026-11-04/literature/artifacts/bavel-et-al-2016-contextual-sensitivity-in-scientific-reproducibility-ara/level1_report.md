# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
