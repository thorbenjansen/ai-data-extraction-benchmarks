# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf`.
- Raw Markdown path: `not available`.
