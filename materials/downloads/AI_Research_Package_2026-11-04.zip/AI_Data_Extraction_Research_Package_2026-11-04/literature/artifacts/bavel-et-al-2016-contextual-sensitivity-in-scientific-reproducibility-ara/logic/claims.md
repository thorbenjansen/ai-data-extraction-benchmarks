# Claims

- C01: `Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]], [[Context Engineering]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf`.
