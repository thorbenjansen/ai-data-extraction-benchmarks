# Method And Design

## Source Identity

- Title: Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility
- ARA: `bavel-et-al-2016-contextual-sensitivity-in-scientific-reproducibility-ara`
- Source PDF: `raw/Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `experiment`
- Branch role: `branch-adjacent context`

## Data, Sample, Or Source Material

In recent years, scientists have paid increasing attention to reproducibility. For example, the Reproducibility Project, a large-scale replication attempt of 100 studies published in top psychology journals found that only 39% could be unambiguously reproduced. There is a growing consensus among scientists that the lack of reproducibility in psychology and other fields stems from various methodological factors, including low statistical power, researcher’s degrees of freedom, and an emphasis on publishing surprising positive results. However, there is a contentious debate about the extent to which failures to reproduce certain results might also reflect contextual differences (often termed “hidden moderators”) between the original research and the replication attempt. Although psychologists have found extensive evidence that contextual factors alter behavior, some have argued that context is unlikely to influence the results of direct replications precisely because these studies use the same methods as those used in the original research. To help resolve this debate, we recoded the 100 original studies from the Reproducibility Project on the extent to which the research topic of each study was contextually sensitive. Results suggested that the contextual sensitivity of the research topic was associated with replication success, even after statistically adjusting for several methodological characteristics (e.g., statistical power, effect size). The association between contextual sensitivity and replication success did not differ across psychological subdisciplines. These results suggest that researchers, replicators, and consumers should be mindful of contextual factors that might influence a psychological process. We offer several guidelines for dealing with contextual sensitivity in reproducibility. replication

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

14. Spellman BA (2012b) Introduction to the special section on research practices. Perspect Psychol Sci 7(6):655–656. 15. Bollen K, Cacioppo JT, Kaplan RM, Krosnick JA, Olds JL (2015) Social, Behavioral, and Economic Sciences Perspectives on Robust and Reliable Science: Report of the Subcommittee on Replicability in Science, Advisory Committee to the National Science Foundation Directorate for Social, Behavioral, and Economic Sciences. Available at www.nsf.gov/sbe/AC_Materials/ SBE_Robust_and_Reliable_Research_Report.pdf. Accessed May 10, 2016. 16. Open Science Collaboration (2015) Psychology. Estimating the reproducibility of psychological science. Science 349(6251):aac4716. 17. Sample I (2015) Study delivers bleak verdict on validity of psychology experiment results. Available at https://www.theguardian.com/science/2015/aug/27/study-delivers-bleak-verdicton-validity-of-psychology-experiment-results. Accessed May 10, 2016. 18. Efferson ADP (2015) How many laws are based on psychology’s bad science. Available at thefederalist.com/2015/09/08/how-many-laws-are-based-on-psychologys-bad-science/. Accessed May 10, 2016. 19. Ferguson CJ (2015) “Everybody knows psychology is not a real science”: Public perceptions of psychology and how we can improve our relationship with policymakers, the scientific community, and the general public. Am Psychol 70(6):527–542. 20. Lilienfeld SO (2012) Public skepticism of psychology: Why many people perceive the study of human behavior as unscientific. Am Psychol 67(2):111–129. 21. Ferguson CJ, Heene M (2012) A vast graveyard of undead theories publication bias and psychological science’s aversion to the null. Perspect Psychol Sci 7(6):555–561. 22. Rosenthal R (1979) The file drawer problem and tolerance for null results. Psychol Bull 86(3):638–641. 23. Cohen J (1962) The statistical power of abnormal-social psychological research: A review. J Abnorm Soc Psychol 65:145–153. 24. Maxwell SE, Lau MY, Howard GS (2015) Is psychology suffering from a replication crisis? What does “failure to replicate” really mean? Am Psychol 70(6):487–498.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
