# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `branch-adjacent context`.
- Provisional design: `experiment`.
- Top automated-data-extraction terms in source text: llm (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Contextual sensitivity in scientific reproducibility
Jay J.
- Results suggested that
the contextual sensitivity of the research topic was associated with
replication success, even after statistically adjusting for several methodological characteristics (e.g., statistical power, effect size).
- The association between contextual sensitivity and replication success did not
differ across psychological subdisciplines.
- We offer several
guidelines for dealing with contextual sensitivity in reproducibility.
replication

| reproducibility | context | psychology | meta-science

I

n recent years, scientists have paid increasing attention to reproducibility.
- 39–42) and have found extensive evidence that
contextual factors alter human behavior (43–46).
- The relatively small number of replication attempts (along with
relatively idiosyncratic inclusion criteria‡) across these prior replication projects makes it difficult to draw strong conclusions
regarding the role of contextual sensitivity in reproducibility.
- This paper addresses these issues directly by analyzing a large and diverse database of 100 replication
attempts and assessing the contextual sensitivity of each effect.
- Methods
To help assess the relationship between context and replication success, we
coded and analyzed contextual sensitivity in the Reproducibility Project (16).
- This practice ensured that each coder rated contextual sensitivity in a similar and
consistent fashion.
- Moreover, coders did
not base their assessments of contextual sensitivity on the reputations of particular laboratories, researchers, or effects, nor did they assess objective information regarding subsequent replication attempts available in the literature.
- Contextual sensitivity ratings were made on a five-point scale, with anchors at 1 (context is not at all likely to affect results), 3 (context is somewhat
likely to affect results), and 5 (context is very likely to affect results) (mean =
2.90, SD = 1.16).
- Although the ideal
methods section should include enough detail to permit a direct
replication, this seemingly reasonable demand is rarely satisfied
in psychology, because human behavior is easily affected by
seemingly irrelevant factors (48).
