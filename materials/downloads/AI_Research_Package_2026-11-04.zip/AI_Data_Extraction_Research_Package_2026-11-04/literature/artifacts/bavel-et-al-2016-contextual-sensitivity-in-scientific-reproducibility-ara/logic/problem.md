# Problem

This ARA preserves a branch-local retrieval entry point for `Bavel et al. - 2016 - Contextual sensitivity in scientific reproducibility`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
