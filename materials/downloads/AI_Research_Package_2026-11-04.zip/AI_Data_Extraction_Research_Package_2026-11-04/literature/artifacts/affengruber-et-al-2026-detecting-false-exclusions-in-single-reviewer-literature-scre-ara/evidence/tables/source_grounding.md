# Source Grounding Table

| Field | Value |
|---|---|
| Source title | Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers |
| Source note | wiki/sources/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.md |
| Source path | raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf |
| Raw Markdown | rawmarkdown_full/affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-screening-by-using-ai-tools-as-secondary-reviewers.md |
| Grounding status | full_markdown |
| Branch degree | 7 |
| Incoming links | 0 |
| Outgoing links | 7 |
| Study kind | empirical-primary |
| Study method | applied-methods-study |
| Article role | supporting-rejoinder-evidence |
