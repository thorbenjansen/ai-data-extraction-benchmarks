# Evidence Layer

## Source Pointers

- Source note: `wiki/sources/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.md`
- Source path: `raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-screening-by-using-ai-tools-as-secondary-reviewers.md`
- Grounding status: `full_markdown`

## Evidence Policy

This ARA is grounded only to the level stated above. For exact claims, quotes, table values, sample sizes, or model performance numbers, open the Markdown sidecar/PDF and add a specific evidence file with page or section pointers.

## Current Evidence Records

- `evidence/tables/source_grounding.md`: source and graph metadata.
