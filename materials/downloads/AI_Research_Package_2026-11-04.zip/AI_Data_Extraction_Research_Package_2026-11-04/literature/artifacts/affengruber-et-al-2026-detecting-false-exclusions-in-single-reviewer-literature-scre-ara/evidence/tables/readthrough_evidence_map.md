# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf` |
| Raw Markdown | `rawmarkdown_full/affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-screening-by-using-ai-tools-as-secondary-reviewers.md` |
| Grounding | `pdftotext-full` |
| Provisional design | `protocol` |
| Branch role | `adjacent evidence-synthesis automation evidence` |
| Top terms | screening (75), artificial intelligence (4), chatgpt (2), systematic review automation (1), machine learning tools (1), review automation (1) |
| Verification status | Needs human source-checking before exact citation |
