# Read-Through Key Passages

## Abstract Or Opening

Abstract Background: Systematic reviews are fundamental to evidence-based medicine, but the process of screening studies is time-consuming and prone to errors, especially when conducted by a single reviewer. False exclusions of relevant studies can significantly impact the quality and reliability of reviews. Artificial intelligence (AI) tools have emerged as secondary reviewers in detecting these false exclusions, yet empirical evidence comparing their performance is limited. Methods: This study protocol outlines a comprehensive evaluation of four AI tools (ASReview, DistillerSR Artificial Intelligence System [DAISY], Evidence for Policy and

## Methods

S S E R P abstract screening missed, on Gartlehner et al. (2019) demonstrated that single-reviewer INa significant limitation in this approach (4). average, 13% of the relevant studies, highlighting E et al. (2019) found the median proportion of L Similarly, a systematic review by Waffenschmidt C I missed studies was 5% (rangeT 0 to 58%) in single-reviewer screenings (6). Comparatively, R A dual screening missed only 3% of the relevant studies on average, underscoring its robustness studies that can impact the validity and comprehensiveness of a review (4, 5).

## Results Or Findings

(4). Despite these findings, the Cochrane Handbook for Systematic Reviews of Interventions acknowledges that initial screening by a single reviewer is acceptable but, ideally, screening should be conducted in duplicate (2). In light of these challenges, advancements in artificial intelligence (AI) offer potential solutions to enhance the efficiency and accuracy of title and abstract screening in systematic reviews, particularly when only one reviewer is involved. Recent studies evaluating the performance of machine-assisted abstract screening report that AI tools are not ready to fully replace human screeners, and that head-to-head comparisons of AI tools are lacking (7).

## Discussion Or Conclusion

Discussion: This research seeks to provide valuable insights into the potential of AI-assisted screening for detecting falsely excluded studies during single screening. By comparing the performance of multiple AI tools, we aim to guide researchers in selecting the most effective assistive technologies for their review processes. Keywords: rapid reviews, AI tools, falsely excluded studies, study protocol Registration (Open Science Framework) : https://osf.io/dky26

## Limitations

S S E R P abstract screening missed, on Gartlehner et al. (2019) demonstrated that single-reviewer INa significant limitation in this approach (4). average, 13% of the relevant studies, highlighting E et al. (2019) found the median proportion of L Similarly, a systematic review by Waffenschmidt C I missed studies was 5% (rangeT 0 to 58%) in single-reviewer screenings (6). Comparatively, R A dual screening missed only 3% of the relevant studies on average, underscoring its robustness studies that can impact the validity and comprehensiveness of a review (4, 5).
