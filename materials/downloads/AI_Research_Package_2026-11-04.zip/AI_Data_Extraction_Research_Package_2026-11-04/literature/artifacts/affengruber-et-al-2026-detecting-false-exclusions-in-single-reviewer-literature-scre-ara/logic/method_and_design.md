# Method And Design

## Source Identity

- Title: Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers
- ARA: `affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-scre-ara`
- Source PDF: `raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf`
- Raw Markdown: `rawmarkdown_full/affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-screening-by-using-ai-tools-as-secondary-reviewers.md`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `protocol`
- Branch role: `adjacent evidence-synthesis automation evidence`

## Data, Sample, Or Source Material

S S E R P abstract screening missed, on Gartlehner et al. (2019) demonstrated that single-reviewer INa significant limitation in this approach (4). average, 13% of the relevant studies, highlighting E et al. (2019) found the median proportion of L Similarly, a systematic review by Waffenschmidt C I missed studies was 5% (rangeT 0 to 58%) in single-reviewer screenings (6). Comparatively, R A dual screening missed only 3% of the relevant studies on average, underscoring its robustness studies that can impact the validity and comprehensiveness of a review (4, 5).

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

(4). Despite these findings, the Cochrane Handbook for Systematic Reviews of Interventions acknowledges that initial screening by a single reviewer is acceptable but, ideally, screening should be conducted in duplicate (2). In light of these challenges, advancements in artificial intelligence (AI) offer potential solutions to enhance the efficiency and accuracy of title and abstract screening in systematic reviews, particularly when only one reviewer is involved. Recent studies evaluating the performance of machine-assisted abstract screening report that AI tools are not ready to fully replace human screeners, and that head-to-head comparisons of AI tools are lacking (7).

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
