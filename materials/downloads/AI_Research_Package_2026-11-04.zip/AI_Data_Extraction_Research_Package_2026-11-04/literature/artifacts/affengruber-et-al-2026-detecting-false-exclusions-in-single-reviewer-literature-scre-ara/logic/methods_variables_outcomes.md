# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `adjacent evidence-synthesis automation evidence`.
- Provisional design: `protocol`.
- Top automated-data-extraction terms in source text: screening (75), artificial intelligence (4), chatgpt (2), systematic review automation (1), machine learning tools (1), review automation (1).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Systematic Reviews

https://doi.org/10.1186/s13643-025-03031-7

Article in Press

Detecting false exclusions in single-reviewer
literature screening by using AI tools as
secondary reviewers: a study protocol for an
evaluation study
Lisa Affengruber, Jos Kleijnen & Gerald Gartlehner

Received: 17 Feb 2025
Accepted: 08 Dec 2025

Cite this article as: Affengruber,
L., Kleijnen, J., Gartlehner, G. et
al.
- Detecting false exclusions in
single-reviewer literature screening
by using AI tools as secondary
reviewers: a study protocol for an
evaluation study.
- Please
note there may be errors present which affect the content, and all legal disclaimers
apply.
- To view a copy of this licence, visit http://creativecommons.org/licenses/by-nc-nd/4.0/

ACCEPTED
ARTICLE IN
MANUSCRIPT
PRESS

Detecting false exclusions in single-reviewer literature screening by
using AI tools as secondary reviewers: A study protocol for an
evaluation study

Lisa Affengruber1,2, lisa.affengruber@donau-uni.ac.at
Jos Kleijnen4, jos@systematic-reviews.com
Gerald Gartlehner1,3, gerald.gartlehner@donau-uni.ac.at
1.
- Artificial intelligence (AI) tools have emerged as secondary reviewers
in detecting these false exclusions, yet empirical evidence comparing their performance is
limited.
- Methods: This study protocol outlines a comprehensive evaluation of four AI tools
(ASReview, DistillerSR Artificial Intelligence System [DAISY], Evidence for Policy and

S
S
reviewers during single-reviewer title and abstract screeningE
for systematic reviews.
- Utilizing
R published systematic reviews, we
Ptwo
a database of single-reviewer screening decisions from
N
will access how effective AI tools are at I
detecting false exclusions while assisting singleE reference standard.
- Additionally, we aim to
L
reviewer screening compared to the dual-reviewer
C
I
T performance of AI tools in assisting single-reviewer
determine the overall screening
R
A
screening.
- Practice Information [EPPI]-Reviewer, and Rayyan) in their capacity to act as secondary

Discussion: This research seeks to provide valuable insights into the potential of AI-assisted
screening for detecting falsely excluded studies during single screening.
- A critical phase in
systematic reviews is the title and abstract screening, where reviewers determine which
studies to include based on the information contained in the studies‟ titles and abstracts.
- The
accepted international standard for systematic reviews is dual-reviewer screening, which aims
to mitigate the risk of false exclusions–the erroneous exclusion of relevant studies (1-3).
- However, due to several factors, such as decision-making urgency and resource availability,
single-reviewer screening is often used, especially in rapid reviews.
