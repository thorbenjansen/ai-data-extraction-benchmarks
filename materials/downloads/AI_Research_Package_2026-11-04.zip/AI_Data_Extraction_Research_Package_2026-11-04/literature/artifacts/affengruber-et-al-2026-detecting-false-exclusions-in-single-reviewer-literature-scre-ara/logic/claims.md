# Claims

- C01: The source is highly connected in the branch graph with degree 7 (0 incoming, 7 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: This accepted study protocol evaluates four AI tools as secondary reviewers for single-reviewer title and abstract screening in systematic reviews. The protocol focuses on whether AI systems can detect false exclusions and approach the safety of dual-reviewer screening while improving efficiency. Within the branch, it is useful as adjacent evidence because it treats AI not as a replacement for human judgment but as...
- C03: The source note classifies the work as empirical-primary using applied-methods-study, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.

## Claim Status

- Supported by: `raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf` and `wiki/sources/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.md`
- Grounding status: `full_markdown`
- Verification priority: high for numerical or methodological details; medium for conceptual linkage claims.
