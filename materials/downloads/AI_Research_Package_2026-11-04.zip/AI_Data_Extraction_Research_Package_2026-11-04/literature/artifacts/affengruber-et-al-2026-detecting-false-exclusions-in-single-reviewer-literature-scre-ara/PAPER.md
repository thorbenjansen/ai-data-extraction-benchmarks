---
type: agent_native_research_artifact
date: 2026-05-04
source_title: "Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers"
source_note: "wiki/sources/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.md"
source_path: "raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf"
rawmarkdown_path: "rawmarkdown_full/affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-screening-by-using-ai-tools-as-secondary-reviewers.md"
grounding_status: "full_markdown"
branch: ai-data-extraction
ranking_degree: 7
ranking_incoming: 0
ranking_outgoing: 7
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers

## Retrieval Contract

Use this ARA as the first agent-facing layer for the source, then verify important claims against `evidence/README.md`, `the PDF/source note pointer`, and the branch source note `wiki/sources/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.md`.

## Source Grounding

- Source note: `wiki/sources/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.md`
- Source path: `raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf`
- Raw Markdown sidecar: `rawmarkdown_full/affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-screening-by-using-ai-tools-as-secondary-reviewers.md`
- Grounding status: `full_markdown`
- Branch graph rank signal: degree 7 = 0 incoming + 7 outgoing links.

## Abstracted Contribution

This accepted study protocol evaluates four AI tools as secondary reviewers for single-reviewer title and abstract screening in systematic reviews. The protocol focuses on whether AI systems can detect false exclusions and approach the safety of dual-reviewer screening while improving efficiency. Within the branch, it is useful as adjacent evidence because it treats AI not as a replacement for human judgment but as...

## Branch Use

This artifact was generated for the Top-20 connected-paper pass. It is designed for retrieval, rejoinder drafting, and source triage, not as a substitute for checking the PDF or full Markdown when making exact empirical claims.

## Main Ideas

- False exclusions are a central risk in single-reviewer screening and may threaten review quality.
- AI tools can be evaluated as secondary reviewers rather than as fully autonomous replacements.
- Comparative performance evidence is needed to decide when AI assistance is safe enough to complement or partially substitute human effort.

## Key Claims

- C01: The source is highly connected in the branch graph with degree 7 (0 incoming, 7 outgoing links), so it functions as a retrieval hub for the AI Data Extraction source base.
- C02: This accepted study protocol evaluates four AI tools as secondary reviewers for single-reviewer title and abstract screening in systematic reviews. The protocol focuses on whether AI systems can detect false exclusions and approach the safety of dual-reviewer screening while improving efficiency. Within the branch, it is useful as adjacent evidence because it treats AI not as a replacement for human judgment but as...
- C03: The source note classifies the work as empirical-primary using applied-methods-study, with article role supporting-rejoinder-evidence.
- C04: The source is linked to the AI Data Extraction branch theme and should be read alongside the anchor documents before using it in rejoinder synthesis.
- C05: The artifact preserves source pointers and grounding status so later agents can verify claims against the source note, markdown sidecar, and PDF rather than relying on this synthesis alone.
