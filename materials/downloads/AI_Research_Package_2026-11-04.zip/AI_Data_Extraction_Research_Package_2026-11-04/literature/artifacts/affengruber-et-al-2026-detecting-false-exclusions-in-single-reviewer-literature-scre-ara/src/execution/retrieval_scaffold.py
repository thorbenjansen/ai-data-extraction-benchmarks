"""Retrieval scaffold for the ARA: Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers."""
from pathlib import Path

BRANCH_ROOT = Path(__file__).resolve().parents[5]
SOURCE_NOTE = BRANCH_ROOT / "wiki" / "sources" / 'Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.md'
RAW_MARKDOWN = BRANCH_ROOT / 'rawmarkdown_full/affengruber-et-al-2026-detecting-false-exclusions-in-single-reviewer-literature-screening-by-using-ai-tools-as-secondary-reviewers.md'
SOURCE_PATH = BRANCH_ROOT / 'raw/Affengruber et al. - 2026 - Detecting false exclusions in single-reviewer literature screening by using AI tools as secondary reviewers.pdf' if True else None


def available_paths():
    paths = {"source_note": SOURCE_NOTE}
    if RAW_MARKDOWN:
        paths["raw_markdown"] = RAW_MARKDOWN
    if SOURCE_PATH:
        paths["source_path"] = SOURCE_PATH
    return {k: str(v) for k, v in paths.items() if v.exists()}
