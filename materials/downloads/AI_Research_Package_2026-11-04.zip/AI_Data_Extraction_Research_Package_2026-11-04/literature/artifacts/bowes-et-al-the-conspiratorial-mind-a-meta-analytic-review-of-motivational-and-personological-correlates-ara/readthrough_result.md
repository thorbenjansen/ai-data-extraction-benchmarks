# Read-Through Result

## Source Identity Check

- Title: Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates
- Source PDF: `raw/Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates.pdf`
- Raw Markdown: `missing`
- Grounding used: `pdftotext-full`

## Content Read-Through

The source was read through using full PDF text when available, with Markdown sidecar fallback. It was selected because it matched automated data extraction, LLM/AI evidence synthesis, screening, annotation, or related review-automation terms.

## Methods And Design Check

- Provisional design: `guidance/framework`
- Branch role: `background meta-research or synthesis-methods evidence`

## Results Or Findings Check

Method Inclusion Criteria and Literature Search To identify candidate studies, we started by searching references from previous meta-analyses on conspiratorial ideation (e.g., Goreis & Voracek, 2019; Imhoff & Lamberty, 2018; Stojanov & Halberstadt, 2020). We next broadened our search through electronic databases, speciﬁcally Google Scholar and APA PsycInfo,6 using a series of Boolean phrases (e.g., ((“conspir* theor* OR conspire* belie* OR conspire* idea*) AND open*)). For the complete list of search terms we used, see Supplemental Table S1. Deﬁnitions of and references for motivational and personological constructs included in the meta-analysis are provided in Supplemental Tables S2 and S3. See Figure 1 for an overview of the screening process. We included studies that contained the words “conspiracy,” “conspiratorial,” or “epistemically unwarranted beliefs” and allied constructs (e.g., scientiﬁcally unsubstantiated beliefs) in the title or abstract. We broadened our initial search to include studies referencing epistemically unwarranted beliefs and allied constructs, as conspiracy theories are often discussed and measured in the larger context of epistemically unwarranted/questionable beliefs (e.g., Lobato et al., 2014). Our inclusion criteria also included the following: studies that (a) report an effect size (e.g., Pearson’s r) and (b) measure a motivational or personological construct via selfreport or experimental paradigm (e.g., lab measures of illusory pattern perception). Both published and unpublished (i.e., preprints, theses, data sets) articles were eligible for inclusion. No exclusions were made based on study population. Articles not written in English were excluded. For studies that used multiple waves, we included the correlations within waves (e.g., Wave 1 conspiratorial ideation with Wave 1 variable of interest; Wave 2 conspiratorial ideation with Wave 2 variable of interest; see Golec de Zavala & Federico, 2018). In studies using pre–post designs (e.g., Orosz et al., 2016), we included the correlations between baseline levels of conspiratorial ideation and variables of interest at baseline, and we did not include the correlations between experimentally induced (post) levels of conspiratorial ideation and variables of interest. The ﬁnal search was conducted in February 2022, yielding a total of 3,721 unique results (after repeat titles were

## Theory And Concept Check

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Human-AI Validation]]
- [[LLM Accuracy]]
- [[Speed-Accuracy Tradeoff]]

## Noise Removed

This pass did not preserve title-page boilerplate as claims. It wrote concise method/scope/evidence files and left exact quotation to source checking.

## Open Verification Needs

- Verify exact methods, sample sizes, field definitions, and metrics in the PDF.
- Distinguish direct data extraction evidence from adjacent tasks.
- Add parser-compatible APA relations only after close manual comparison with neighboring ARAs.

## Final Read-Through Status

`automated-readthrough-complete`; do not treat as `curated-level-3`.
