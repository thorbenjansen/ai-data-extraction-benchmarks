# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `guidance/framework` |
| Branch role | `background meta-research or synthesis-methods evidence` |
| Top terms | screening (2) |
| Verification status | Needs human source-checking before exact citation |
