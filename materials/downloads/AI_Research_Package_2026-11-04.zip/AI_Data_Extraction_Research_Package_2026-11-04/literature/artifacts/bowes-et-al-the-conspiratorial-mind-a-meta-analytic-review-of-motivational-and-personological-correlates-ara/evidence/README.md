# Evidence README

## Source Pointer

- PDF: `raw/Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Psychological Bulletin
© 2023 American Psychological Association
ISSN: 0033-2909

2023, Vol. 149, Nos. 5–6, 259–293
https://doi.org/10.1037/bul0000392

The Conspiratorial Mind: A Meta-Analytic Review of Motivational and
Personological Correlates
Shauna M. Bowes1, Thomas H. Costello1, 2, 3, and Arber Tasimi1
1

This document is copyrighted by the American Psychological Association or one of its allied publishers.
This article is intended solely for the personal use of the individual user and is not to be disseminated broadly.

2

Department of Psychology, Emory University
Sloan School of Management, Massachusetts Institute of Technology
3
Department of Psychology, University of Regina

A tidal wave of research has tried to uncover the motivational and personological correlates of conspiratorial
ideation, often studying these two classes of correlates in parallel. Here, we synthesize this vast and
piecemeal literature through a multilevel meta-analytic review that spanned 170 studies, 257 samples,
52 variables, 1,429 effect sizes, and 158,473 participants. Overall, we found that the strongest correlates of
conspiratorial ideation pertained to (a) perceiving danger and threat, (b) relying on intuition and having
odd beliefs and experiences, and (c) being antagonistic and acting superior. Considerable heterogeneity was
found within these relations––especially when individual variables were lumped together under a single
domain––and we identiﬁed potential boundary conditions in these relations (e.g., type of conspiracy). Given
that the psychological correlates of conspiratorial ideation have often been classiﬁed as belonging to one
of two broad domains—motivation or personality—we aim to understand the implications of such
heterogeneity for frameworks of conspiratorial ideat
