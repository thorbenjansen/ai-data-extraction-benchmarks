# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
