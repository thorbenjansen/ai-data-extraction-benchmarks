# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `background meta-research or synthesis-methods evidence`.
- Provisional design: `guidance/framework`.
- Top automated-data-extraction terms in source text: screening (2).

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Despite relatively consistent cross-sectional links between anxiety
and existential threat sensitivity and conspiratorial ideation, some
research shows that anxiety and existential threat sensitivity do
not seem to temporally precede conspiratorial ideation; such
results raise questions about whether and to what extent anxiety and
existential threat sensitivity are causes of conspiratorial ideation
(Liekefett et al., 2023).
- See Figure 1 for an overview of the screening process.
- Figure 1
Flowchart of Screening Process

Note. k = number of studies; S = number of samples; ES = number of effect sizes.

(257 samples, 1,429 effect sizes) that met inclusion criteria.
- Effect sizes were also
weighted according to the inverse of their variance (i.e., sampling
error) as it is the standard approach in meta-analysis (MarinMartinez & Sánchez-Meca, 2010).
- By accounting for systematic variance
across outcomes from the same sample, we were better able to
account for correlated sampling errors (e.g., because of multiple
effect sizes drawn from the same sample; Van den Noortgate et al.,
2013) than previous meta-analyses (e.g., Goreis & Voracek, 2019;
Stasielowicz, 2022).
- First, we added the standard error or variance for each effect size as
a predictor in each meta-analytic model.
- The precision-effect
test (PET; Stanley & Doucouliagos, 2014) is a meta-regression
technique in which the effect sizes are predicted from their
standard errors and weighted according to their precision estimates
(see Carter et al., 2019).
- If PET is signiﬁcant, then it is recommended
to follow-up with the precision-effect estimate with standard error
test (PEESE; see Carter et al., 2019).
- PEESE is the same as PET
except that the effect sizes are predicted from the squared standard
errors.
- Interpreting the magnitude of
publication bias from a funnel plot based upon visual inspection alone is
subjective and susceptible to error, however, and scholars caution against
interpreting funnel plots when effect sizes are signiﬁcantly heterogeneous
(Vevea & Woods, 2005).
- Finally,
conspiratorial ideation was strongly related to more delusion-proneness

and anthropomorphism, more existential threat sensitivity, belief
in a dangerous world, cynicism, and powerlessness, more anomie,
and more collective narcissism and social threat perception.
- Longitudinal research provides some evidence that intolerance
of uncertainty both precedes and follows conspiratorial ideation
(e.g., endorsement of COVID-19 conspiracy theories), suggesting
that conspiracy theories do not satisfy this epistemic motive, and,
if anything, increase it; there was also some evidence that
conspiratorial ideation predicted increases in existential motives,
namely anxiety and existential threat sensitivity (e.g., Liekefett
et al., 2023).
