# Problem

This ARA preserves a branch-local retrieval entry point for `Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates`.

## Provisional Role

- Document category: `evidence-synthesis-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
