# Claims

- C01: `Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates` is part of the AI Data Extraction branch source base and should be retrieved with the anchor documents before use in rejoinder synthesis.
- C02: The source is provisionally connected to [[AI Data Extraction]], [[Evidence Synthesis Automation]], [[Speed-Accuracy Tradeoff]].
- C03: The current ARA is a scaffold; exact empirical, methodological, and numerical claims require source checking against `raw/Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates.pdf`.
