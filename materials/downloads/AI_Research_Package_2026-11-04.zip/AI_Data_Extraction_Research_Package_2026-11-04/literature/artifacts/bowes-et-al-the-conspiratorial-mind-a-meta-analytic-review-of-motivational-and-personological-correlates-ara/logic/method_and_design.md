# Method And Design

## Source Identity

- Title: Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates
- ARA: `bowes-et-al-the-conspiratorial-mind-a-meta-analytic-review-of-motivational-and-personological-correlates-ara`
- Source PDF: `raw/Bowes et al. - The Conspiratorial Mind A Meta-Analytic Review of Motivational and Personological Correlates.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `guidance/framework`
- Branch role: `background meta-research or synthesis-methods evidence`

## Data, Sample, Or Source Material

Method Inclusion Criteria and Literature Search To identify candidate studies, we started by searching references from previous meta-analyses on conspiratorial ideation (e.g., Goreis & Voracek, 2019; Imhoff & Lamberty, 2018; Stojanov & Halberstadt, 2020). We next broadened our search through electronic databases, speciﬁcally Google Scholar and APA PsycInfo,6 using a series of Boolean phrases (e.g., ((“conspir* theor* OR conspire* belie* OR conspire* idea*) AND open*)). For the complete list of search terms we used, see Supplemental Table S1. Deﬁnitions of and references for motivational and personological constructs included in the meta-analysis are provided in Supplemental Tables S2 and S3. See Figure 1 for an overview of the screening process. We included studies that contained the words “conspiracy,” “conspiratorial,” or “epistemically unwarranted beliefs” and allied constructs (e.g., scientiﬁcally unsubstantiated beliefs) in the title or abstract. We broadened our initial search to include studies referencing epistemically unwarranted beliefs and allied constructs, as conspiracy theories are often discussed and measured in the larger context of epistemically unwarranted/questionable beliefs (e.g., Lobato et al., 2014). Our inclusion criteria also included the following: studies that (a) report an effect size (e.g., Pearson’s r) and (b) measure a motivational or personological construct via selfreport or experimental paradigm (e.g., lab measures of illusory pattern perception). Both published and unpublished (i.e., preprints, theses, data sets) articles were eligible for inclusion. No exclusions were made based on study population. Articles not written in English were excluded. For studies that used multiple waves, we included the correlations within waves (e.g., Wave 1 conspiratorial ideation with Wave 1 variable of interest; Wave 2 conspiratorial ideation with Wave 2 variable of interest; see Golec de Zavala & Federico, 2018). In studies using pre–post designs (e.g., Orosz et al., 2016), we included the correlations between baseline levels of conspiratorial ideation and variables of interest at baseline, and we did not include the correlations between experimentally induced (post) levels of conspiratorial ideation and variables of interest. The ﬁnal search was conducted in February 2022, yielding a total of 3,721 unique results (after repeat titles were

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Method Inclusion Criteria and Literature Search To identify candidate studies, we started by searching references from previous meta-analyses on conspiratorial ideation (e.g., Goreis & Voracek, 2019; Imhoff & Lamberty, 2018; Stojanov & Halberstadt, 2020). We next broadened our search through electronic databases, speciﬁcally Google Scholar and APA PsycInfo,6 using a series of Boolean phrases (e.g., ((“conspir* theor* OR conspire* belie* OR conspire* idea*) AND open*)). For the complete list of search terms we used, see Supplemental Table S1. Deﬁnitions of and references for motivational and personological constructs included in the meta-analysis are provided in Supplemental Tables S2 and S3. See Figure 1 for an overview of the screening process. We included studies that contained the words “conspiracy,” “conspiratorial,” or “epistemically unwarranted beliefs” and allied constructs (e.g., scientiﬁcally unsubstantiated beliefs) in the title or abstract. We broadened our initial search to include studies referencing epistemically unwarranted beliefs and allied constructs, as conspiracy theories are often discussed and measured in the larger context of epistemically unwarranted/questionable beliefs (e.g., Lobato et al., 2014). Our inclusion criteria also included the following: studies that (a) report an effect size (e.g., Pearson’s r) and (b) measure a motivational or personological construct via selfreport or experimental paradigm (e.g., lab measures of illusory pattern perception). Both published and unpublished (i.e., preprints, theses, data sets) articles were eligible for inclusion. No exclusions were made based on study population. Articles not written in English were excluded. For studies that used multiple waves, we included the correlations within waves (e.g., Wave 1 conspiratorial ideation with Wave 1 variable of interest; Wave 2 conspiratorial ideation with Wave 2 variable of interest; see Golec de Zavala & Federico, 2018). In studies using pre–post designs (e.g., Orosz et al., 2016), we included the correlations between baseline levels of conspiratorial ideation and variables of interest at baseline, and we did not include the correlations between experimentally induced (post) levels of conspiratorial ideation and variables of interest. The ﬁnal search was conducted in February 2022, yielding a total of 3,721 unique results (after repeat titles were

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
