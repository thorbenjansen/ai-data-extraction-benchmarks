# Read-Through Evidence Map

| Field | Automated read-through value |
|---|---|
| Source PDF | `raw/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.pdf` |
| Raw Markdown | `missing` |
| Grounding | `pdftotext-full` |
| Provisional design | `needs-further-coding` |
| Branch role | `branch-adjacent context` |
| Top terms | none found |
| Verification status | Needs human source-checking before exact citation |
