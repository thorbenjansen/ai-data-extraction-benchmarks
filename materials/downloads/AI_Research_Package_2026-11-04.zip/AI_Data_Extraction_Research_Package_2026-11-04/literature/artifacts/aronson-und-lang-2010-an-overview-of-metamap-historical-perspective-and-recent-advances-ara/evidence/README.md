# Evidence README

## Source Pointer

- PDF: `raw/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.pdf`
- Raw Markdown: `not available`

## Current Evidence State

This ARA has a scaffold-level evidence layer. Use the PDF or raw Markdown for quotation, numeric extraction, inclusion/exclusion decisions, and final manuscript claims.

## Initial Excerpt

Synthesis of research

An overview of MetaMap: historical perspective and
recent advances
Alan R Aronson, François-Michel Lang
Lister Hill National Center for
Biomedical Communications
(LHNCBC), US National Library
of Medicine, National Institutes
of Health, Bethesda, Maryland,
USA
Correspondence to
Dr Alan R Aronson, National
Library of Medicine, Building
38A, Room 9N-905 8600
Rockville Pike, MSC-3826,
Bethesda, MD 20894, USA;
alan@nlm.nih.gov
Received 26 February 2010
Accepted 2 March 2010

ABSTRACT
MetaMap is a widely available program providing access
to the concepts in the unified medical language system
(UMLS) Metathesaurus from biomedical text. This study
reports on MetaMap’s evolution over more than
a decade, concentrating on those features arising out of
the research needs of the biomedical informatics
community both within and outside of the National
Library of Medicine. Such features include the detection
of author-defined acronyms/abbreviations, the ability to
browse the Metathesaurus for concepts even tenuously
related to input text, the detection of negation in
situations in which the polarity of predications is
important, word sense disambiguation (WSD), and
various technical and algorithmic features. Near-term
plans for MetaMap development include the
incorporation of chemical name recognition and
enhanced WSD.

MetaMap1 is a widely available program providing
access from biomedical text to the concepts in the
uniﬁed medical language system (UMLS) Metathesaurus. MetaMap arose in the context of an effort
to improve biomedical text retrieval, speciﬁcally the
retrieval of MEDLINE/PubMed citations.2 3 It
provided a link between the text of biomedical
literature and the knowledge, including synonymy
relationships, embedded in the Metathesaurus. Early
MetaMap
