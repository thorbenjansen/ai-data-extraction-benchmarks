# Read-Through Key Passages

## Abstract Or Opening

ABSTRACT MetaMap is a widely available program providing access to the concepts in the unified medical language system (UMLS) Metathesaurus from biomedical text. This study reports on MetaMap’s evolution over more than a decade, concentrating on those features arising out of the research needs of the biomedical informatics community both within and outside of the National Library of Medicine. Such features include the detection of author-defined acronyms/abbreviations, the ability to browse the Metathesaurus for concepts even tenuously related to input text, the detection of negation in situations in which the polarity of predications is important, word sense disambiguation (WSD), and various technical and algorithmic features. Near-term plans for MetaMap development include the incorporation of chemical name recognition and enhanced WSD.

## Methods

As mentioned earlier, the ﬁnal phase of MetaMap’s lexical/ syntactic processing involves computing a shallow parse, dividing the input text into phrases, which form the basis of MetaMap’s subsequent processing. Each phrase’s human-readable output by default consists of three parts: < the phrase itself; < the candidates, a list of intermediate results consisting of Metathesaurus strings matching some or all of the input text. In addition, the preferred name of each candidate is displayed in parentheses if it differs from the candidate, and the semantic type of the candidate is also shown; and ﬁnally, < the mappings, combinations of candidates matching as much of the phrase as possible. Most elements of human-readable output, whether default or optional, can be shown or hidden based on MetaMap options. In addition, by default MetaMap displays only those mappings that receive the highest score. MetaMap’s default human-readable output generated from the input text obstructive sleep apnea is shown in ﬁgure 2. In this example MetaMap identiﬁed 11 Metathesaurus candidates, the best of which received a perfect score of 1000, and by itself formed the top-scoring mapping. If all mappings had been requested, then several more mappings including one consisting of the combination of ‘apnea, sleep’ and ‘obstructive’ would have been displayed. MetaMap possesses a number of strengths and weaknesses. Among its strengths are its thoroughness, characterized by its aggressive generation of word variants, and its linguistically principled approach to its lexical and syntactic analyses as well as its evaluation metric for scoring and ranking concepts. It is also adept at constructing partial, compound mappings when a single concept is insufﬁcient to characterize input text phrases. As evidenced by the above description of some of its options, it is highly conﬁgurable; its behavior can be easily customized depending on the task being addressed. Finally, because its lexicon and target vocabulary can be replaced with others from another domain, it has the property of domain independence. One of MetaMap’s weaknesses is that it can be applied only to English text. MetaMap’s English-centric nature is evident throughout its implementation, not just in its lexical and J Am Med Inform Assoc 2010;17:229e236. doi:10.1136/jamia.2009.002733

## Results Or Findings

Each phrase’s human-readable output by default consists of three parts:
< the phrase itself;
< the candidates, a list of intermediate results consisting of
Metathesaurus strings matching some or all of the input text. Most elements of human-readable output, whether default or
optional, can be shown or hidden based on MetaMap options. MetaMap’s default human-readable output generated from the input text obstructive sleep
apnea is shown in ﬁgure 2. MetaMap’s English-centric nature is evident
throughout its implementation, not just in its lexical and
J Am Med Inform Assoc 2010;17:229e236. doi:10.1136/jamia.2009.002733

Synthesis of research
Figure 2 An example of MetaMap’s humanreadable output.

## Discussion Or Conclusion

Perhaps MetaMap’s greatest weakness is its reduced accuracy
in the presence of ambiguity. J Am Med Inform Assoc 2010;17:229e236. doi:10.1136/jamia.2009.002733

Synthesis of research
Tokenization issues
Acronym detection

Output formats

Most technical domains are heavily laden with acronyms and
abbreviations (AA), often accompanied by their deﬁnitions or
expansions:
The effect of adrenocorticotropic hormone (ACTH) and cortisone
on drug hypersensitivity reactions. Figure 3 MetaMap’s human-readable output
for the input text ‘heart’. MetaMap’s default output is human readable and displays, for
each phrase in the input text, an intermediate list of candidate
Metathesaurus concepts matching (part of) the phrase, the
mappings formed by combining candidates matching disjoint
phrase text, and ancillary information, often optional, such as
concept CUI and their semantic types.

## Limitations

No clean limitations passage isolated automatically.
