---
type: agent_native_research_artifact
date: 2026-05-12
source_title: "Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances"
source_note: "wiki/sources/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.md"
source_path: "raw/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.pdf"
rawmarkdown_path: ""
grounding_status: "pdf_first_pages"
branch: ai-data-extraction
status: automated-level-3
quality_label: automated-level-3
readthrough_status: automated-readthrough-complete
readthrough_date: 2026-05-12
---

# Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances

## Retrieval Contract

Use this ARA as the first branch-local agent-facing layer for the source. Verify important claims against `evidence/README.md`, the branch source note, the raw Markdown sidecar when available, and the PDF.

## Source Grounding

- Source note: `wiki/sources/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.md`
- Source path: `raw/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.pdf`
- Raw Markdown sidecar: `missing`
- Grounding status: `pdf_first_pages`

## Abstracted Contribution

Synthesis of research

An overview of MetaMap: historical perspective and
recent advances
Alan R Aronson, François-Michel Lang
Lister Hill National Center for
Biomedical Communications
(LHNCBC), US National Library
of Medicine, National Institutes
of Health, Bethesda, Maryland,
USA
Correspondence to
Dr Alan R Aronson, National
Library of Medicine, Building
38A, Room 9N-905 8600
Rockville Pike, MSC-3826,
Bethesda, MD 20894, USA;
alan@nlm.nih.gov
Received 26 February 2010
Accepted 2 March 2010

ABSTRACT
MetaMap is a widely available program providing access
to the concepts in the unified medical language system
(UMLS) Metathesaurus from biomedical text. This study
reports on MetaMap’s evolution over more than
a decade, concentrating on those features arising out of
the research needs of the biomedical informatics
community both within and outside of the National
Library of Medicine. Such features include the detection
of author-defined acronyms/abbreviations, the ability to
browse the Metathesaurus for concepts even tenuously
related to input text, the detection of negation in
situations in which the polarity of predications is
important, word sense disambiguation (WSD), and
various technical and algorithmic features. Near-term
plans for MetaMap development include the
incorporation of chemical name recognition and
enhanced WSD.

MetaMap1 is a widely available program providing
access from biomedical text to the concepts in the
uniﬁed medical language system (UMLS) Metathesaurus. MetaMap arose in the context of an effort
to improve biomedical text retrieval, speciﬁcally the
retrieval of MEDLINE/PubMed citations.2 3 It
provided a link between the text of biomedical
literature and the knowledge, including synonymy
relationships, embedded in the Metathesaurus. Early
MetaMap

## Branch Use

This artifact was generated to make every PDF in the AI Data Extraction branch retrievable through a consistent ARA framework. It is a Level 1 scaffold unless later files in this folder document deeper curation.

## Main Concept Links

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Context Engineering]]

## Layer Index

- `logic/claims.md`
- `logic/problem.md`
- `logic/concepts.md`
- `logic/related_work.md`
- `logic/experiments.md`
- `evidence/README.md`
- `trace/exploration_tree.yaml`
- `src/environment.md`
- `index.html`
