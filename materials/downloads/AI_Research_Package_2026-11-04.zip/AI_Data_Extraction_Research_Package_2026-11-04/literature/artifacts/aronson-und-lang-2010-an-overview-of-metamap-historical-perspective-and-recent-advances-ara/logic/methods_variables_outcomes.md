# Methods Variables Outcomes

## Extraction-Relevant Constructs

- Branch role: `branch-adjacent context`.
- Provisional design: `needs-further-coding`.
- Top automated-data-extraction terms in source text: none found.

## Variables And Measures To Source-Check

- AI system or tool used.
- Human comparison or adjudication workflow.
- Data extraction target fields.
- Screening/extraction/annotation/risk-of-bias task definition.
- Accuracy, agreement, sensitivity, specificity, error rate, time, cost, or workload outcomes.

## Extracted Evidence Sentences

- Each phrase’s human-readable output by default consists of three parts:
< the phrase itself;
< the candidates, a list of intermediate results consisting of
Metathesaurus strings matching some or all of the input text.
- Most elements of human-readable output, whether default or
optional, can be shown or hidden based on MetaMap options.
- MetaMap’s default human-readable output generated from the input text obstructive sleep
apnea is shown in ﬁgure 2.
- MetaMap’s English-centric nature is evident
throughout its implementation, not just in its lexical and
J Am Med Inform Assoc 2010;17:229e236. doi:10.1136/jamia.2009.002733

Synthesis of research
Figure 2 An example of MetaMap’s humanreadable output.
- Perhaps MetaMap’s greatest weakness is its reduced accuracy
in the presence of ambiguity.
- J Am Med Inform Assoc 2010;17:229e236. doi:10.1136/jamia.2009.002733

Synthesis of research
Tokenization issues
Acronym detection

Output formats

Most technical domains are heavily laden with acronyms and
abbreviations (AA), often accompanied by their deﬁnitions or
expansions:
The effect of adrenocorticotropic hormone (ACTH) and cortisone
on drug hypersensitivity reactions.
- Figure 3 MetaMap’s human-readable output
for the input text ‘heart’.
- MetaMap’s default output is human readable and displays, for
each phrase in the input text, an intermediate list of candidate
Metathesaurus concepts matching (part of) the phrase, the
mappings formed by combining candidates matching disjoint
phrase text, and ancillary information, often optional, such as
concept CUI and their semantic types.
- MMO, the earliest alternative form of MetaMap output,
includes a superset of the information in human-readable output
and is formatted as Prolog terms.
- To provide context, ﬁgure 3 contains the human-readable
output for heart.
- The
former improves accuracy while the latter improves throughput.
- No content-bearing
word (such as human, disease and protein) appeared in more
than 12 K concepts; consequently the relatively modest size of
the Metathesaurus did not impose signiﬁcant computational
constraints.
