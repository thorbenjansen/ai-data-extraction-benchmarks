# Concepts

- [[AI Data Extraction]]
- [[Evidence Synthesis Automation]]
- [[Context Engineering]]
