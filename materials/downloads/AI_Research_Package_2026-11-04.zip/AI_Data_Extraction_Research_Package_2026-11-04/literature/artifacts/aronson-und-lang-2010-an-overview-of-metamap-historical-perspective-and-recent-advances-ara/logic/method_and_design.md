# Method And Design

## Source Identity

- Title: Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances
- ARA: `aronson-und-lang-2010-an-overview-of-metamap-historical-perspective-and-recent-advances-ara`
- Source PDF: `raw/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.pdf`
- Raw Markdown: `missing`
- Automated read-through grounding: `pdftotext-full`

## Design Classification

- Provisional design: `needs-further-coding`
- Branch role: `branch-adjacent context`

## Data, Sample, Or Source Material

As mentioned earlier, the ﬁnal phase of MetaMap’s lexical/ syntactic processing involves computing a shallow parse, dividing the input text into phrases, which form the basis of MetaMap’s subsequent processing. Each phrase’s human-readable output by default consists of three parts: < the phrase itself; < the candidates, a list of intermediate results consisting of Metathesaurus strings matching some or all of the input text. In addition, the preferred name of each candidate is displayed in parentheses if it differs from the candidate, and the semantic type of the candidate is also shown; and ﬁnally, < the mappings, combinations of candidates matching as much of the phrase as possible. Most elements of human-readable output, whether default or optional, can be shown or hidden based on MetaMap options. In addition, by default MetaMap displays only those mappings that receive the highest score. MetaMap’s default human-readable output generated from the input text obstructive sleep apnea is shown in ﬁgure 2. In this example MetaMap identiﬁed 11 Metathesaurus candidates, the best of which received a perfect score of 1000, and by itself formed the top-scoring mapping. If all mappings had been requested, then several more mappings including one consisting of the combination of ‘apnea, sleep’ and ‘obstructive’ would have been displayed. MetaMap possesses a number of strengths and weaknesses. Among its strengths are its thoroughness, characterized by its aggressive generation of word variants, and its linguistically principled approach to its lexical and syntactic analyses as well as its evaluation metric for scoring and ranking concepts. It is also adept at constructing partial, compound mappings when a single concept is insufﬁcient to characterize input text phrases. As evidenced by the above description of some of its options, it is highly conﬁgurable; its behavior can be easily customized depending on the task being addressed. Finally, because its lexicon and target vocabulary can be replaced with others from another domain, it has the property of domain independence. One of MetaMap’s weaknesses is that it can be applied only to English text. MetaMap’s English-centric nature is evident throughout its implementation, not just in its lexical and J Am Med Inform Assoc 2010;17:229e236. doi:10.1136/jamia.2009.002733

## Method Workflow

This source was read from the branch-local PDF or Markdown sidecar and mapped for AI data extraction relevance. Treat this as an automated read-through card: useful for routing, but not a replacement for close reading when citing exact methods.

## Outcomes Or Analytic Targets

Each phrase’s human-readable output by default consists of three parts:
< the phrase itself;
< the candidates, a list of intermediate results consisting of
Metathesaurus strings matching some or all of the input text. Most elements of human-readable output, whether default or
optional, can be shown or hidden based on MetaMap options. MetaMap’s default human-readable output generated from the input text obstructive sleep
apnea is shown in ﬁgure 2. MetaMap’s English-centric nature is evident
throughout its implementation, not just in its lexical and
J Am Med Inform Assoc 2010;17:229e236. doi:10.1136/jamia.2009.002733

Synthesis of research
Figure 2 An example of MetaMap’s humanreadable output.

## What To Verify Before Citation-Grade Use

- Exact sample/study counts.
- Exact model/tool versions.
- Evaluation metrics and denominators.
- Whether reported accuracy concerns screening, extraction, annotation, risk-of-bias, or downstream synthesis.
- Whether humans are used as gold standard, adjudicators, reviewers, validators, or final decision makers.
