# Methods And Evidence Role

- Current status: automated scaffold.
- Grounding status: `pdf_first_pages`.
- Source checking path: `raw/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.pdf`.
- Raw Markdown path: `not available`.
