# Problem

This ARA preserves a branch-local retrieval entry point for `Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances`.

## Provisional Role

- Document category: `branch-source`
- Branch anchor: connect explicitly to [[Main Paper]], [[Commentary]], [[Commentary 2]], or [[Rejoinder Map]] before using in final prose.
