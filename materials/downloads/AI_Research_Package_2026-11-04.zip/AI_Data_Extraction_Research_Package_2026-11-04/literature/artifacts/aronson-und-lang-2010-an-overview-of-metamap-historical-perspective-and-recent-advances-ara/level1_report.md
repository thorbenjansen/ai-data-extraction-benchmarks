# Level 1 Report

- `PAPER.md`: present.
- Source PDF: `raw/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.pdf`.
- Raw Markdown: `missing`.
- Source note: `wiki/sources/Aronson und Lang - 2010 - An overview of MetaMap historical perspective and recent advances.md`.
- Required scaffold folders: present.
- Status: `automated-level-1`.
